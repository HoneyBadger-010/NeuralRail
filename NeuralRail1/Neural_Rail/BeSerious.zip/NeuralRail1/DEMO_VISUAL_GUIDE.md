# 🎬 NeuralRail Demo - Visual Guide

## 🖥️ Initial Screen (Before Loading Scenario)

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│ 🚄 RAILWAY CONTROL ROOM          Mumbai Division          ●LIVE    12:00:00 IST │
├──────────────┬──────────────────────────────────────────────────┬────────────────┤
│              │                                                  │                │
│ LOAD SCENARIO│  🗺️ CSMT-PUNE Railway Network (192 km)         │                │
│              │  Select a scenario to begin                     │                │
│ ┌──────────┐ │                                                  │                │
│ │    1     │ │  CSMT    THANE    KYN    KARJAT    LNL    PUNE  │                │
│ │ Kalyan-  │ │   0km     34km    54km     80km    106km  192km │                │
│ │ Karjat   │ │   │       │       │        │       │       │    │                │
│ │ Conflict │ │   ▼       ▼       ▼        ▼       ▼       ▼    │                │
│ └──────────┘ │                                                  │                │
│              │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │                │
│ ┌──────────┐ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │                │
│ │    2     │ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │                │
│ │ CSMT-    │ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │                │
│ │ Thane    │ │                                                  │                │
│ │ Suburban │ │  [+] 100% [-]                                   │                │
│ └──────────┘ │                                                  │                │
│              │  Route: CSMT-PUNE  View: 0-192km  Trains: 0     │                │
│ ┌──────────┐ │                                                  │                │
│ │    3     │ ├──────────────────────────────────────────────────┤                │
│ │ Bhor Ghat│ │  📈 Distance-Time Graph                         │                │
│ │🔥 KILLER │ │  Simulation data will appear here               │                │
│ └──────────┘ │                                                  │                │
│              │                                                  │  📊            │
│              │                                                  │  Load scenario │
│              │                                                  │  to see AI     │
│              │                                                  │  recommendations│
│              │                                                  │                │
└──────────────┴──────────────────────────────────────────────────┴────────────────┘
```

## 🎯 After Loading Scenario 1 (Kalyan-Karjat)

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│ 🚄 RAILWAY CONTROL ROOM          Mumbai Division          ●LIVE    12:00:15 IST │
├──────────────┬──────────────────────────────────────────────────┬────────────────┤
│              │                                                  │                │
│ LOAD SCENARIO│  🗺️ CSMT-PUNE Railway Network (192 km)         │ ⚠️ CONFLICT    │
│              │  ● Scenario 1 - KYN-KARJAT                      │   DETECTED     │
│ ┌──────────┐ │                                                  │                │
│ │    1     │ │        KYN          KARJAT                      │ Type: Head-on  │
│ │ Kalyan-  │ │        54km           80km                      │ Location: 67km │
│ │ Karjat   │◄┤        │              │                         │ Time: 45s      │
│ │ Conflict │ │        ▼              ▼                         │ Trains: RAJ,FRT│
│ └──────────┘ │                                                  │                │
│              │  Track 1: ━━━━●RAJ━━━━━━━━━━━━━━━━FRT●━━━━━━  │ 🤖 AI RECS     │
│ ┌──────────┐ │  Track 2: ━━━━━━━━━━🚧━━━━━━━━━━━━━━━━━━━━━  │                │
│ │    2     │ │                                                  │ #1 Stop RAJ    │
│ │ CSMT-    │ │  [+] 180% [-]                                   │ Energy: 245kWh │
│ │ Thane    │ │                                                  │ Delay: 3.2min  │
│ │ Suburban │ │  Route: CSMT-PUNE  View: 48-86km  Trains: 2    │ Score: 0.85    │
│ └──────────┘ │                                                  │ [Apply]        │
│              ├──────────────────────────────────────────────────┤                │
│ ┌──────────┐ │  📈 Distance-Time Graph                         │ #2 Stop FRT    │
│ │    3     │ │                                                  │ Energy: 892kWh │
│ │ Bhor Ghat│ │  80km ┤     ╱RAJ                               │ Delay: 8.5min  │
│ │🔥 KILLER │ │       │    ╱                                    │ Score: 0.42    │
│ └──────────┘ │  70km ┤   ╱                                     │ [Apply]        │
│              │       │  ╱                                      │                │
│ CURRENT      │  60km ┤ ╱    ╲FRT                              │ ⚡ ENERGY      │
│ SECTION      │       │╱      ╲                                 │                │
│              │  54km └────────────→                            │ System: 1245kWh│
│ KYN-KARJAT   │        0s    30s   60s                          │                │
│              │                                                  │                │
│ TRAINS (2)   │                                                  │                │
│              │                                                  │                │
│ ┌──────────┐ │                                                  │                │
│ │ RAJ      │ │                                                  │                │
│ │ 98 km/h  │ │                                                  │                │
│ │ 56.2 km  │ │                                                  │                │
│ │ Track 1  │ │                                                  │                │
│ └──────────┘ │                                                  │                │
│              │                                                  │                │
│ ┌──────────┐ │                                                  │                │
│ │ FRT      │ │                                                  │                │
│ │ 58 km/h  │ │                                                  │                │
│ │ 76.8 km  │ │                                                  │                │
│ │ Track 1  │ │                                                  │                │
│ └──────────┘ │                                                  │                │
└──────────────┴──────────────────────────────────────────────────┴────────────────┘
```

## ✨ Key Visual Features

### 1. **Map Always Visible**
- Full CSMT-PUNE route (0-192 km) shown from start
- All 6 stations labeled
- All tracks rendered (2-4 per segment)
- Distance markers every 10-20 km

### 2. **Dynamic Zoom on Scenario Load**
- Map smoothly zooms into active section
- Active section highlighted with blue dashed border
- Zoom level indicator shows percentage
- User can zoom in/out or pan manually

### 3. **Train Visualization**
- Small colored dots ON track lines
- Train ID labels above dots
- Real-time position updates (150ms)
- Hover shows full train details

### 4. **Conflict Detection**
- Red pulsing zone on map
- Alert card in right panel
- Shows conflict type, location, time
- Lists affected trains

### 5. **AI Recommendations**
- Ranked solution cards
- Energy, delay, and score metrics
- Apply button for each solution
- Color-coded by priority

### 6. **Live Updates**
- Clock ticking in navbar
- Live status indicator pulsing
- Trains moving on map
- Graph updating in real-time

## 🎮 Demo Flow

### Step 1: Initial State
- Map shows full route
- No trains visible
- "Select a scenario to begin" message
- All 3 scenario buttons ready

### Step 2: Load Scenario
- Click scenario button
- Map zooms to section (smooth animation)
- Trains appear on tracks
- Left panel shows train list
- Graph starts plotting

### Step 3: Watch Simulation
- Trains move in real-time
- Positions update every 150ms
- Distance-time graph grows
- Energy metrics update

### Step 4: Conflict Detected
- Red zone appears on map
- Alert pops up in right panel
- AI analyzes conflict
- Solutions appear ranked

### Step 5: Review Solutions
- Compare energy vs delay
- Check scores
- Read descriptions
- Apply best solution

## 🎨 Visual Polish

### Colors:
- **Background:** Dark navy (#0a0e1a)
- **Panels:** Slightly lighter (#111827)
- **Tracks:** Gray (#4b5563)
- **Conflict:** Red (#ef4444)
- **Success:** Green (#10b981)
- **Primary:** Blue (#3b82f6)

### Animations:
- Status dot pulsing
- Conflict zone pulsing
- Train movement smooth
- Zoom transitions smooth

### Typography:
- **Headers:** Inter, bold
- **Numbers:** Roboto Mono
- **Body:** Inter, regular

## 🚀 Demo Script

**Presenter says:**

1. "Welcome to NeuralRail Railway Control Room"
2. "Here's the full CSMT-PUNE route - 192 kilometers"
3. "Let's load Scenario 1 - Kalyan to Karjat section"
4. *Click Scenario 1*
5. "Watch the map zoom into the active section"
6. "Two trains on the same track - heading towards each other"
7. "The system detects the conflict in real-time"
8. "Our AI analyzes and recommends solutions"
9. "Solution 1 uses less energy but causes delay"
10. "The operator can choose the best option"

**Result:** Audience sees a professional, working railway control system! 🎉
