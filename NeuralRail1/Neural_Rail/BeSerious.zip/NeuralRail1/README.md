# 🚄 NeuralRail - AI-Assisted Railway Traffic Management

**Smart India Hackathon 2024 - Renewable Energy Domain**

An intelligent railway traffic management system that uses AI to prevent train collisions while optimizing energy consumption on the Mumbai-Pune corridor.

---

## 🎯 Problem Statement

Railway networks face critical challenges:
- Train collisions due to conflicts on shared tracks
- Energy wastage from inefficient conflict resolution
- Complex decision-making under operational constraints
- Need for real-time conflict detection and resolution

---

## 💡 Our Solution

NeuralRail uses AI to:
1. **Detect conflicts** 7-30 minutes in advance
2. **Generate multiple solutions** considering safety, priority, and energy
3. **Recommend optimal actions** that resolve conflicts permanently
4. **Save energy** through smart decision-making (up to 1418 kWh per conflict!)
5. **Explain decisions** in human-readable format for Section Controllers

---

## 🔥 Key Features

### 1. **Conflict Resolution First**
- Prioritizes permanent solutions (stop/switch) over temporary (slow)
- Handles head-on and same-direction conflicts
- Validates track constraints before recommending solutions

### 2. **Gradient-Aware Physics**
- Applies 1200 kWh penalty for stopping heavy trains uphill
- Considers regenerative braking (30% energy recovery)
- Realistic energy calculations based on mass, speed, and gradient

### 3. **Multi-Train Coordination**
- Handles 2-4 trains simultaneously
- Generates multi-step solutions with track switching
- Considers all track occupancy states

### 4. **Smart Priority Management**
- Respects train priorities (Rajdhani > Express > Local > Freight)
- Overrides priority only for MASSIVE energy savings (>1000 kWh)
- Balances operational needs with energy efficiency

### 5. **Real-Time Monitoring**
- Live train position tracking
- Distance-time graphs
- Energy consumption monitoring
- Conflict countdown timers

---

## 📊 Demo Scenarios

### **Scenario 1: Head-On Collision (Kalyan-Karjat)**
- **Conflict:** Rajdhani vs Freight, head-on in 7 minutes
- **Challenge:** Track 2 blocked (rail crack)
- **AI Solution:** Stop Freight (respects priority)
- **Energy:** 363 kWh
- **Result:** Conflict resolved, Rajdhani continues

### **Scenario 2: Multi-Train Coordination (CSMT-Thane)**
- **Conflict:** Vande Bharat catching Local from behind
- **Challenge:** 4 trains on same section, Tracks 1 & 4 occupied
- **AI Solution:** Multi-step track switch to Track 3
- **Energy:** 51 kWh
- **Result:** Permanent resolution, minimal delay (1.5 min)

### **Scenario 3: Bhor Ghat Challenge (KILLER FEATURE!) 🔥**
- **Conflict:** Freight (uphill) vs Express (downhill), head-on
- **Challenge:** Steep 1.83% gradient, Track 1 occupied, Track 3 blocked
- **AI Solution:** Stop Express (downhill)
- **Energy:** 53 kWh
- **Savings:** 1418 kWh! (vs stopping Freight uphill)
- **Result:** Equivalent to powering 284 homes for 1 hour!

---

## 🎯 Results

### **Energy Performance:**
- **Total Energy Used:** 467 kWh (across all scenarios)
- **Total Energy Saved:** 1497 kWh (vs worst alternatives)
- **CO2 Reduction:** ~1228 kg
- **Equivalent:** Powering 299 homes for 1 hour

### **Operational Performance:**
- **Conflict Detection:** 7-30 minutes advance warning
- **Resolution Success:** 100% (all conflicts permanently resolved)
- **Priority Respect:** 67% (override only when justified)
- **Average Delay:** 7.4 minutes per conflict

---

## 🏗️ Architecture

### **Backend (Python)**
```
backend/
├── ai_agent/          # AI explanation system
├── api/               # REST API (Flask)
├── data/              # Railway network data
├── optimizer/         # Conflict resolution engine
├── physics/           # Energy calculations
└── simulation/        # Train simulation
```

### **Frontend (React - ✅ COMPLETE)**
```
frontend/
├── src/
│   ├── components/    # UI components (15+ components)
│   │   ├── Navbar.jsx
│   │   ├── LeftPanel/
│   │   ├── MiddlePanel/
│   │   └── RightPanel/
│   ├── services/      # API integration
│   └── utils/         # Helper functions
├── vite.config.js     # Vite configuration
└── package.json       # Dependencies
```

### **Scenarios**
```
scenarios/
├── scenario_definitions.py  # 3 demo scenarios
├── scenario_runner.py       # Scenario execution
└── test_scenarios.py        # Tests
```

---

## 🚀 Quick Start

### **1. Install Dependencies**
```bash
pip install -r requirements.txt
```

### **2. Test Backend**
```bash
python scenarios/test_scenarios.py
```

Expected output:
```
✓ Scenario 1: Stop FRT (363 kWh)
✓ Scenario 2: Multi-step switch (51 kWh)
✓ Scenario 3: Stop EXP (53 kWh, saves 1418 kWh!)
```

### **3. Install Frontend**
```bash
# Windows
INSTALL_FRONTEND.bat

# Manual
cd frontend
npm install
```

### **4. Start Backend API**
```bash
python backend/api/app.py
# or
START_DEMO.bat
```

API runs on: `http://localhost:5000`

### **5. Start Frontend**
```bash
# Windows
START_FRONTEND.bat

# Manual
cd frontend
npm run dev
```

Frontend runs on: `http://localhost:3000`

### **6. Open Browser**
Navigate to: `http://localhost:3000`

---

## 📡 API Endpoints

### **Scenarios**
- `GET /api/scenarios` - List all scenarios
- `POST /api/scenario/<id>/start` - Start a scenario

### **Simulation**
- `POST /api/simulation/step` - Run simulation step
- `POST /api/conflict/analyze` - Get AI recommendations

### **Explanations**
- `GET /api/conflict/explain/<question>` - Answer questions
- `GET /api/conflict/similar` - Show similar past cases

### **Control**
- `POST /api/train/<id>/control` - Manual train control
- `POST /api/scenario/custom` - Create custom scenario

See `API_DOCUMENTATION.md` for complete details.

---

## 🎓 Technical Details

### **AI Decision Logic**
1. **Safety First:** All solutions must be safe
2. **Conflict Resolution:** Permanent solutions prioritized
3. **Train Priority:** Respect operational priorities
4. **Energy Optimization:** Minimize energy within valid solutions
5. **Exception:** Override priority for MASSIVE savings (>1000 kWh)

### **Physics Engine**
- Kinetic energy calculations
- Braking energy loss (with regenerative recovery)
- Acceleration energy requirements
- Gradient penalties (uphill/downhill)
- Rolling resistance and air drag

### **Energy Calculations**
- **Regenerative Braking:** 30% energy recovery for electric trains
- **Gradient Penalty:** 1200 kWh for stopping heavy trains (>1000 tons) uphill
- **Idle Power:** Varies by train type (45-180 kW)
- **Restart Energy:** Depends on mass, speed, and gradient

---

## 🏆 Competitive Advantages

1. **Realistic Physics:** Based on actual Indian Railways data
2. **Gradient Awareness:** Unique 1200 kWh uphill penalty
3. **Multi-Step Solutions:** Sophisticated track switching logic
4. **Massive Energy Savings:** Up to 1418 kWh per conflict
5. **Judge-Proof:** Every detail explained and justified
6. **Authentic Operations:** Banker engines, landslides, rail cracks

---

## 📚 Documentation

- **`CORRECTED_AI_RECOMMENDATIONS.md`** - Complete AI analysis
- **`API_DOCUMENTATION.md`** - REST API reference
- **`DEMO_GUIDE.md`** - Presentation guide
- **`PROJECT_STRUCTURE.md`** - Project organization
- **`AI_VERIFICATION_SYSTEM.md`** - AI verification details

---

## 🎯 Demo Talking Points

### **For Judges:**

**Opening:**
"NeuralRail is an AI-powered railway traffic management system that prevents collisions while optimizing energy consumption. Let me show you three scenarios..."

**Scenario 1:**
"Here we have a head-on collision between Rajdhani and Freight. Our AI detects it 7 minutes in advance and recommends stopping the lower-priority Freight train, allowing Rajdhani to continue."

**Scenario 2:**
"This shows multi-train coordination with 4 trains. Instead of stopping, our AI uses available Track 3 for switching, providing a permanent resolution with minimal delay."

**Scenario 3 (KILLER!):**
"This is our killer feature. A heavy freight is climbing steep Bhor Ghat when it meets an Express coming downhill. Stopping the freight uphill would waste 1471 kWh. Our AI stops the Express instead, saving 1418 kWh - enough to power 284 homes for an hour!"

**Closing:**
"Across all scenarios, we save 1497 kWh total, equivalent to 1228 kg CO2 reduction. This demonstrates how AI can make railways safer AND more energy-efficient."

---

## 👥 Team

- **Backend Development:** Python, Flask, Physics Engine
- **AI/ML:** Conflict Resolution, Decision Making
- **Frontend:** React, Real-time Visualization (to be built)
- **Domain Expertise:** Indian Railways Operations

---

## 📄 License

This project is developed for Smart India Hackathon 2024.

---

## 🙏 Acknowledgments

- Indian Railways for operational data
- RDSO for technical specifications
- Mumbai Railway Vikas Corporation for route information

---

**Status:** ✅ Backend Complete | ✅ Frontend Complete | ✅ Demo Ready  
**Total Components:** 15+ React components, 10+ API endpoints  
**Features:** Real-time tracking, AI recommendations, energy optimization  
**SIH 2024 - Renewable Energy Domain**

---

## 🎨 Frontend Features

### Core Features
- ✅ **3-Panel Control Room Layout** - Professional monitoring interface
- ✅ **Real-Time Train Tracking** - 150ms updates with smooth animations
- ✅ **Live Track Visualization** - Animated train markers on horizontal tracks
- ✅ **Distance-Time Graphs** - Recharts visualization with conflict markers
- ✅ **Conflict Detection Alerts** - Visual + audio warnings with countdown
- ✅ **AI Recommendations** - Solution cards with energy/delay metrics
- ✅ **Playback Controls** - Play/pause, speed control (1x-10x)

### Standout Features 🔥
- 🎨 **Dark Control Room Theme** - Professional aesthetic
- 📊 **Elevation Profile** - Shows gradient impact (Bhor Ghat)
- 💰 **Energy Savings Meter** - CO₂ and homes powered calculations
- 🔊 **Sound Alerts** - Audio notifications for conflicts
- ⚡ **Live Energy Gauge** - Visual consumption tracking
- 🎯 **Priority Indicators** - Star ratings for trains
- 🌡️ **Gradient Badges** - Uphill/downhill indicators
- 📈 **Smooth Animations** - Professional transitions
- 🚨 **Conflict Countdown** - Dramatic timer with progress bar
- 🏆 **Killer Feature Badge** - Highlights 1418 kWh savings

See `FRONTEND_COMPLETE.md` for detailed documentation.
