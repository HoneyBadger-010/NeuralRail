﻿# Demo Scenarios for NeuralRail
# Route: CSMT (0km) → Thane (34km) → Kalyan (54km) → Karjat (80km) → Lonavala (106km) → Pune (192km)

SCENARIO_1 = {
    "id": "s1",
    "name": "Head-On Collision - Priority Conflict",
    "description": "Rajdhani from CSMT vs Freight from Kalyan - collision in Thane-Kalyan section (Track 2 occupied by MEMO)",
    "trains": [
        # ============================================================
        # SCENARIO 1: HEAD-ON COLLISION IN THANE-KALYAN SECTION
        # ============================================================
        # 
        # STORY:
        # - RAJ (Rajdhani) just left CSMT, now at 5 km, heading to Pune on Track 1
        # - FRT (Freight) left Kalyan, now at 52 km, heading to CSMT on Track 1
        # - Both will enter Thane-Kalyan section (34-54 km) which has only 2 tracks
        # - Track 2 is OCCUPIED by MEMO (local train)
        # - So both RAJ and FRT must use Track 1 → HEAD-ON COLLISION!
        #
        # CONFLICT ZONE: Thane-Kalyan section (34 km to 54 km)
        # 
        # CALCULATION:
        # - RAJ position: 5 km, Speed: 100 km/h, Direction: Forward (→)
        # - FRT position: 52 km, Speed: 50 km/h, Direction: Backward (←)
        # - Distance between: 52 - 5 = 47 km
        # - Closing speed: 100 + 50 = 150 km/h (head-on)
        # - Time to collision: 47 / 150 hours = 0.313 hours = 18.8 minutes
        # - Collision point: RAJ travels (100 × 0.313) = 31.3 km → 5 + 31.3 = 36.3 km
        #   (This is in Thane-Kalyan section, between 34-54 km) ✓
        #
        # CONFLICT DETECTION TIMING:
        # - We want conflict to be detected when RAJ ~32 km and FRT ~40 km
        # - At that point, distance = 40 - 32 = 8 km
        # - Time to collision from detection = 8 / 150 × 60 = 3.2 minutes
        # - Time for RAJ to reach 32 km: (32-5)/100 × 60 = 16.2 minutes of demo time!
        #
        # AI SOLUTION:
        # - Stop FRT at Thane Junction (34 km) - Thane has 10 platforms
        # - Let RAJ pass through on Track 1
        # - Then FRT can proceed to CSMT
        # ============================================================
        
        # === MAIN CONFLICT TRAINS ===
        {
            "train_id": "RAJ",
            "train_type": "rajdhani",
            "initial_position_km": 15,  # In CSMT-Thane section (4 tracks)
            "initial_speed_kmh": 100,   # Full speed
            "destination_km": 192,      # Going to Pune
            "direction": "forward",
            "initial_track": 1,         # Track 1 - will continue to Track 1 after Thane
            "color": "#FF4444"          # Red for Rajdhani
        },
        {
            "train_id": "FRT",
            "train_type": "freight_heavy",
            "initial_position_km": 55,  # Just past Kalyan (54 km), in Kalyan-Karjat section
            "initial_speed_kmh": 50,    # Slow heavy freight
            "destination_km": 0,        # Going to CSMT
            "direction": "backward",
            "initial_track": 1,         # Track 1 - HEAD-ON with RAJ!
            "color": "#8B4513"          # Brown for Freight
        },
        
        # === BACKGROUND TRAINS IN CSMT-KALYAN SECTION ===
        {
            "train_id": "MEMO",
            "train_type": "local_emu",
            "initial_position_km": 45,  # In Thane-Kalyan section - BLOCKS Track 2!
            "initial_speed_kmh": 60,
            "destination_km": 54,       # Going to Kalyan
            "direction": "forward",
            "initial_track": 2,         # Track 2 - THIS IS WHY RAJ/FRT CAN'T SWITCH!
            "color": "#9370DB",
            "status": "normal_operation",
            "description": "Local EMU Thane to Kalyan - OCCUPIES Track 2"
        },
        {
            "train_id": "LOC1",
            "train_type": "local_emu",
            "initial_position_km": 8,   # CSMT-Thane section (different from RAJ)
            "initial_speed_kmh": 80,
            "destination_km": 34,       # Going to Thane
            "direction": "forward",
            "initial_track": 3,         # Track 3 (4-track section only)
            "color": "#4169E1",
            "status": "normal_operation",
            "description": "Local EMU CSMT to Thane on Track 3"
        },
        {
            "train_id": "LOC2",
            "train_type": "local_emu",
            "initial_position_km": 25,  # CSMT-Thane section
            "initial_speed_kmh": 75,
            "destination_km": 0,        # Going to CSMT
            "direction": "backward",
            "initial_track": 4,         # Track 4 (4-track section only)
            "color": "#87CEEB",
            "status": "normal_operation",
            "description": "Local EMU return to CSMT on Track 4"
        },
        
        # === BACKGROUND TRAINS BEYOND KALYAN (showing full network activity) ===
        {
            "train_id": "EXP1",
            "train_type": "express_passenger",
            "initial_position_km": 90,  # Karjat-Lonavala section (Bhor Ghat)
            "initial_speed_kmh": 60,    # Slower due to ghat section
            "destination_km": 192,      # Going to Pune
            "direction": "forward",
            "initial_track": 1,
            "color": "#32CD32",
            "status": "normal_operation",
            "description": "Express climbing Bhor Ghat towards Pune"
        },
        {
            "train_id": "FRT2",
            "train_type": "freight_heavy",
            "initial_position_km": 150, # Lonavala-Pune section
            "initial_speed_kmh": 70,
            "destination_km": 192,      # Going to Pune
            "direction": "forward",
            "initial_track": 2,
            "color": "#A0522D",
            "status": "normal_operation",
            "description": "Freight heading to Pune on Track 2"
        },
        {
            "train_id": "LOC3",
            "train_type": "local_emu",
            "initial_position_km": 70,  # Kalyan-Karjat section
            "initial_speed_kmh": 65,
            "destination_km": 80,       # Going to Karjat
            "direction": "forward",
            "initial_track": 2,
            "color": "#20B2AA",
            "status": "normal_operation",
            "description": "Local EMU Kalyan to Karjat"
        }
    ],
    "section": "Thane-Kalyan (2 tracks, Track 2 occupied by MEMO)",
    "track_info": {
        "parallel_tracks_available": False,  # Track 2 is occupied by MEMO
        "switching_possible": False,
        "tracks": 2,  # Conflict section has 2 tracks
        "section_start_km": 34,  # Thane
        "section_end_km": 54,    # Kalyan
        "gradient": "flat",
        
        # Track status in Thane-Kalyan section (34-54 km)
        "track_1_status": "CONFLICT",
        "track_1_details": "RAJ (→) and FRT (←) both on Track 1 - HEAD-ON COLLISION IMMINENT",
        "track_2_status": "OCCUPIED",
        "track_2_details": "MEMO (Local EMU) at 45 km, moving towards Kalyan at 60 km/h",
        
        # Thane Junction info (solution point)
        "thane_junction": {
            "location_km": 34,
            "platforms": 10,
            "can_hold_freight": True,
            "description": "Thane Junction has 10 platforms - FRT can be held here"
        },
        
        "ai_options": [
            "Stop FRT at Thane Junction (34 km) - hold on platform, let RAJ pass",
            "Stop RAJ before Thane - let FRT pass first (NOT recommended - priority violation)",
            "Slow both trains to buy time for MEMO to clear Track 2"
        ]
    },
    "conflict_calculation": {
        "raj_position": 15,
        "frt_position": 55,
        "distance_between": 40,   # 55 - 15 = 40 km
        "raj_speed": 100,
        "frt_speed": 50,
        "closing_speed": 150,     # 100 + 50 = 150 km/h (head-on collision)
        "time_to_conflict_hours": 0.267,  # 40 / 150 = 0.267 hours
        "time_to_conflict_minutes": 16,   # 0.267 × 60 = 16 minutes
        "raj_travel_distance": 26.7,      # 100 × 0.267 = 26.7 km
        "collision_position": 41.7,       # 15 + 26.7 = 41.7 km (in Thane-Kalyan section!)
        "formula": "Time = Distance / Closing_Speed = 40km / 150km/h = 16 min",
        # When conflict is detected (RAJ ~32km, FRT ~45km):
        "detection_raj_position": 32,
        "detection_frt_position": 45,
        "detection_distance": 13,         # 45 - 32 = 13 km apart
        "time_after_detection": 5.2       # 13 / 150 × 60 = 5.2 min to collision
    },
    "judge_points": [
        "Long demo time before conflict detection",
        "Detects conflict when trains are ~11 km apart",
        "Only ~4.4 minutes to collision after detection - URGENT!",
        "Collision point at 41 km (Thane-Kalyan section)",
        "Track 2 occupied by MEMO - no track switching possible",
        "Respects priorities: RAJ (Priority 1) > FRT (Priority 5)",
        "AI recommends: Stop FRT at Thane Junction (10 platforms available)",
        "Shows full network activity with trains beyond Kalyan"
    ]
}

SCENARIO_2 = {
    "id": "s2",
    "name": "Multi-Train Coordination - Parallel Tracks",
    "description": "Fast Vande Bharat catching slower Local on CSMT-Thane section",
    "trains": [
        {
            "train_id": "VB",
            "train_type": "vande_bharat",
            "initial_position_km": 5,  # Adjusted for conflict timing
            "initial_speed_kmh": 100,  # Section max speed (SEG_1)
            "destination_km": 54,
            "direction": "forward",
            "initial_track": 2,  # Track 2 of 4
            "target_track": 3,   # Will switch to Track 3
            "color": "#FFD700"  # Gold for Vande Bharat
        },
        {
            "train_id": "LOC",
            "train_type": "local_emu",
            "initial_position_km": 11,  # Adjusted for conflict timing
            "initial_speed_kmh": 90,
            "destination_km": 54,
            "direction": "forward",
            "initial_track": 2,  # Same track - conflict!
            "target_track": 2,   # Stays on Track 2
            "color": "#4169E1"  # Blue for Local
        },
        {
            "train_id": "MEMO",
            "train_type": "local_emu",
            "initial_position_km": 18,
            "initial_speed_kmh": 85,
            "destination_km": 54,
            "direction": "forward",
            "initial_track": 1,  # Occupies Track 1
            "color": "#87CEEB",  # Light blue
            "status": "normal_operation"
        },
        {
            "train_id": "FRT2",
            "train_type": "freight_heavy",
            "initial_position_km": 25,
            "initial_speed_kmh": 50,
            "destination_km": 54,
            "direction": "forward",
            "initial_track": 4,  # Occupies Track 4
            "color": "#A0522D",  # Sienna brown
            "status": "normal_operation"
        }
    ],
    "section": "CSMT-Thane (4 tracks, flat)",
    "track_info": {
        "parallel_tracks_available": True,
        "num_parallel_tracks": 4,
        "tracks": 4,
        "section_start_km": 0,
        "section_end_km": 34,
        "gradient": "flat",
        "track_1_status": "OCCUPIED",
        "track_1_details": "Local MEMO at 18 km, moving forward at 85 km/h",
        "track_2_status": "OCCUPIED",
        "track_2_details": "VB and LOC (conflict here)",
        "track_3_status": "AVAILABLE",
        "track_3_details": "Free for switching - VB can move here",
        "track_4_status": "OCCUPIED",
        "track_4_details": "Freight FRT2 at 25 km, moving forward at 50 km/h",
        "available_for_switch": [3],
        "switching_possible": True
    },
    "conflict_calculation": {
        "distance_between": 6,   # 11 - 5 = 6 km
        "closing_speed": 10,     # 100 - 90 = 10 km/h (same direction, adjusted speeds)
        "time_to_conflict": 36,  # 6/10 * 60 = 36 minutes
        "conflict_position": 11  # VB catches LOC at 11 km
    },
    "judge_points": [
        "Multi-step solution",
        "Track switching to Track 3 (only free track)",
        "Tracks 1 & 4 occupied by other trains",
        "Permanent resolution"
    ]
}

SCENARIO_3 = {
    "id": "s3",
    "name": "Bhor Ghat Challenge - KILLER FEATURE",
    "description": "Heavy freight climbing Bhor Ghat (Karjat-Lonavala) - MASSIVE energy savings!",
    "trains": [
        {
            "train_id": "FRT",
            "train_type": "freight_heavy",
            "initial_position_km": 83,  # Adjusted for conflict timing
            "initial_speed_kmh": 50,
            "destination_km": 106,
            "direction": "forward",
            "initial_track": 2,  # Track 2 of 3
            "gradient_status": "uphill",  # Climbing steep gradient
            "color": "#8B4513"  # Brown for Freight
        },
        {
            "train_id": "EXP",
            "train_type": "express_passenger",
            "initial_position_km": 100,  # Adjusted for conflict timing
            "initial_speed_kmh": 60,  # Section max speed (SEG_4 - Bhor Ghat)
            "destination_km": 80,
            "direction": "backward",
            "initial_track": 2,  # Same track - conflict!
            "gradient_status": "downhill",  # Descending
            "color": "#32CD32"  # Green for Express
        },
        {
            "train_id": "BANKER",
            "train_type": "freight_heavy",
            "initial_position_km": 95,
            "initial_speed_kmh": 40,
            "destination_km": 80,
            "direction": "backward",
            "initial_track": 1,  # Occupies Track 1
            "gradient_status": "downhill",
            "color": "#808080",  # Gray for banker
            "status": "banker_returning",
            "description": "Banker engine returning after assisting heavy freight to Lonavala"
        }
    ],
    "section": "Karjat-Lonavala (Bhor Ghat - 3 tracks, steep uphill 1.83%)",
    "track_info": {
        "parallel_tracks_available": False,
        "tracks": 3,
        "section_start_km": 80,
        "section_end_km": 106,
        "gradient": "steep_uphill",
        "elevation_gain": 475,
        "gradient_percent": 1.83,
        "FRT_gradient": "uphill",
        "EXP_gradient": "downhill",
        "max_speed_kmh": 60,
        "track_1_status": "OCCUPIED",
        "track_1_details": "Banker engine returning from Lonavala at 95 km, 40 km/h",
        "track_1_note": "Banker engines assist heavy trains uphill, then return on Track 1",
        "track_2_status": "OCCUPIED",
        "track_2_details": "FRT and EXP (conflict here)",
        "track_3_status": "BLOCKED",
        "track_3_details": "Emergency maintenance - Landslide debris removal at 88 km",
        "track_3_incident": {
            "type": "landslide_debris",
            "location_km": 88,
            "severity": "high",
            "clearance_time": "4 hours",
            "crew_present": True,
            "equipment": "JCB excavator on track"
        },
        "switching_possible": False
    },
    "conflict_calculation": {
        "distance_between": 17,  # 100 - 83 = 17 km
        "closing_speed": 110,    # 50 + 60 = 110 km/h (adjusted speeds)
        "time_to_conflict": 9.3, # 17/110 * 60 = 9.3 minutes
        "conflict_position": 89  # Middle of steep ghat
    },
    "priority_note": "AI recommends stopping higher-priority Express to avoid massive energy waste (1365 kWh) from stopping heavy freight uphill. Priority is considered, but extreme energy savings justify the decision.",
    "judge_points": [
        "1365 kWh savings!",
        "Gradient-aware physics",
        "Track 1: Banker engine (realistic ghat operation)",
        "Track 3: Landslide debris (common in ghat sections)",
        "No track switching possible",
        "Real Bhor Ghat (1.83% gradient)",
        "Smart priority trade-off"
    ]
}

ALL_SCENARIOS = [SCENARIO_1, SCENARIO_2, SCENARIO_3]

def get_scenario_by_index(index):
    return ALL_SCENARIOS[index - 1] if 1 <= index <= len(ALL_SCENARIOS) else None

def list_scenarios():
    print("\n" + "="*70)
    print("AVAILABLE DEMO SCENARIOS")
    print("="*70)
    for i, s in enumerate(ALL_SCENARIOS, 1):
        print(f"\n{i}. {s['name']}")
        print(f"   {s['description']}")
    print("="*70)

if __name__ == "__main__":
    print(f"Loaded {len(ALL_SCENARIOS)} scenarios")
    list_scenarios()
