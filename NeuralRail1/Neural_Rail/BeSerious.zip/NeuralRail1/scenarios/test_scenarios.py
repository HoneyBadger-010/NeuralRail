"""
Quick test of scenario system
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'backend'))

from scenario_runner import ScenarioRunner
from scenario_definitions import get_scenario_by_index


def test_scenario_1():
    """Test Scenario 1: Head-On Collision"""
    print("Testing Scenario 1: Head-On Collision")
    print("="*70)
    
    runner = ScenarioRunner()
    scenario = get_scenario_by_index(1)
    
    result = runner.run_scenario(scenario, verbose=True)
    
    if result:
        print("\n✓ Scenario 1 completed successfully!")
        print(f"  Energy saved: {result['energy_saved_kwh']:.1f} kWh")
        print(f"  Best solution: {result['best_solution']['action']}")
    else:
        print("\n⚠️  Scenario 1 failed")


def test_scenario_3():
    """Test Scenario 3: Ghat Section (The killer feature!)"""
    print("\n\nTesting Scenario 3: Ghat Section")
    print("="*70)
    print("This is your KILLER FEATURE - massive energy savings!")
    
    runner = ScenarioRunner()
    scenario = get_scenario_by_index(3)
    
    result = runner.run_scenario(scenario, verbose=True)
    
    if result:
        print("\n✓ Scenario 3 completed successfully!")
        print(f"  Energy saved: {result['energy_saved_kwh']:.1f} kWh")
        
        if result['energy_saved_kwh'] > 1000:
            print(f"\n  🔥🔥🔥 MASSIVE SAVINGS! This will impress judges! 🔥🔥🔥")


if __name__ == "__main__":
    test_scenario_1()
    test_scenario_3()
    
    print("\n" + "="*70)
    print("✓ Scenario tests completed!")
    print("="*70)
    print("\nTo run interactive demo:")
    print("  python scenario_runner.py")
