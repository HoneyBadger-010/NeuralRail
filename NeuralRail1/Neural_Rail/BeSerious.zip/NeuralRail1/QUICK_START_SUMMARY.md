# ⚡ NeuralRail - Quick Start Summary

**Get up and running in 5 minutes!**

---

## 🚀 Installation (One-Time Setup)

### Step 1: Install Backend Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Install Frontend Dependencies
```bash
# Windows
INSTALL_FRONTEND.bat

# Or manually
cd frontend
npm install
```

---

## ▶️ Running the System

### Start Backend (Terminal 1)
```bash
# Windows
START_DEMO.bat

# Or manually
python backend/api/app.py
```
✅ Backend running on: `http://localhost:5000`

### Start Frontend (Terminal 2)
```bash
# Windows
START_FRONTEND.bat

# Or manually
cd frontend
npm run dev
```
✅ Frontend running on: `http://localhost:3000`

### Open Browser
Navigate to: `http://localhost:3000`

---

## 🎯 Quick Demo (2 Minutes)

1. **Select Scenario 3** (Bhor Ghat - Killer Feature)
2. **Click Play** - Watch trains move
3. **Wait for Conflict** - Alert appears in ~8 minutes (simulation time)
4. **See AI Recommendation** - "Stop EXP" solution
5. **Check Energy Savings** - **1418 kWh saved!** 🔥

---

## 📊 What You'll See

### Left Panel
- 3 scenario cards
- Playback controls (play/pause/speed)
- Live train status cards

### Middle Panel
- Live track view with train markers
- Elevation profile (Scenario 3)
- Distance-time graph

### Right Panel
- Conflict alert with countdown
- AI recommendations
- Energy savings meter

---

## 🔥 Killer Feature (Scenario 3)

**The Highlight:**
- Heavy 4200-ton freight climbing steep 1.83% gradient
- Meets Express coming downhill
- AI stops Express instead of freight
- **Saves 1418 kWh** (96.4% reduction!)
- Equivalent to powering **284 homes for 1 hour**
- **1228 kg CO₂ saved**

---

## 🎬 Demo Script (30 Seconds)

"This is Scenario 3 - our killer feature. A heavy freight is climbing steep Bhor Ghat when it meets an Express. Stopping the freight uphill would waste 1471 kWh. Our AI stops the Express instead, using only 53 kWh. This saves 1418 kWh - enough to power 284 homes for an hour!"

---

## 🐛 Quick Troubleshooting

**Backend won't start?**
```bash
pip install -r requirements.txt
python backend/api/app.py
```

**Frontend won't start?**
```bash
cd frontend
npm install
npm run dev
```

**No data showing?**
- Check backend is running: `http://localhost:5000/api/health`
- Refresh browser
- Check console for errors

---

## 📚 Documentation

- `README.md` - Project overview
- `COMPLETE_SYSTEM_GUIDE.md` - Full system documentation
- `FRONTEND_COMPLETE.md` - Frontend details
- `FRONTEND_VISUAL_GUIDE.md` - UI/UX guide
- `API_DOCUMENTATION.md` - API reference

---

## ✅ Pre-Demo Checklist

- [ ] Backend running (port 5000)
- [ ] Frontend running (port 3000)
- [ ] Browser open to localhost:3000
- [ ] Scenario 3 tested
- [ ] Energy savings showing correctly
- [ ] No console errors

---

## 🏆 Key Talking Points

1. **Real-time monitoring** - 150ms updates
2. **AI-powered recommendations** - Smart conflict resolution
3. **Gradient-aware physics** - 1200 kWh uphill penalty
4. **Massive energy savings** - 1418 kWh in Scenario 3
5. **Environmental impact** - 1228 kg CO₂ reduction

---

**Status:** ✅ Complete and Demo-Ready  
**Time to Start:** 5 minutes  
**Time to Demo:** 8 minutes  

🚀 **READY TO IMPRESS!**
