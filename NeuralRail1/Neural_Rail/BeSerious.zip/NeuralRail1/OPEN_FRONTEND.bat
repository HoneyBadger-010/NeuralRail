@echo off
echo ========================================
echo Opening NeuralRail Frontend
echo ========================================
echo.
echo Backend is running on: http://localhost:5000
echo Opening frontend in your default browser...
echo.

cd frontend
start index.html

echo.
echo ========================================
echo Frontend opened!
echo ========================================
echo.
echo What you should see:
echo - Map with scrollbars
echo - Scroll left: 18 CSMT platforms
echo - Scroll right: Complete route to Pune
echo - All 5 stations at top
echo - Color-coded tracks
echo.
echo Click a scenario to test train movement!
echo ========================================
pause
