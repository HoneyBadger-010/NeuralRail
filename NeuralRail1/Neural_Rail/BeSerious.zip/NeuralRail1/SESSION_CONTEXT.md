# NeuralRail - Session Context for Continuation

## Project Overview
**NeuralRail** is an AI-Assisted Railway Traffic Management System for Smart India Hackathon 2024 (Renewable Energy Domain). It prevents train collisions while optimizing energy consumption on the Mumbai-Pune corridor (192 km).

## Architecture

### Backend (Python/Flask - Port 5000)
```
backend/
├── api/app.py              # REST API server
├── simulation/
│   ├── railway_simulator.py # Train simulation engine
│   └── train.py            # Train class with movement physics
├── optimizer/
│   └── conflict_resolver.py # AI conflict resolution
├── physics/
│   └── energy_calculator.py # Energy calculations
├── ai_agent/
│   └── llm_explainer.py    # AI decision explanations
└── data/
    └── railway_network.py  # Mumbai-Pune route data
```

### Frontend (Vanilla JS - Port 3000)
```
frontend/
├── index.html    # Single-page control room interface
├── app.js        # Main application logic (~1800 lines)
├── styles.css    # Dark control room theme
└── package.json  # Uses 'serve' package
```

### Scenarios
```
scenarios/
└── scenario_definitions.py  # 3 demo scenarios with train configs
```

## Route Data
```
CSMT (0km) → Thane (34km) → Kalyan (54km) → Karjat (80km) → Lonavala (106km) → Pune (192km)

Sections:
- CSMT-Thane: 4 tracks, suburban
- Thane-Kalyan: 2 tracks, mainline
- Kalyan-Karjat: 2 tracks + sidings, gentle uphill
- Bhor Ghat: 3 tracks, steep 1.83% gradient
- Lonavala-Pune: 2 tracks, mainline
```

## Current Scenario 1 Configuration

### Train Positions (Far Apart for Demo Time)
| Train | Position | Speed | Direction | Track |
|-------|----------|-------|-----------|-------|
| RAJ | 55 km | 80 km/h | Forward | 1 |
| FRT | 79 km | 40 km/h | Backward | 1 |
| LOC1 | 10 km | 60 km/h | Forward | 2 |
| LOC2 | 25 km | 55 km/h | Backward | 3 |
| EXP1 | 120 km | 70 km/h | Forward | 1 |
| MEMO | 38 km | 50 km/h | Forward | 2 |

### Conflict Calculation
- Distance: 24 km (79 - 55)
- Closing speed: 120 km/h (80 + 40)
- Time to conflict: 12 minutes
- Conflict position: ~67 km

### Track Info (Kalyan-Karjat Section)
- Track 1: OCCUPIED (RAJ & FRT - conflict)
- Track 2: BLOCKED (rail crack at 68 km)
- **Siding A**: 60 km, available (Kalyan side)
- **Siding B**: 74 km, available (Karjat side)

## Key Frontend Configuration (app.js)

### CONFIG
```javascript
const CONFIG = {
  API_BASE: 'http://localhost:5000/api',
  UPDATE_INTERVAL: 800,    // Slower for realistic movement
  ANIMATION_DURATION: 800,
};
```

### State
```javascript
conflictDetectionDelay: 15000,  // 15 seconds before showing conflict
playbackSpeed: 1               // Adjustable via UI (0.5x, 1x, 2x, 5x)
```

## UI Features Implemented

### Header (Navbar)
- Logo + Title
- Corridor info (CSMT-PUNE 192 km)
- Scenario selector dropdown + Run button
- **Playback controls** (Pause/Resume + Speed buttons: 0.5x, 1x, 2x, 5x)
- Connection status indicator
- Clock

### Main Content
1. **Track Schematic** (top)
   - Full route SVG visualization
   - Section focus selector
   - Train markers with direction arrows
   - Station markers
   - **Sidings rendered in amber** at 60 km and 74 km
   - Blocked track indicators

2. **Bottom Split**
   - **Time-Space Graph** (60%) - Canvas-based, shows train movement over time
   - **AI Recommendations Panel** (40%) - Shows conflict solutions

### Control Bar (Bottom)
- Train status cards (position, speed, destination)
- Energy metrics (consumed, saved, CO₂)
- AI Performance metrics
- Decision log

## CSS Key Classes
- `.train-marker { transition: transform 0.8s linear; }` - Smooth train movement
- `.playback-nav` - Navbar playback controls
- `.speed-btn-nav.active` - Active speed button highlight
- Sidings rendered in amber (#ffb800)

## Backend Conflict Detection
- Lookahead: 1800 seconds (30 minutes)
- Conflict threshold: 2 km between trains
- Detects immediately but frontend delays showing for 15 seconds

## How to Run
```bash
# Terminal 1 - Backend
python backend/api/app.py

# Terminal 2 - Frontend
cd frontend
npm start

# Open browser
http://localhost:3000
```

## Recent Changes Made This Session

1. **Removed speed labels** from train markers on track schematic
2. **Added playback controls** to navbar (moved from bottom panel)
3. **Slowed down train movement** (UPDATE_INTERVAL: 800ms)
4. **Increased conflict detection delay** to 15 seconds
5. **Added 4 background trains** to Scenario 1 (LOC1, LOC2, EXP1, MEMO)
6. **Added sidings** to Kalyan-Karjat section (60 km and 74 km)
7. **Sidings now render visually** on track schematic in amber
8. **Trains positioned further apart** (24 km) for more demo time
9. **Added margin** between AI panel and bottom control bar

## Pending/Known Issues
- Sidings are visual only - AI doesn't actually route trains to them yet
- Graph lines may still be short if simulation runs briefly
- Train movement smoothness depends on browser performance

## Files Modified This Session
- `frontend/app.js` - Playback controls, sidings rendering, timing
- `frontend/index.html` - Playback controls in navbar
- `frontend/styles.css` - Playback styles, margins, transitions
- `scenarios/scenario_definitions.py` - Train positions, sidings data

## Next Steps to Consider
1. Make AI actually recommend siding routes
2. Add visual conflict zone on track schematic
3. Improve graph visualization
4. Add sound effects for conflict alerts
5. Test all 3 scenarios thoroughly
