# 🎨 NeuralRail Frontend - Visual Guide

**A tour of the control room interface**

---

## 🖥️ Main Interface Layout

```
┌─────────────────────────────────────────────────────────────────────────┐
│  🚄 NeuralRail Control Room    ●LIVE    14:32:15 IST    Balanced Mode  │
├──────────────────┬──────────────────────────────┬───────────────────────┤
│                  │                              │                       │
│  LEFT PANEL      │      MIDDLE PANEL            │    RIGHT PANEL        │
│  (30%)           │      (50%)                   │    (20%)              │
│                  │                              │                       │
│ ┌──────────────┐ │  ┌────────────────────────┐ │  ┌─────────────────┐ │
│ │ SCENARIO 1   │ │  │  LIVE TRACK VIEW       │ │  │ ⚠️ CONFLICT     │ │
│ │ Head-On      │ │  │                        │ │  │ DETECTED        │ │
│ │ Collision    │ │  │  CSMT ──●──●──→ PUNE  │ │  │                 │ │
│ └──────────────┘ │  │                        │ │  │ RAJ ↔ FRT       │ │
│                  │  │  Track 1: ━━━━━━━━━━  │ │  │ At 68.9 km      │ │
│ ┌──────────────┐ │  │  Track 2: 🚧 BLOCKED  │ │  │ In 7:00 min     │ │
│ │ SCENARIO 2   │ │  └────────────────────────┘ │  └─────────────────┘ │
│ │ Multi-Train  │ │                              │                       │
│ │ Coordination │ │  ┌────────────────────────┐ │  ┌─────────────────┐ │
│ └──────────────┘ │  │  ELEVATION PROFILE     │ │  │ AI RECOMMEND    │ │
│                  │  │                        │ │  │                 │ │
│ ┌──────────────┐ │  │      ⛰️ 1.83%         │ │  │ ⭐ Stop FRT     │ │
│ │ SCENARIO 3   │ │  │     ╱                 │ │  │ 363 kWh         │ │
│ │ 🔥 KILLER    │ │  │   ╱                   │ │  │ 10 min delay    │ │
│ └──────────────┘ │  └────────────────────────┘ │  │ ✓ Priority OK   │ │
│                  │                              │  │ [APPLY]         │ │
│ ▶️ PLAY  🔄 RESET│  ┌────────────────────────┐ │  └─────────────────┘ │
│ Speed: [1x] 2x   │  │  DISTANCE-TIME GRAPH   │ │                       │
│        5x  10x   │  │                        │ │  ┌─────────────────┐ │
│                  │  │  Distance              │ │  │ 💰 ENERGY SAVED │ │
│ ┌──────────────┐ │  │    │    ╱ RAJ         │ │  │                 │ │
│ │ RAJ  ●LIVE   │ │  │  80├──╱──╲            │ │  │ 1418 kWh        │ │
│ │ 100 km/h     │ │  │    │      ╲ FRT        │ │  │ 🔥 KILLER!      │ │
│ │ ████████░░   │ │  │  60├───────╲          │ │  │                 │ │
│ │ 56.0 km      │ │  │    │         ╲         │ │  │ 🌱 1228 kg CO₂  │ │
│ │ ████████░░   │ │  │    └──────────────     │ │  │ 🏠 284 homes    │ │
│ │ → Karjat     │ │  │         Time (min)     │ │  └─────────────────┘ │
│ │ ETA: 15:02   │ │  └────────────────────────┘ │                       │
│ │              │ │                              │                       │
│ │ Track: 1     │ │                              │                       │
│ │ Priority: ⭐⭐│ │                              │                       │
│ │ Energy: 125  │ │                              │                       │
│ │ Mass: 850t   │ │                              │                       │
│ └──────────────┘ │                              │                       │
│                  │                              │                       │
│ ┌──────────────┐ │                              │                       │
│ │ FRT  ●LIVE   │ │                              │                       │
│ │ 60 km/h      │ │                              │                       │
│ │ ⛰️ UPHILL    │ │                              │                       │
│ │ ...          │ │                              │                       │
│ └──────────────┘ │                              │                       │
└──────────────────┴──────────────────────────────┴───────────────────────┘
```

---

## 🎨 Color Scheme

### Background Colors
- **Dark Background:** `#0a0e1a` - Deep navy
- **Panel Background:** `#111827` - Dark gray
- **Card Background:** `#1f2937` - Medium gray

### Accent Colors
- **Blue:** `#3b82f6` - Primary actions, recommended solutions
- **Red:** `#ef4444` - Conflicts, danger, live indicators
- **Green:** `#10b981` - Success, energy savings
- **Yellow:** `#f59e0b` - Warnings, killer feature badge
- **Purple:** `#8b5cf6` - Gradients, special effects

### Train Colors
- **Rajdhani:** `#ef4444` (Red) 🔴
- **Freight:** `#92400e` (Brown) 🟤
- **Vande Bharat:** `#fbbf24` (Gold) 🟡
- **Local EMU:** `#3b82f6` (Blue) 🔵
- **Express:** `#10b981` (Green) 🟢

---

## 📱 Component Breakdown

### 1. Navbar (Top Bar)
```
┌─────────────────────────────────────────────────────────────┐
│ 🚄 NeuralRail Control Room  │  ●LIVE  │  14:32:15 IST  │ 🔊 │
└─────────────────────────────────────────────────────────────┘
```
- Logo with gradient text
- Pulsing red "LIVE" indicator
- Real-time clock (updates every second)
- Sound toggle button

---

### 2. Left Panel - Scenario Selector
```
┌──────────────────────────────┐
│ SCENARIO SELECTION           │
├──────────────────────────────┤
│ ┌──────────────────────────┐ │
│ │ ① Scenario 1             │ │
│ │ Head-On Collision        │ │
│ │ Rajdhani vs Freight on   │ │
│ │ Kalyan-Karjat section    │ │
│ └──────────────────────────┘ │
│                              │
│ ┌──────────────────────────┐ │
│ │ ② Scenario 2             │ │
│ │ Multi-Train Coordination │ │
│ │ Fast Vande Bharat        │ │
│ │ catching slower Local    │ │
│ └──────────────────────────┘ │
│                              │
│ ┌──────────────────────────┐ │
│ │ ③ Scenario 3  🔥 KILLER  │ │
│ │ Bhor Ghat Challenge      │ │
│ │ Heavy freight climbing   │ │
│ │ steep gradient           │ │
│ └──────────────────────────┘ │
└──────────────────────────────┘
```

---

### 3. Left Panel - Playback Controls
```
┌──────────────────────────────┐
│ PLAYBACK CONTROLS            │
├──────────────────────────────┤
│ ┌─────────┐  ┌─────────────┐ │
│ │ ▶️ PLAY │  │ 🔄 RESET    │ │
│ └─────────┘  └─────────────┘ │
│                              │
│ Playback Speed               │
│ ┌───┬───┬───┬───┐           │
│ │1x │2x │5x │10x│           │
│ └───┴───┴───┴───┘           │
└──────────────────────────────┘
```

---

### 4. Left Panel - Train Status Card
```
┌──────────────────────────────┐
│ RAJ              ●LIVE       │
├──────────────────────────────┤
│ 100 km/h                     │
│ ████████████░░░░░░░░ 75%     │
│                              │
│ Position: 56.0 km            │
│ ████████████████░░░░ 80%     │
│                              │
│ → Karjat        ETA: 15:02   │
│                              │
│ ⛰️ UPHILL                    │
│                              │
│ Track: 1      Priority: ⭐⭐  │
│ Energy: 125   Mass: 850t     │
└──────────────────────────────┘
```

---

### 5. Middle Panel - Live Track View
```
┌────────────────────────────────────────────────┐
│ LIVE TRACK VIEW                                │
├────────────────────────────────────────────────┤
│                                                │
│ CSMT    THANE    KYN    KARJAT    LNL    PUNE │
│  0km     34km    54km    80km    106km   192km│
│  │        │       │       │        │       │  │
│  │        │       │       │        │       │  │
│ Track 1: ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│          ●RAJ                                  │
│                                                │
│ Track 2: ━━━━━━━━━━━━━🚧 BLOCKED━━━━━━━━━━━  │
│                    ●FRT                        │
│                                                │
│                    ⚠️                          │
│                CONFLICT ZONE                   │
│                  7:00 min                      │
└────────────────────────────────────────────────┘
```

---

### 6. Middle Panel - Elevation Profile
```
┌────────────────────────────────────────────────┐
│ ELEVATION PROFILE                              │
├────────────────────────────────────────────────┤
│                                                │
│ 625m ┌─────────────────────────────────       │
│      │                           ╱             │
│ 500m │                      ╱                  │
│      │                 ╱                       │
│ 375m │            ╱                            │
│      │       ╱                                 │
│ 250m │  ╱                                      │
│      ╱                                         │
│ 150m                                           │
│      80km  ●FRT  ●EXP  106km                   │
│                                                │
│ Gradient: 1.83%  │  Elevation: 475m  │  Steep │
└────────────────────────────────────────────────┘
```

---

### 7. Middle Panel - Distance-Time Graph
```
┌────────────────────────────────────────────────┐
│ DISTANCE-TIME GRAPH                            │
├────────────────────────────────────────────────┤
│                                                │
│ Distance (km)                                  │
│ 100 │                                          │
│     │        ╱ RAJ (red line)                  │
│  80 │      ╱                                   │
│     │    ╱   ⚠️ (conflict point)               │
│  60 │  ╱       ╲                               │
│     │╱           ╲ FRT (brown line)            │
│  40 │              ╲                           │
│     │                ╲                         │
│  20 │                  ╲                       │
│     └────────────────────────────              │
│     0    5    10   15   20   25               │
│              Time (minutes)                    │
└────────────────────────────────────────────────┘
```

---

### 8. Right Panel - Conflict Alert
```
┌──────────────────────────────┐
│ ⚠️ CONFLICT DETECTED         │
├──────────────────────────────┤
│                              │
│  ┌─────┐       ┌─────┐      │
│  │ RAJ │  ↔️   │ FRT │      │
│  └─────┘       └─────┘      │
│                              │
│ Location: 68.9 km            │
│                              │
│ Time to Conflict             │
│      7:00                    │
│ ████████████░░░░░░░░         │
│                              │
│ ┌──────────────────────────┐ │
│ │      CRITICAL            │ │
│ └──────────────────────────┘ │
└──────────────────────────────┘
```

---

### 9. Right Panel - Solution Card
```
┌──────────────────────────────┐
│        ⭐ RECOMMENDED         │
├──────────────────────────────┤
│ Stop FRT              [stop] │
│                              │
│ Energy        Delay          │
│ 363 kWh       10.0 min       │
│                              │
│ ┌──────────────────────────┐ │
│ │ Priority:  ✓ Respected   │ │
│ │ Safety:    10/10         │ │
│ └──────────────────────────┘ │
│                              │
│ ┌──────────────────────────┐ │
│ │   ✓ APPLY SOLUTION       │ │
│ └──────────────────────────┘ │
└──────────────────────────────┘
```

---

### 10. Right Panel - Energy Meter
```
┌──────────────────────────────┐
│ ENERGY METRICS               │
├──────────────────────────────┤
│ System Energy                │
│ 467 kWh                      │
│ ████████░░░░░░░░░░░░         │
│                              │
│ ┌──────────────────────────┐ │
│ │ 💰 ENERGY SAVED          │ │
│ │                          │ │
│ │      1418 kWh            │ │
│ │                          │ │
│ │  🔥 KILLER FEATURE!      │ │
│ │                          │ │
│ │ 🌱 CO₂ Reduced           │ │
│ │    1228 kg               │ │
│ │                          │ │
│ │ 🏠 Homes Powered         │ │
│ │    284 homes/hr          │ │
│ │                          │ │
│ │ ⛰️ Bhor Ghat Optimization│ │
│ │ Avoided stopping 4200-ton│ │
│ │ freight uphill!          │ │
│ └──────────────────────────┘ │
│                              │
│ ⚡ Efficiency: 96.4%         │
│ 🎯 Optimization: Active      │
└──────────────────────────────┘
```

---

## 🎬 Animation Effects

### 1. Pulsing Live Indicator
```
●  →  ○  →  ●  (repeats)
```
Red dot fades in/out every second

### 2. Train Movement
```
Track: ━━━━━━━━━━━━━━━━━━━━
       ●  →  →  →  ●
```
Smooth CSS transition, updates every 150ms

### 3. Conflict Zone Glow
```
⚠️  (glows red)
```
Box shadow pulses every 1.5 seconds

### 4. Speed Bar Fill
```
████████░░░░░░░░
```
Smooth width transition based on speed

### 5. Countdown Timer
```
7:00  →  6:59  →  6:58  →  ...
████████████░░░░░░░░
```
Number updates, progress bar shrinks

---

## 🎨 Typography

### Fonts
- **UI Text:** Inter (sans-serif)
- **Numbers:** Roboto Mono (monospace)

### Sizes
- **Large Numbers:** 2rem (32px) - Energy savings
- **Medium Text:** 1rem (16px) - Labels
- **Small Text:** 0.75rem (12px) - Details
- **Tiny Text:** 0.625rem (10px) - Badges

---

## 🌈 Visual Hierarchy

### Primary Focus
- Conflict alerts (red, glowing)
- Recommended solutions (blue, highlighted)
- Energy savings (green, large numbers)

### Secondary Focus
- Train status cards
- Live map view
- Distance-time graph

### Tertiary Focus
- Scenario selector
- Playback controls
- System metrics

---

## 📱 Responsive Behavior

### Desktop (1920x1080)
- 3-panel layout: 30% | 50% | 20%
- All features visible
- Optimal viewing experience

### Laptop (1366x768)
- 3-panel layout: 25% | 50% | 25%
- Slightly compressed
- Still fully functional

### Tablet (768px)
- Single column layout
- Panels stack vertically
- Scrollable content

---

## ✨ Special Effects

### Hover Effects
- Cards lift up 2px
- Border color changes
- Smooth 0.2s transition

### Click Effects
- Button scales to 1.02x
- Background color darkens
- Ripple effect (optional)

### Loading States
- Skeleton screens
- Pulsing placeholders
- "Waiting for data..." message

---

## 🎯 Key Visual Elements

### 1. Killer Feature Badge
```
┌──────────────────────┐
│  🔥 KILLER FEATURE!  │
└──────────────────────┘
```
Gradient background, glowing animation

### 2. Priority Stars
```
⭐⭐⭐⭐⭐  (Priority 1)
⭐         (Priority 5)
```

### 3. Gradient Badges
```
⛰️ UPHILL    (red)
⬇️ DOWNHILL  (green)
```

### 4. Track Status
```
🚧 BLOCKED - Rail crack at 68 km
```

### 5. Live Indicator
```
●LIVE  (pulsing red)
```

---

## 🎨 Design Principles

1. **Dark Theme** - Reduces eye strain, professional look
2. **High Contrast** - Easy to read from distance
3. **Color Coding** - Trains, status, priorities
4. **Smooth Animations** - Professional feel
5. **Clear Hierarchy** - Important info stands out
6. **Consistent Spacing** - 0.5rem, 1rem, 1.5rem
7. **Rounded Corners** - Modern aesthetic (6-8px)
8. **Subtle Shadows** - Depth and layering

---

**This visual guide shows the professional, feature-rich interface that will impress judges!** 🎨

