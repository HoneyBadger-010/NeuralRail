"""
Railway Network Data for Mumbai-Pune Corridor
This file contains the real railway infrastructure data we'll use for simulation.
"""

# Station data: Real stations on Mumbai-Pune route
# Route: CSMT → Thane → Kalyan → Karjat → Lonavala → Pune (192 km)
STATIONS = {
    "CSMT": {
        "name": "Chhatrapati Shivaji Maharaj Terminus",
        "km": 0,
        "elevation": 10,  # meters above sea level
        "platforms": 18,
        "type": "major_terminal"
    },
    "THANE": {
        "name": "Thane",
        "km": 34,
        "elevation": 25,
        "platforms": 10,
        "type": "major_station"
    },
    "KYN": {
        "name": "Kalyan Junction",
        "km": 54,
        "elevation": 42,
        "platforms": 8,
        "type": "junction"
    },
    "KARJAT": {
        "name": "Karjat",
        "km": 80,
        "elevation": 150,
        "platforms": 4,
        "type": "junction"
    },
    "LNL": {
        "name": "Lonavala",
        "km": 106,
        "elevation": 625,  # This is in the ghats - steep climb!
        "platforms": 4,
        "type": "major_station"
    },
    "PUNE": {
        "name": "Pune Junction",
        "km": 192,
        "elevation": 560,
        "platforms": 6,
        "type": "major_terminal"
    }
}

# Track segments: Connections between stations
# Route: CSMT → Thane → Kalyan → Karjat → Lonavala → Pune
TRACK_SEGMENTS = [
    {
        "id": "SEG_1",
        "from": "CSMT",
        "to": "THANE",
        "distance_km": 34,
        "tracks": 4,  # 4 parallel tracks (busy suburban section)
        "max_speed_kmh": 100,
        "gradient": "flat",  # Mostly flat terrain
        "electrified": True,
        "elevation_gain": 15  # 10m → 25m
    },
    {
        "id": "SEG_2",
        "from": "THANE",
        "to": "KYN",
        "distance_km": 20,
        "tracks": 2,  # Narrows to 2 tracks after Thane
        "max_speed_kmh": 100,
        "gradient": "flat",
        "electrified": True,
        "elevation_gain": 17  # 25m → 42m
    },
    {
        "id": "SEG_3",
        "from": "KYN",
        "to": "KARJAT",
        "distance_km": 26,
        "tracks": 2,  # 2 tracks
        "max_speed_kmh": 100,
        "gradient": "gentle_uphill",  # Gentle climb begins
        "electrified": True,
        "elevation_gain": 108  # 42m → 150m
    },
    {
        "id": "SEG_4",
        "from": "KARJAT",
        "to": "LNL",
        "distance_km": 26,
        "tracks": 3,  # Expands to 3 tracks for ghat section
        "max_speed_kmh": 60,  # Reduced speed due to steep climb (actual ghat limit)
        "gradient": "steep_uphill",  # This is the famous Bhor/Khandala ghat
        "electrified": True,
        "elevation_gain": 475,  # meters climbed (150m → 625m) - STEEP!
        "gradient_percent": 1.83  # 475m / 26000m = 1.83% average gradient
    },
    {
        "id": "SEG_5",
        "from": "LNL",
        "to": "PUNE",
        "distance_km": 86,
        "tracks": 2,
        "max_speed_kmh": 110,
        "gradient": "gentle_downhill",  # Descending from ghats
        "electrified": True,
        "elevation_loss": 65  # meters descended (625 - 560)
    }
]

# Train types with authentic Indian Railways characteristics
# Data sources: Indian Railways Technical Specifications (2023-2024)
# - RDSO (Research Designs and Standards Organisation) guidelines
# - CRIS (Centre for Railway Information Systems) data
# - Indian Railways Year Book 2023-24
# Last Updated: November 2024

TRAIN_TYPES = {
    "express_passenger": {
        "name": "Express Passenger (e.g., Deccan Queen)",
        "mass_kg": 520000,  # 520 tons (typical 22-coach rake with LHB coaches)
        # LHB coach weight: ~42 tons, WAP-5 loco: ~113 tons
        "max_speed_kmh": 110,  # Standard express speed limit
        "acceleration_mps2": 0.42,  # Typical for electric locos on level track
        "braking_rate_mps2": 0.65,  # Emergency braking with air brakes
        "idle_power_kw": 65,  # Hotel load (AC, lights) + auxiliary systems
        "traction_type": "electric",
        "passenger_capacity": 1430,  # 22 coaches × 65 passengers avg
        "priority": 3,  # 1=highest, 5=lowest
        "schedule_importance": "high",
        "loco_type": "WAP-5 or WAP-7"  # Common electric locos
    },
    "freight_heavy": {
        "name": "Heavy Freight (Coal/Container)",
        "mass_kg": 4200000,  # 4200 tons (58-wagon rake, fully loaded)
        # Typical BOXN wagon: 22 tons empty + 60 tons load
        # WAG-9 loco: ~123 tons
        "max_speed_kmh": 75,  # Freight speed limit on main line
        "acceleration_mps2": 0.12,  # Very slow acceleration due to mass
        "braking_rate_mps2": 0.28,  # Longer braking distance for freight
        "idle_power_kw": 45,  # Minimal auxiliary load
        "traction_type": "electric",
        "passenger_capacity": 0,
        "priority": 5,  # Lowest priority
        "schedule_importance": "low",
        "loco_type": "WAG-9 or WAG-12"  # Heavy freight locos
    },
    "local_emu": {
        "name": "Local EMU (Mumbai Suburban)",
        "mass_kg": 380000,  # 380 tons (12-car EMU rake)
        # Each EMU car: ~32 tons (lighter than loco-hauled)
        "max_speed_kmh": 105,  # Mumbai suburban EMU max speed
        "acceleration_mps2": 0.85,  # Fast acceleration for frequent stops
        "braking_rate_mps2": 1.1,  # Regenerative + air brakes
        "idle_power_kw": 55,  # Lights, fans, doors
        "traction_type": "electric",
        "passenger_capacity": 3600,  # 12 cars × 300 (crush capacity)
        "priority": 4,  # Lower priority but frequent
        "schedule_importance": "medium",
        "loco_type": "MRVC EMU"  # Mumbai Railway Vikas Corporation
    },
    "rajdhani": {
        "name": "Rajdhani Express (Premium)",
        "mass_kg": 850000,  # 850 tons (20 LHB AC coaches + 2 locos)
        # LHB AC coach: ~42 tons, Dual WAP-7: ~113 tons each
        "max_speed_kmh": 140,  # Rajdhani permitted speed (160 capable)
        "acceleration_mps2": 0.38,  # Slightly lower due to heavy AC load
        "braking_rate_mps2": 0.72,  # Modern disc brakes + regenerative
        "idle_power_kw": 180,  # High hotel load (full AC, kitchen, etc.)
        "traction_type": "electric",
        "passenger_capacity": 1122,  # AC coaches (lower capacity, more comfort)
        "priority": 1,  # Highest priority - premium service
        "schedule_importance": "critical",
        "loco_type": "WAP-7 (Dual)"  # High-speed electric loco
    },
    "vande_bharat": {
        "name": "Vande Bharat Express (Train 18)",
        "mass_kg": 430000,  # 430 tons (16-car distributed traction EMU)
        # Modern lightweight aluminum body
        "max_speed_kmh": 160,  # Operational max (180 capable)
        "acceleration_mps2": 1.05,  # Fastest acceleration in Indian Railways!
        "braking_rate_mps2": 1.2,  # Advanced regenerative braking
        "idle_power_kw": 95,  # Modern efficient systems
        "traction_type": "electric",
        "passenger_capacity": 1128,  # 16 cars, premium seating
        "priority": 1,  # Equal to Rajdhani
        "schedule_importance": "critical",
        "loco_type": "Distributed Traction EMU"  # Self-propelled
    }
}

def get_station_info(station_code):
    """Get information about a specific station"""
    return STATIONS.get(station_code, None)

def get_track_segment(segment_id):
    """Get information about a specific track segment"""
    for segment in TRACK_SEGMENTS:
        if segment["id"] == segment_id:
            return segment
    return None

def get_distance_between_stations(from_station, to_station):
    """Calculate distance between two stations"""
    if from_station in STATIONS and to_station in STATIONS:
        return abs(STATIONS[to_station]["km"] - STATIONS[from_station]["km"])
    return None

def get_elevation_change(from_station, to_station):
    """Calculate elevation change between two stations (positive = uphill)"""
    if from_station in STATIONS and to_station in STATIONS:
        return STATIONS[to_station]["elevation"] - STATIONS[from_station]["elevation"]
    return 0
