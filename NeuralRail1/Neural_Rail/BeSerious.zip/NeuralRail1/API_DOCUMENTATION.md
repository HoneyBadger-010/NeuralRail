# 🚀 NeuralRail API Documentation

## Base URL
```
http://localhost:5000/api
```

---

## 📋 **Endpoints**

### **1. GET /api/health**
Health check endpoint

**Response:**
```json
{
  "status": "ok",
  "message": "NeuralRail API is running"
}
```

---

### **2. GET /api/scenarios**
Get list of available demo scenarios

**Response:**
```json
{
  "scenarios": [
    {
      "id": 1,
      "name": "Head-On Collision - Priority Conflict",
      "description": "Rajdhani vs Freight on Kalyan-Karjat section",
      "judge_points": [
        "Detects conflict 7 min ahead",
        "Respects priorities (RAJ > FRT)",
        "Saves 139 kWh"
      ]
    },
    ...
  ]
}
```

---

### **3. POST /api/scenario/<scenario_id>/start**
Start a scenario simulation

**Parameters:**
- `scenario_id` (path): Scenario ID (1, 2, or 3)

**Response:**
```json
{
  "status": "started",
  "scenario": {
    "id": "s1",
    "name": "Head-On Collision - Priority Conflict",
    "description": "Rajdhani vs Freight on Kalyan-Karjat section",
    "section": "Kalyan-Karjat (2 tracks, gentle uphill)"
  },
  "trains": [
    {
      "id": "RAJ",
      "name": "Rajdhani Express (Premium)",
      "type": "rajdhani",
      "position": 56.0,
      "speed": 100.0,
      "direction": "forward",
      "destination": 106,
      "priority": 1,
      "mass_tons": 850,
      "track_number": 1,
      "color": "#FF4444",
      "next_station": "Karjat",
      "distance_to_station": 24.0,
      "gradient_status": "flat"
    },
    {
      "id": "FRT",
      "name": "Heavy Freight (Coal/Container)",
      "type": "freight_heavy",
      "position": 77.0,
      "speed": 60.0,
      "direction": "backward",
      "destination": 54,
      "priority": 5,
      "mass_tons": 4200,
      "track_number": 1,
      "color": "#8B4513",
      "next_station": "Kalyan Junction",
      "distance_to_station": 23.0,
      "gradient_status": "flat"
    }
  ],
  "track_info": {
    "parallel_tracks_available": false,
    "tracks": 2,
    "section_start_km": 54,
    "section_end_km": 80,
    "gradient": "gentle_uphill",
    "elevation_gain": 108
  },
  "stations": [
    {
      "code": "CSMT",
      "name": "Chhatrapati Shivaji Maharaj Terminus",
      "km": 0,
      "platforms": 18
    },
    {
      "code": "THANE",
      "name": "Thane",
      "km": 34,
      "platforms": 10
    },
    ...
  ]
}
```

---

### **4. POST /api/simulation/step**
Execute one simulation step (10 seconds)

**Response:**
```json
{
  "time_minutes": 0.2,
  "trains": [
    {
      "id": "RAJ",
      "name": "Rajdhani Express (Premium)",
      "type": "Rajdhani Express (Premium)",
      "position": 56.28,
      "speed": 100.0,
      "state": "moving",
      "direction": "forward",
      "destination": 106,
      "priority": 1,
      "energy_kwh": 12.5,
      "mass_tons": 850,
      "track_number": 1,
      "color": "#FF4444",
      "next_station": "Karjat",
      "distance_to_station": 23.72,
      "section": "KYN-KARJAT",
      "gradient_status": "flat"
    },
    {
      "id": "FRT",
      "name": "Heavy Freight (Coal/Container)",
      "type": "Heavy Freight (Coal/Container)",
      "position": 76.83,
      "speed": 60.0,
      "state": "moving",
      "direction": "backward",
      "destination": 54,
      "priority": 5,
      "energy_kwh": 8.2,
      "mass_tons": 4200,
      "track_number": 1,
      "color": "#8B4513",
      "next_station": "Kalyan Junction",
      "distance_to_station": 22.83,
      "section": "KYN-KARJAT",
      "gradient_status": "flat"
    }
  ],
  "conflicts": [
    {
      "train_a": "RAJ",
      "train_b": "FRT",
      "position_km": 66.5,
      "time_minutes": 7.7,
      "severity": "critical"
    }
  ],
  "system_energy_kwh": 20.7,
  "history": [
    {
      "time": 0.0,
      "trains": {
        "RAJ": {"position": 56.0, "speed": 100.0},
        "FRT": {"position": 77.0, "speed": 60.0}
      }
    },
    {
      "time": 0.2,
      "trains": {
        "RAJ": {"position": 56.28, "speed": 100.0},
        "FRT": {"position": 76.83, "speed": 60.0}
      }
    },
    ...
  ]
}
```

---

### **5. POST /api/conflict/analyze**
Analyze detected conflict and get AI recommendations

**Response:**
```json
{
  "conflict": {
    "position_km": 66.5,
    "time_minutes": 7.7,
    "severity": "critical"
  },
  "solutions": [
    {
      "id": "A2",
      "action": "Stop FRT",
      "type": "stop",
      "energy_kwh": 850.0,
      "delay_minutes": 8.0,
      "priority_violation": false,
      "score": 45.2,
      "safety_score": 10,
      "is_recommended": true
    },
    {
      "id": "A1",
      "action": "Stop RAJ",
      "type": "stop",
      "energy_kwh": 989.0,
      "delay_minutes": 5.0,
      "priority_violation": true,
      "score": 545.8,
      "safety_score": 8,
      "is_recommended": false
    },
    ...
  ],
  "explanation": "I recommend stopping the Freight train because...",
  "energy_saved_kwh": 139.0
}
```

---

## 📊 **Data Models**

### **Train Object**
```typescript
{
  id: string;              // Train ID (e.g., "RAJ", "FRT")
  name: string;            // Full name
  type: string;            // Train type
  position: number;        // Position in km
  speed: number;           // Speed in km/h
  state: string;           // "moving", "stopped", "braking", "accelerating"
  direction: string;       // "forward" or "backward"
  destination: number;     // Destination in km
  priority: number;        // 1 (highest) to 5 (lowest)
  energy_kwh: number;      // Total energy consumed
  mass_tons: number;       // Mass in tons
  track_number: number;    // Current track (1-4)
  color: string;           // Hex color for UI
  next_station: string;    // Next station name
  distance_to_station: number;  // Distance to next station
  section: string;         // Current section (e.g., "KYN-KARJAT")
  gradient_status: string; // "uphill", "downhill", "flat"
}
```

### **Conflict Object**
```typescript
{
  train_a: string;         // First train ID
  train_b: string;         // Second train ID
  position_km: number;     // Conflict position
  time_minutes: number;    // Time to conflict
  severity: string;        // "critical" or "warning"
}
```

### **Solution Object**
```typescript
{
  id: string;              // Solution ID
  action: string;          // Action description
  type: string;            // "stop", "slow", "both_slow", "multi_step"
  energy_kwh: number;      // Energy cost
  delay_minutes: number;   // Time delay
  priority_violation: boolean;  // Violates priority?
  score: number;           // Lower is better
  safety_score: number;    // 1-10, higher is better
  is_recommended: boolean; // Is this the best solution?
}
```

### **History Point** (for distance-time graph)
```typescript
{
  time: number;            // Time in minutes
  trains: {
    [train_id: string]: {
      position: number;    // Position in km
      speed: number;       // Speed in km/h
    }
  }
}
```

---

## 🎨 **Train Colors**

| Train Type | Color | Hex Code |
|------------|-------|----------|
| Rajdhani | Red 🔴 | #FF4444 |
| Freight | Brown 🟤 | #8B4513 |
| Vande Bharat | Gold 🟡 | #FFD700 |
| Local EMU | Blue 🔵 | #4169E1 |
| Express | Green 🟢 | #32CD32 |

---

## 🚂 **Stations**

| Code | Name | Distance (km) | Platforms |
|------|------|---------------|-----------|
| CSMT | Chhatrapati Shivaji Maharaj Terminus | 0 | 18 |
| THANE | Thane | 34 | 10 |
| KYN | Kalyan Junction | 54 | 8 |
| KARJAT | Karjat | 80 | 4 |
| LNL | Lonavala | 106 | 4 |
| PUNE | Pune Junction | 192 | 6 |

---

## 🛤️ **Track Segments**

| Segment | From | To | Distance | Tracks | Max Speed | Gradient |
|---------|------|----|---------:|-------:|----------:|----------|
| SEG_1 | CSMT | THANE | 34 km | 4 | 100 km/h | Flat |
| SEG_2 | THANE | KYN | 20 km | 2 | 100 km/h | Flat |
| SEG_3 | KYN | KARJAT | 26 km | 2 | 100 km/h | Gentle uphill |
| SEG_4 | KARJAT | LNL | 26 km | 3 | 60 km/h | **Steep uphill** ⛰️ |
| SEG_5 | LNL | PUNE | 86 km | 2 | 110 km/h | Gentle downhill |

---

## 🔄 **Typical Usage Flow**

```javascript
// 1. Check health
GET /api/health

// 2. Get scenarios
GET /api/scenarios

// 3. Start scenario
POST /api/scenario/1/start

// 4. Run simulation loop
setInterval(() => {
  POST /api/simulation/step
  // Update UI with train positions
  // Check for conflicts
}, 150);  // 150ms = 6.67 FPS

// 5. When conflict detected
POST /api/conflict/analyze
// Show AI recommendations
```

---

## ⚡ **Performance Notes**

- **Update Rate**: 150ms recommended (6.67 FPS)
- **History Limit**: Last 100 points (prevents memory issues)
- **Response Time**: <100ms typical
- **Concurrent Requests**: Single simulation at a time

---

## 🐛 **Error Responses**

```json
{
  "error": "No simulation running"
}
```

**Status Codes:**
- `200`: Success
- `400`: Bad request (no simulation running)
- `404`: Scenario not found
- `500`: Server error

---

**Status:** API Enhanced ✅  
**Ready for:** Frontend development  
**Date:** 2024-11-29
