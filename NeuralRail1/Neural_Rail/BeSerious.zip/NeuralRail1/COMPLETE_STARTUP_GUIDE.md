# 🚀 Complete Startup Guide - NeuralRail Frontend

## ✅ Status: Frontend is 100% Complete!

All 32 files are created and properly implemented. You just need to start the servers!

---

## 📋 Pre-Flight Checklist

### ✅ What's Already Done:
- [x] 32 frontend files created
- [x] All components implemented
- [x] All CSS styled
- [x] API integration complete
- [x] Error handling added
- [x] Animations configured
- [x] Train positioning fixed (ON track lines)

### ⏳ What You Need to Do:
1. Start Backend Server
2. Frontend is already running (refresh if needed)
3. Select a scenario and watch!

---

## 🚀 Step-by-Step Startup

### **Step 1: Start Backend** (CRITICAL!)

Open a **NEW terminal** and run:

```bash
# Navigate to project root
cd D:\AC\NeuralRail1

# Start backend
python backend/api/app.py
```

**Expected Output:**
```
======================================================================
NeuralRail API Server
======================================================================
Starting server on http://localhost:5000
Frontend will connect to this API
======================================================================
 * Serving Flask app 'app'
 * Debug mode: on
WARNING: This is a development server.
 * Running on http://127.0.0.1:5000
Press CTRL+C to quit
```

**✅ Backend is running when you see:** `Running on http://127.0.0.1:5000`

---

### **Step 2: Refresh Frontend**

Your frontend is already running on `http://localhost:3000`

**Just refresh the page!** (Press F5 or Ctrl+R)

---

### **Step 3: What You Should See**

#### **A. If Backend is Running:** ✅
```
┌─────────────────────────────────────────────────────────────┐
│  🚄 NeuralRail Control Room    ●LIVE    14:32:15 IST      │
├──────────────┬──────────────────────────────┬──────────────┤
│              │                              │              │
│  ┌────────┐  │                              │              │
│  │   ①    │  │      (Empty - waiting       │  (Empty)     │
│  │ Head-On│  │       for scenario)          │              │
│  │Collision│ │                              │              │
│  └────────┘  │                              │              │
│              │                              │              │
│  ┌────────┐  │                              │              │
│  │   ②    │  │                              │              │
│  │ Multi- │  │                              │              │
│  │ Train  │  │                              │              │
│  └────────┘  │                              │              │
│              │                              │              │
│  ┌────────┐  │                              │              │
│  │   ③    │  │                              │              │
│  │🔥KILLER│  │                              │              │
│  │BhorGhat│  │                              │              │
│  └────────┘  │                              │              │
└──────────────┴──────────────────────────────┴──────────────┘
```

**You should see:**
- ✅ Navbar with logo, LIVE indicator, clock
- ✅ 3 scenario cards in left panel
- ✅ Empty middle panel (waiting for scenario)
- ✅ Empty right panel (waiting for data)

---

#### **B. If Backend is NOT Running:** ⚠️
```
┌─────────────────────────────────────────────────────────────┐
│  🚄 NeuralRail Control Room    ●LIVE    14:32:15 IST      │
├─────────────────────────────────────────────────────────────┤
│  ⚠️ Backend Not Running!                                    │
│                                                             │
│  Please start the backend server:                          │
│  python backend/api/app.py                                 │
│                                                             │
│  [🔄 Retry Connection]                                     │
└─────────────────────────────────────────────────────────────┘
```

**If you see this:**
1. Backend is not running
2. Start backend in a new terminal
3. Click "Retry Connection" button
4. Or refresh the page (F5)

---

## 🎬 How to Use

### **1. Select Scenario**

Click on any scenario card:
- **Scenario 1:** Head-On Collision
- **Scenario 2:** Multi-Train Coordination  
- **Scenario 3:** 🔥 Bhor Ghat (KILLER FEATURE)

### **2. Watch Simulation**

After clicking a scenario:
- ✅ Trains appear on map
- ✅ Train status cards show in left panel
- ✅ Play button appears
- ✅ Graph starts updating

### **3. Start Simulation**

Click **▶️ PLAY** button

You'll see:
- ✅ Trains moving on track lines
- ✅ Speed bars updating
- ✅ Graph lines drawing
- ✅ Position numbers changing

### **4. Wait for Conflict**

After a few minutes (simulation time):
- ⚠️ Conflict alert appears (right panel)
- ⚠️ Countdown timer starts
- ⚠️ Red zone appears on map
- ⚠️ Sound alert plays (if enabled)

### **5. See AI Recommendations**

When conflict is detected:
- ⭐ Recommended solution appears
- 💰 Energy cost shown
- ⏱️ Delay time shown
- ✓ Priority status shown

### **6. Apply Solution**

Click **✓ APPLY SOLUTION** button

Result:
- ✅ Simulation pauses
- ✅ Success message shows
- ✅ Energy savings displayed

---

## 🔥 Demo Scenario 3 (Killer Feature)

### **To See the 1418 kWh Savings:**

1. **Click Scenario 3** (🔥 KILLER)
2. **Click ▶️ PLAY**
3. **Wait ~8 minutes** (simulation time)
4. **See conflict detected**
5. **See recommendation:** "Stop EXP"
6. **See energy saved:** **1418 kWh** 🔥

**You'll see:**
```
┌─────────────────────────────────────┐
│  💰 ENERGY SAVED                    │
│                                     │
│         1418 kWh                    │
│                                     │
│  ┌─────────────────────────────┐   │
│  │  🔥 KILLER FEATURE!         │   │
│  └─────────────────────────────┘   │
│                                     │
│  🌱 CO₂ Reduced: 1228 kg           │
│  🏠 Homes Powered: 284 homes/hr    │
│                                     │
│  ⛰️ Bhor Ghat Optimization         │
│  Avoided stopping 4200-ton          │
│  freight uphill!                    │
└─────────────────────────────────────┘
```

---

## 🐛 Troubleshooting

### **Problem 1: "Backend Not Running" Error**

**Solution:**
```bash
# Open new terminal
cd D:\AC\NeuralRail1
python backend/api/app.py
```

Then refresh frontend (F5)

---

### **Problem 2: Scenarios Not Loading**

**Check:**
1. Is backend running? Look for: `Running on http://127.0.0.1:5000`
2. Is it on port 5000? (not 5001 or other)
3. Any errors in backend terminal?

**Solution:**
```bash
# Restart backend
Ctrl+C (to stop)
python backend/api/app.py
```

---

### **Problem 3: Trains Not Moving**

**Check:**
1. Did you click a scenario?
2. Did you click ▶️ PLAY button?
3. Is backend responding?

**Solution:**
1. Click scenario card
2. Click ▶️ PLAY
3. Wait a few seconds

---

### **Problem 4: Graph Not Showing**

**Reason:** Graph needs data from simulation

**Solution:**
1. Start a scenario
2. Click PLAY
3. Wait 10-20 seconds
4. Graph will start drawing

---

### **Problem 5: Port 5000 Already in Use**

**Error:** `Address already in use`

**Solution:**
```bash
# Windows - Kill process on port 5000
netstat -ano | findstr :5000
taskkill /PID <PID_NUMBER> /F

# Then restart backend
python backend/api/app.py
```

---

## ✅ Success Indicators

### **Backend Running Successfully:**
- ✅ Terminal shows: `Running on http://127.0.0.1:5000`
- ✅ No error messages
- ✅ Can access: `http://localhost:5000/api/health`

### **Frontend Running Successfully:**
- ✅ Page loads at `http://localhost:3000`
- ✅ Navbar visible with clock updating
- ✅ 3 scenario cards visible
- ✅ No red error banner

### **Integration Working:**
- ✅ Click scenario → trains appear
- ✅ Click PLAY → trains move
- ✅ Numbers update in real-time
- ✅ Graph draws lines
- ✅ Conflict detected after some time

---

## 📊 What Each Panel Shows

### **Left Panel (30%):**
- Scenario selector (3 cards)
- Playback controls (Play/Pause/Reset/Speed)
- Train status cards (live data)

### **Middle Panel (50%):**
- Live track map (trains on lines)
- Elevation profile (Scenario 3 only)
- Distance-time graph (Recharts)

### **Right Panel (20%):**
- Conflict alert (when detected)
- AI recommendations (solutions)
- Energy meter (savings)

---

## 🎯 Quick Test Checklist

### **Test 1: Basic Functionality**
- [ ] Backend starts without errors
- [ ] Frontend loads at localhost:3000
- [ ] Navbar shows with clock updating
- [ ] 3 scenarios visible

### **Test 2: Scenario 1**
- [ ] Click Scenario 1
- [ ] Trains appear (RAJ, FRT)
- [ ] Click PLAY
- [ ] Trains move on track lines
- [ ] Conflict detected (~7 min)
- [ ] AI recommends "Stop FRT"

### **Test 3: Scenario 3 (Killer)**
- [ ] Click Scenario 3
- [ ] Trains appear (FRT, EXP, BANKER)
- [ ] Elevation profile shows
- [ ] Click PLAY
- [ ] Trains move on gradient
- [ ] Conflict detected (~8 min)
- [ ] AI recommends "Stop EXP"
- [ ] **1418 kWh savings shown** 🔥

---

## 🎉 You're Ready!

**Everything is set up!** Just:

1. **Start backend:** `python backend/api/app.py`
2. **Refresh frontend:** Press F5
3. **Click Scenario 3**
4. **Click PLAY**
5. **Watch the magic!** ✨

---

## 📞 Still Having Issues?

### **Check These:**
1. Python version: `python --version` (should be 3.8+)
2. Backend dependencies: `pip list | findstr Flask`
3. Frontend dependencies: `npm list react` (in frontend folder)
4. Port availability: `netstat -ano | findstr :5000`
5. Browser console: Press F12, check for errors

### **Common Fixes:**
```bash
# Reinstall backend dependencies
pip install -r requirements.txt

# Reinstall frontend dependencies
cd frontend
npm install

# Clear browser cache
Ctrl+Shift+Delete → Clear cache

# Restart everything
Ctrl+C (stop backend)
Ctrl+C (stop frontend)
python backend/api/app.py
npm run dev (in frontend folder)
```

---

**Status:** ✅ **FRONTEND IS COMPLETE AND READY!**

**Just start the backend and you're good to go!** 🚀
