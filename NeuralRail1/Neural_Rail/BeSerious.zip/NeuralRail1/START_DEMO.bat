@echo off
echo ========================================
echo    NeuralRail - Demo Startup Script
echo    Smart India Hackathon 2024
echo ========================================
echo.

echo [1/3] Checking Python installation...
python --version
if errorlevel 1 (
    echo ERROR: Python not found! Please install Python 3.8+
    pause
    exit /b 1
)
echo.

echo [2/3] Starting Backend Server...
echo Backend will start on http://localhost:5000
echo.
start "NeuralRail Backend" cmd /k "python backend/api/app.py"
timeout /t 3 /nobreak >nul
echo.

echo [3/3] Opening Frontend Dashboard...
echo Dashboard will open in your default browser
echo.
start "" "frontend/index.html"
timeout /t 2 /nobreak >nul
echo.

echo ========================================
echo    Demo is ready!
echo ========================================
echo.
echo Backend: http://localhost:5000
echo Frontend: Check your browser
echo.
echo Press any key to stop the demo...
pause >nul

echo.
echo Stopping backend server...
taskkill /FI "WINDOWTITLE eq NeuralRail Backend*" /T /F >nul 2>&1
echo.
echo Demo stopped. Thank you!
pause
