# 🎨 Frontend Development - Complete Context

**Project:** NeuralRail - AI-Assisted Railway Traffic Management  
**Status:** Backend 100% Complete - Ready for Frontend  
**Date:** November 30, 2024

---

## 📋 QUICK START SUMMARY

### **What We Have:**
✅ Backend API running on `http://localhost:5000`  
✅ 3 demo scenarios fully tested  
✅ AI recommendations working correctly  
✅ All endpoints functional  

### **What We Need:**
⏳ React frontend with real-time monitoring  
⏳ Live train visualization  
⏳ Distance-time graphs  
⏳ AI assistant panel  

### **Tech Stack:**
- React 18 + Vite
- Recharts (for graphs)
- CSS (control room styling)
- Fetch API (backend connection)

---

## 🎯 FRONTEND REQUIREMENTS

### **Layout (3-Panel Design):**
```
┌────────────────────────────────────────────────────────┐
│ 🚄 NeuralRail Control Room | ●LIVE | 14:32:15 IST    │
├──────────┬─────────────────────────┬───────────────────┤
│  LEFT    │       MIDDLE            │      RIGHT        │
│  30%     │        50%              │       20%         │
│          │                         │                   │
│ Scenario │  Live Map View          │  AI Assistant     │
│ Selector │  ┌──────────────────┐   │  ⚠️ CONFLICT     │
│          │  │ Train Positions  │   │  DETECTED        │
│ Train    │  │ CSMT ──●──●→ Pune│   │                  │
│ Status   │  └──────────────────┘   │  Recommendations │
│ Cards    │                         │  ┌─────────────┐ │
│          │  Distance-Time Graph    │  │ Stop FRT    │ │
│ ┌──────┐ │  ┌──────────────────┐   │  │ 363 kWh     │ │
│ │ RAJ  │ │  │     Distance     │   │  │ [APPLY]     │ │
│ │100km/│ │  │  80├─────────    │   │  └─────────────┘ │
│ │56 km │ │  │    │   ╱ RAJ     │   │                  │
│ └──────┘ │  │  60├─╱───╲       │   │  Energy Saved:  │
│          │  │    │      ╲ FRT   │   │  1418 kWh       │
└──────────┴─────────────────────────┴───────────────────┘
```


## 🔌 BACKEND API REFERENCE

### **Base URL:** `http://localhost:5000/api`

### **Key Endpoints:**

#### 1. Get Scenarios
```javascript
GET /api/scenarios
Response: {
  scenarios: [
    {
      id: 1,
      name: "Head-On Collision - Priority Conflict",
      description: "Rajdhani vs Freight on Kalyan-Karjat section",
      judge_points: [...]
    }
  ]
}
```

#### 2. Start Scenario
```javascript
POST /api/scenario/1/start
Response: {
  status: "started",
  scenario: { id: "s1", name: "...", description: "..." },
  trains: [
    {
      id: "RAJ",
      name: "Rajdhani Express (Premium)",
      type: "rajdhani",
      position: 56.0,
      speed: 100,
      direction: "forward",
      destination: 106,
      priority: 1,
      mass_tons: 850,
      track_number: 1,
      color: "#FF4444",
      next_station: "Lonavala",
      distance_to_station: 50.0
    }
  ],
  track_info: { tracks: 2, parallel_tracks_available: false, ... },
  stations: [...]
}
```

#### 3. Simulation Step
```javascript
POST /api/simulation/step
Response: {
  time_minutes: 0.2,
  trains: [
    {
      id: "RAJ",
      position: 56.5,
      speed: 100,
      state: "moving",
      energy_kwh: 125.5,
      next_station: "Lonavala",
      distance_to_station: 49.5
    }
  ],
  conflicts: [
    {
      train_a: "RAJ",
      train_b: "FRT",
      position_km: 68.9,
      time_minutes: 7.0,
      severity: "CRITICAL"
    }
  ],
  system_energy_kwh: 465.2,
  history: [...]  // For distance-time graph
}
```

#### 4. Analyze Conflict
```javascript
POST /api/conflict/analyze
Response: {
  conflict: { position_km: 68.9, time_minutes: 7.0, severity: "CRITICAL" },
  solutions: [
    {
      id: "A2",
      action: "Stop FRT",
      type: "stop",
      energy_kwh: 363.2,
      delay_minutes: 10.0,
      priority_violation: false,
      score: 38.5,
      is_recommended: true
    }
  ],
  explanation: "Recommended action: Stop FRT. Stopping FRT respects...",
  energy_saved_kwh: 0
}
```


## 📊 SCENARIO DATA

### **Scenario 1: Head-On Collision**
- **Trains:** RAJ (Priority 1, 850 tons) vs FRT (Priority 5, 4200 tons)
- **Conflict:** Head-on at 68.9 km in 7.0 minutes
- **Track 2:** BLOCKED (rail crack at 68 km)
- **AI Recommendation:** Stop FRT (363 kWh)
- **Color Scheme:** RAJ=#FF4444 (red), FRT=#8B4513 (brown)

### **Scenario 2: Multi-Train Coordination**
- **Trains:** VB (Priority 1), LOC (Priority 4), MEMO (Priority 4), FRT2 (Priority 5)
- **Conflict:** VB catching LOC at 46.3 km in 24.0 minutes
- **Track 3:** AVAILABLE for switching
- **AI Recommendation:** Multi-step track switch (51 kWh)
- **Color Scheme:** VB=#FFD700 (gold), LOC=#4169E1 (blue)

### **Scenario 3: Bhor Ghat (KILLER FEATURE)**
- **Trains:** FRT (Priority 5, uphill) vs EXP (Priority 3, downhill)
- **Conflict:** Head-on at 90.8 km in 8.2 minutes
- **Gradient:** 1.83% steep uphill
- **AI Recommendation:** Stop EXP (53 kWh, saves 1418 kWh!)
- **Color Scheme:** FRT=#8B4513 (brown), EXP=#32CD32 (green)


## 🎨 UI COMPONENTS NEEDED

### **1. Navbar (Top - 40px)**
```jsx
<Navbar>
  <Logo>🚄 NeuralRail Control Room</Logo>
  <LiveIndicator>●LIVE</LiveIndicator>
  <Clock>14:32:15 IST</Clock>
  <Mode>Balanced Mode</Mode>
</Navbar>
```

### **2. Left Panel (30% width)**
```jsx
<LeftPanel>
  <ScenarioSelector scenarios={scenarios} onSelect={handleSelect} />
  <TrainStatusCards trains={trains} />
  <EmergencyControls />
</LeftPanel>
```

**TrainStatusCard:**
```jsx
<TrainCard color={train.color}>
  <Header>{train.id} ●LIVE</Header>
  <Speed>{train.speed} km/h</Speed>
  <SpeedBar percentage={train.speed / train.max_speed * 100} />
  <Position>{train.position} km</Position>
  <ProgressBar percentage={progress} />
  <NextStation>→ {train.next_station}</NextStation>
  <ETA>{calculateETA(train)}</ETA>
  <Details>
    Track: {train.track_number}
    Priority: {train.priority} ⭐
    Energy: {train.energy_kwh} kWh
  </Details>
</TrainCard>
```

### **3. Middle Panel (50% width)**
```jsx
<MiddlePanel>
  <LiveMapView trains={trains} stations={stations} />
  <DistanceTimeGraph history={history} conflict={conflict} />
</MiddlePanel>
```

**LiveMapView:**
```jsx
<MapView>
  <StationLabels>
    {stations.map(s => <Station key={s.code} km={s.km}>{s.name}</Station>)}
  </StationLabels>
  <TrackLines>
    {Array(trackInfo.tracks).map(i => <Track key={i} />)}
  </TrackLines>
  <TrainMarkers>
    {trains.map(t => (
      <TrainMarker 
        key={t.id} 
        position={t.position} 
        color={t.color}
        track={t.track_number}
      />
    ))}
  </TrainMarkers>
  {conflict && <ConflictZone position={conflict.position_km} />}
</MapView>
```

**DistanceTimeGraph (using Recharts):**
```jsx
<LineChart data={history}>
  <XAxis dataKey="time" label="Time (min)" />
  <YAxis label="Distance (km)" />
  <Line dataKey="RAJ.position" stroke="#FF4444" />
  <Line dataKey="FRT.position" stroke="#8B4513" />
  {conflict && <ReferenceDot x={conflict.time} y={conflict.position} />}
</LineChart>
```

### **4. Right Panel (20% width)**
```jsx
<RightPanel>
  {conflict && <ConflictAlert conflict={conflict} />}
  <AIRecommendations solutions={solutions} onApply={handleApply} />
  <EnergySavings savings={energySaved} />
</RightPanel>
```

**ConflictAlert:**
```jsx
<Alert severity="critical">
  <Title>⚠️ CONFLICT DETECTED</Title>
  <Location>At {conflict.position_km} km</Location>
  <Countdown>{formatTime(conflict.time_minutes)}</Countdown>
  <Trains>{conflict.train_a} ↔ {conflict.train_b}</Trains>
  <Severity>{conflict.severity}</Severity>
</Alert>
```

**SolutionCard:**
```jsx
<SolutionCard recommended={solution.is_recommended}>
  <Action>{solution.action}</Action>
  <Energy>{solution.energy_kwh} kWh</Energy>
  <Delay>{solution.delay_minutes} min</Delay>
  <Priority>{solution.priority_violation ? "⚠️ Override" : "✓ Respected"}</Priority>
  <Button onClick={() => onApply(solution)}>APPLY</Button>
</SolutionCard>
```


## 🔄 STATE MANAGEMENT

### **Main App State:**
```javascript
const [scenarios, setScenarios] = useState([]);
const [currentScenario, setCurrentScenario] = useState(null);
const [trains, setTrains] = useState([]);
const [conflict, setConflict] = useState(null);
const [solutions, setSolutions] = useState([]);
const [history, setHistory] = useState([]);
const [systemEnergy, setSystemEnergy] = useState(0);
const [isRunning, setIsRunning] = useState(false);
const [currentTime, setCurrentTime] = useState(0);
```

### **Real-Time Update Loop:**
```javascript
useEffect(() => {
  if (!isRunning) return;
  
  const interval = setInterval(async () => {
    // Step simulation
    const response = await fetch('/api/simulation/step', { method: 'POST' });
    const data = await response.json();
    
    // Update state
    setTrains(data.trains);
    setCurrentTime(data.time_minutes);
    setSystemEnergy(data.system_energy_kwh);
    setHistory(prev => [...prev, data.history]);
    
    // Check for conflicts
    if (data.conflicts.length > 0) {
      setConflict(data.conflicts[0]);
      // Analyze conflict
      analyzeConflict();
    }
  }, 150); // Update every 150ms
  
  return () => clearInterval(interval);
}, [isRunning]);
```

### **API Service Functions:**
```javascript
// services/api.js
const API_BASE = 'http://localhost:5000/api';

export const api = {
  getScenarios: async () => {
    const res = await fetch(`${API_BASE}/scenarios`);
    return res.json();
  },
  
  startScenario: async (id) => {
    const res = await fetch(`${API_BASE}/scenario/${id}/start`, {
      method: 'POST'
    });
    return res.json();
  },
  
  simulationStep: async () => {
    const res = await fetch(`${API_BASE}/simulation/step`, {
      method: 'POST'
    });
    return res.json();
  },
  
  analyzeConflict: async () => {
    const res = await fetch(`${API_BASE}/conflict/analyze`, {
      method: 'POST'
    });
    return res.json();
  }
};
```


## 🎨 STYLING (Control Room Theme)

### **Color Palette:**
```css
:root {
  /* Background */
  --bg-dark: #1a1a2e;
  --bg-panel: #16213e;
  --bg-card: #0f3460;
  
  /* Accent Colors */
  --accent-blue: #0f3460;
  --accent-red: #e94560;
  --text-primary: #eaeaea;
  --text-secondary: #94a3b8;
  
  /* Status Colors */
  --success: #00ff88;
  --warning: #ffa500;
  --danger: #ff0000;
  --live: #ff0000;
  
  /* Train Colors */
  --train-rajdhani: #FF4444;
  --train-freight: #8B4513;
  --train-vb: #FFD700;
  --train-local: #4169E1;
  --train-express: #32CD32;
}
```

### **Typography:**
```css
/* Monospace for numbers */
.metric-value {
  font-family: 'Roboto Mono', monospace;
  font-size: 24px;
  font-weight: 700;
  color: var(--text-primary);
}

/* Sans-serif for labels */
.label {
  font-family: 'Inter', sans-serif;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 1px;
  color: var(--text-secondary);
}
```

### **Live Indicator Animation:**
```css
.live-indicator {
  width: 8px;
  height: 8px;
  background: var(--live);
  border-radius: 50%;
  animation: pulse 1s infinite;
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.3; }
}
```

### **Card Styling:**
```css
.train-card {
  background: var(--bg-card);
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 12px;
  border-left: 4px solid var(--train-color);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
}

.train-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
  transition: all 0.2s ease;
}
```


## 📦 PROJECT SETUP

### **1. Initialize React + Vite:**
```bash
cd frontend
npm create vite@latest . -- --template react
npm install
```

### **2. Install Dependencies:**
```bash
npm install recharts
```

### **3. Project Structure:**
```
frontend/
├── src/
│   ├── components/
│   │   ├── Navbar.jsx
│   │   ├── LeftPanel/
│   │   │   ├── ScenarioSelector.jsx
│   │   │   ├── TrainStatusCard.jsx
│   │   │   └── EmergencyControls.jsx
│   │   ├── MiddlePanel/
│   │   │   ├── LiveMapView.jsx
│   │   │   └── DistanceTimeGraph.jsx
│   │   └── RightPanel/
│   │       ├── ConflictAlert.jsx
│   │       ├── SolutionCard.jsx
│   │       └── EnergySavings.jsx
│   ├── services/
│   │   └── api.js
│   ├── utils/
│   │   └── helpers.js
│   ├── App.jsx
│   ├── App.css
│   └── main.jsx
├── index.html
├── vite.config.js
└── package.json
```

### **4. Vite Config (Proxy Setup):**
```javascript
// vite.config.js
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    proxy: {
      '/api': {
        target: 'http://localhost:5000',
        changeOrigin: true
      }
    }
  }
})
```


## 🚀 IMPLEMENTATION STEPS

### **Phase 1: Basic Setup (30 min)**
1. Initialize Vite + React project
2. Setup proxy for API calls
3. Create basic layout (3 panels)
4. Add control room styling
5. Test API connection

### **Phase 2: Left Panel (1 hour)**
1. Scenario selector dropdown
2. Train status cards with live data
3. Speed bars and progress indicators
4. Next station and ETA display
5. Emergency controls (optional)

### **Phase 3: Middle Panel (1.5 hours)**
1. Live map view with train positions
2. Station markers and labels
3. Track lines visualization
4. Conflict zone highlighting
5. Distance-time graph (Recharts)
6. Real-time line drawing

### **Phase 4: Right Panel (1 hour)**
1. Conflict alert card
2. Countdown timer
3. Solution cards with recommendations
4. Apply button functionality
5. Energy savings display

### **Phase 5: Integration (1 hour)**
1. Connect all components to API
2. Implement real-time updates (150ms)
3. Handle conflict detection
4. Test all 3 scenarios
5. Fix bugs and polish

### **Phase 6: Polish (30 min)**
1. Add animations
2. Improve responsiveness
3. Add loading states
4. Error handling
5. Final testing

**Total Time: 5-6 hours**


## 💡 HELPER FUNCTIONS

### **Time Formatting:**
```javascript
export const formatTime = (minutes) => {
  const mins = Math.floor(minutes);
  const secs = Math.floor((minutes - mins) * 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
};

export const formatClock = () => {
  const now = new Date();
  return now.toLocaleTimeString('en-IN', { 
    hour: '2-digit', 
    minute: '2-digit',
    second: '2-digit'
  });
};
```

### **ETA Calculation:**
```javascript
export const calculateETA = (train) => {
  const distance = Math.abs(train.destination - train.position);
  const timeHours = distance / train.speed;
  const eta = new Date(Date.now() + timeHours * 3600000);
  return eta.toLocaleTimeString('en-IN', { 
    hour: '2-digit', 
    minute: '2-digit' 
  });
};
```

### **Position to Pixel Conversion:**
```javascript
export const kmToPixel = (km, totalKm, containerWidth) => {
  return (km / totalKm) * containerWidth;
};
```

### **Color by Train Type:**
```javascript
export const getTrainColor = (type) => {
  const colors = {
    'rajdhani': '#FF4444',
    'freight_heavy': '#8B4513',
    'vande_bharat': '#FFD700',
    'local_emu': '#4169E1',
    'express_passenger': '#32CD32'
  };
  return colors[type] || '#808080';
};
```


## 🎯 KEY FEATURES TO IMPLEMENT

### **Must Have (Priority 1):**
- [x] Scenario selection
- [x] Train status cards with live updates
- [x] Live map view with train positions
- [x] Conflict detection alert
- [x] AI recommendations display
- [x] Real-time updates (150ms interval)

### **Should Have (Priority 2):**
- [x] Distance-time graph
- [x] Conflict countdown timer
- [x] Energy savings display
- [x] Apply solution button
- [x] Next station and ETA

### **Nice to Have (Priority 3):**
- [ ] Speed profile graph
- [ ] Sound alerts
- [ ] Emergency stop button
- [ ] Historical data view
- [ ] Export report


## 🐛 COMMON ISSUES & SOLUTIONS

### **Issue 1: CORS Errors**
**Solution:** Ensure Vite proxy is configured correctly in `vite.config.js`

### **Issue 2: API Not Responding**
**Solution:** Check if backend is running on port 5000:
```bash
python backend/api/app.py
```

### **Issue 3: Real-Time Updates Not Working**
**Solution:** Check interval is running and state is updating:
```javascript
console.log('Update:', trains);
```

### **Issue 4: Graph Not Rendering**
**Solution:** Ensure Recharts data format is correct:
```javascript
// Correct format
const data = [
  { time: 0, RAJ: 56, FRT: 77 },
  { time: 0.2, RAJ: 56.5, FRT: 76.8 }
];
```

### **Issue 5: Train Positions Not Updating**
**Solution:** Check if simulation is running:
```javascript
setIsRunning(true);
```


## 📝 TESTING CHECKLIST

### **Scenario 1 Testing:**
- [ ] Load Scenario 1
- [ ] See RAJ and FRT trains
- [ ] Watch trains move towards each other
- [ ] Conflict detected at 7 minutes
- [ ] AI recommends "Stop FRT"
- [ ] Energy shows 363 kWh
- [ ] Apply solution works

### **Scenario 2 Testing:**
- [ ] Load Scenario 2
- [ ] See 4 trains (VB, LOC, MEMO, FRT2)
- [ ] Watch VB catching LOC
- [ ] Conflict detected at 24 minutes
- [ ] AI recommends "Multi-step switch"
- [ ] Energy shows 51 kWh
- [ ] Track 3 highlighted as available

### **Scenario 3 Testing:**
- [ ] Load Scenario 3
- [ ] See FRT (uphill) and EXP (downhill)
- [ ] Watch head-on approach
- [ ] Conflict detected at 8.2 minutes
- [ ] AI recommends "Stop EXP"
- [ ] Energy shows 53 kWh
- [ ] Savings shows 1418 kWh!
- [ ] Gradient penalty visible

### **General Testing:**
- [ ] Real-time updates smooth (150ms)
- [ ] No lag or freezing
- [ ] All colors correct
- [ ] Responsive layout
- [ ] No console errors


## 🎬 DEMO FLOW

### **Step 1: Introduction (30 sec)**
- Open frontend
- Show control room interface
- Explain 3-panel layout

### **Step 2: Scenario 1 (2 min)**
- Select Scenario 1
- Click Start
- Watch trains approach
- Point out conflict detection
- Show AI recommendation
- Explain "Stop FRT" decision

### **Step 3: Scenario 2 (2 min)**
- Select Scenario 2
- Show 4 trains
- Point out Track 3 available
- Show multi-step solution
- Explain track switching

### **Step 4: Scenario 3 (3 min - HIGHLIGHT)**
- Select Scenario 3
- Show gradient section
- Point out FRT uphill, EXP downhill
- Show conflict detection
- **Highlight 1418 kWh savings!**
- Explain priority override justification

### **Step 5: Closing (30 sec)**
- Show total energy saved
- Mention environmental impact
- Thank judges

**Total Demo Time: 8 minutes**


## 📚 REFERENCE LINKS

### **Backend Documentation:**
- `API_DOCUMENTATION.md` - Complete API reference
- `CORRECTED_AI_RECOMMENDATIONS.md` - All AI recommendations
- `FINAL_STATUS.md` - Backend status

### **Design Reference:**
- Control room aesthetic (dark theme)
- Real-time monitoring interface
- Railway operations dashboard

### **Libraries:**
- React: https://react.dev/
- Vite: https://vitejs.dev/
- Recharts: https://recharts.org/

---

## ✅ READY TO START!

**Backend Status:** ✅ Running on http://localhost:5000  
**API Status:** ✅ All endpoints functional  
**Scenarios:** ✅ All 3 tested and working  
**Documentation:** ✅ Complete  

**Next Command:**
```bash
cd frontend
npm create vite@latest . -- --template react
npm install
npm install recharts
npm run dev
```

**Then start building components following the implementation steps above!**

---

**Estimated Time:** 5-6 hours  
**Difficulty:** Medium  
**Priority:** High (needed for demo)

🚀 **LET'S BUILD THE FRONTEND!**
