# 📦 NeuralRail - Installation Guide

**Complete installation instructions for all platforms**

---

## 🖥️ System Requirements

### Minimum Requirements
- **OS:** Windows 10/11, macOS 10.15+, or Linux (Ubuntu 20.04+)
- **RAM:** 4 GB
- **Storage:** 500 MB free space
- **Python:** 3.8 or higher
- **Node.js:** 16.0 or higher
- **Browser:** Chrome 90+, Firefox 88+, or Edge 90+

### Recommended Requirements
- **OS:** Windows 11 or macOS 12+
- **RAM:** 8 GB or more
- **Storage:** 1 GB free space
- **Python:** 3.10 or higher
- **Node.js:** 18.0 or higher
- **Browser:** Latest Chrome or Firefox

---

## 📥 Installation Steps

### Step 1: Install Python

#### Windows
1. Download Python from: https://www.python.org/downloads/
2. Run installer
3. ✅ **Check "Add Python to PATH"**
4. Click "Install Now"
5. Verify installation:
```bash
python --version
```

#### macOS
```bash
# Using Homebrew
brew install python@3.10

# Verify
python3 --version
```

#### Linux (Ubuntu/Debian)
```bash
sudo apt update
sudo apt install python3 python3-pip

# Verify
python3 --version
```

---

### Step 2: Install Node.js

#### Windows
1. Download Node.js from: https://nodejs.org/
2. Run installer (LTS version recommended)
3. Follow installation wizard
4. Verify installation:
```bash
node --version
npm --version
```

#### macOS
```bash
# Using Homebrew
brew install node

# Verify
node --version
npm --version
```

#### Linux (Ubuntu/Debian)
```bash
# Using NodeSource
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Verify
node --version
npm --version
```

---

### Step 3: Clone/Download Project

#### Option A: Git Clone (Recommended)
```bash
git clone https://github.com/your-repo/neuralrail.git
cd neuralrail
```

#### Option B: Download ZIP
1. Download project ZIP file
2. Extract to desired location
3. Open terminal in project folder

---

### Step 4: Install Backend Dependencies

#### Windows
```bash
# Navigate to project root
cd neuralrail

# Install dependencies
pip install -r requirements.txt

# Verify installation
python -c "import flask; print('Flask installed')"
```

#### macOS/Linux
```bash
# Navigate to project root
cd neuralrail

# Install dependencies
pip3 install -r requirements.txt

# Verify installation
python3 -c "import flask; print('Flask installed')"
```

#### Common Issues

**Issue:** `pip: command not found`  
**Solution:**
```bash
# Windows
python -m pip install -r requirements.txt

# macOS/Linux
python3 -m pip install -r requirements.txt
```

**Issue:** Permission denied  
**Solution:**
```bash
# macOS/Linux - use --user flag
pip3 install --user -r requirements.txt
```

---

### Step 5: Install Frontend Dependencies

#### Windows
```bash
# Option A: Use batch file
INSTALL_FRONTEND.bat

# Option B: Manual installation
cd frontend
npm install
cd ..
```

#### macOS/Linux
```bash
cd frontend
npm install
cd ..
```

#### Common Issues

**Issue:** `npm: command not found`  
**Solution:** Reinstall Node.js, ensure it's in PATH

**Issue:** `EACCES: permission denied`  
**Solution:**
```bash
# macOS/Linux
sudo npm install -g npm
npm install
```

**Issue:** Network timeout  
**Solution:**
```bash
# Increase timeout
npm install --timeout=60000
```

---

## ✅ Verify Installation

### Test Backend
```bash
# Start backend
python backend/api/app.py

# In another terminal, test API
curl http://localhost:5000/api/health

# Expected output:
# {"status":"ok","message":"NeuralRail API is running"}
```

### Test Frontend
```bash
# Navigate to frontend
cd frontend

# Start dev server
npm run dev

# Open browser to: http://localhost:3000
```

---

## 🚀 Quick Start After Installation

### Start Backend (Terminal 1)
```bash
# Windows
START_DEMO.bat

# macOS/Linux
python3 backend/api/app.py
```

### Start Frontend (Terminal 2)
```bash
# Windows
START_FRONTEND.bat

# macOS/Linux
cd frontend
npm run dev
```

### Open Browser
Navigate to: `http://localhost:3000`

---

## 🔧 Configuration

### Backend Configuration

#### Change API Port
Edit `backend/api/app.py`, line ~last:
```python
app.run(debug=True, port=5000)  # Change 5000 to desired port
```

#### Enable/Disable Debug Mode
```python
app.run(debug=False, port=5000)  # Set to False for production
```

### Frontend Configuration

#### Change Frontend Port
Edit `frontend/vite.config.js`:
```javascript
export default defineConfig({
  server: {
    port: 3000,  // Change to desired port
    ...
  }
})
```

#### Change API Proxy
Edit `frontend/vite.config.js`:
```javascript
proxy: {
  '/api': {
    target: 'http://localhost:5000',  // Change if backend on different port
    ...
  }
}
```

---

## 🐛 Troubleshooting

### Python Issues

**Issue:** `ModuleNotFoundError: No module named 'flask'`  
**Solution:**
```bash
pip install flask flask-cors
```

**Issue:** `Python was not found`  
**Solution:** Add Python to PATH or use full path:
```bash
# Windows
C:\Python310\python.exe backend/api/app.py
```

### Node.js Issues

**Issue:** `Cannot find module 'react'`  
**Solution:**
```bash
cd frontend
rm -rf node_modules package-lock.json
npm install
```

**Issue:** `Port 3000 already in use`  
**Solution:**
```bash
# Kill process on port 3000
# Windows
netstat -ano | findstr :3000
taskkill /PID <PID> /F

# macOS/Linux
lsof -ti:3000 | xargs kill -9
```

### Network Issues

**Issue:** `ECONNREFUSED` when frontend calls backend  
**Solution:**
1. Ensure backend is running on port 5000
2. Check firewall settings
3. Verify proxy configuration in `vite.config.js`

**Issue:** CORS errors  
**Solution:** Backend already has CORS enabled. If issues persist:
```python
# In backend/api/app.py
CORS(app, resources={r"/api/*": {"origins": "*"}})
```

---

## 📦 Dependencies List

### Backend (Python)
```
Flask==2.3.0
Flask-CORS==4.0.0
numpy==1.24.0
```

### Frontend (Node.js)
```json
{
  "react": "^18.2.0",
  "react-dom": "^18.2.0",
  "recharts": "^2.10.3",
  "lucide-react": "^0.294.0",
  "vite": "^5.0.8"
}
```

---

## 🔄 Updating Dependencies

### Update Backend
```bash
pip install --upgrade -r requirements.txt
```

### Update Frontend
```bash
cd frontend
npm update
```

---

## 🗑️ Uninstallation

### Remove Backend Dependencies
```bash
pip uninstall -r requirements.txt -y
```

### Remove Frontend Dependencies
```bash
cd frontend
rm -rf node_modules package-lock.json
```

### Remove Project
```bash
# Delete project folder
rm -rf neuralrail
```

---

## 🌐 Deployment (Optional)

### Backend Deployment

#### Using Gunicorn (Production)
```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 backend.api.app:app
```

#### Using Docker
```dockerfile
FROM python:3.10
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "backend/api/app.py"]
```

### Frontend Deployment

#### Build for Production
```bash
cd frontend
npm run build
```

Output in `frontend/dist/` folder.

#### Serve Static Files
```bash
npm install -g serve
serve -s dist -p 3000
```

---

## 📚 Additional Resources

### Documentation
- Python: https://docs.python.org/3/
- Node.js: https://nodejs.org/docs/
- React: https://react.dev/
- Vite: https://vitejs.dev/
- Flask: https://flask.palletsprojects.com/

### Project Documentation
- `README.md` - Project overview
- `API_DOCUMENTATION.md` - API reference
- `FRONTEND_COMPLETE.md` - Frontend guide
- `COMPLETE_SYSTEM_GUIDE.md` - Full system docs

---

## ✅ Installation Checklist

- [ ] Python 3.8+ installed
- [ ] Node.js 16+ installed
- [ ] Project downloaded/cloned
- [ ] Backend dependencies installed
- [ ] Frontend dependencies installed
- [ ] Backend starts successfully
- [ ] Frontend starts successfully
- [ ] Browser shows interface
- [ ] API calls working
- [ ] No console errors

---

## 🎉 Success!

If you've completed all steps:
- ✅ Backend running on `http://localhost:5000`
- ✅ Frontend running on `http://localhost:3000`
- ✅ System fully functional

**You're ready to use NeuralRail!** 🚀

---

## 📞 Support

### Common Issues
1. Check Python/Node.js versions
2. Verify all dependencies installed
3. Check firewall/antivirus settings
4. Review error messages carefully
5. Check documentation files

### Getting Help
- Review troubleshooting section
- Check GitHub issues (if applicable)
- Contact team members
- Review error logs

---

**Installation Time:** 10-15 minutes  
**Difficulty:** Easy  
**Status:** ✅ Complete

**Happy coding!** 💻
