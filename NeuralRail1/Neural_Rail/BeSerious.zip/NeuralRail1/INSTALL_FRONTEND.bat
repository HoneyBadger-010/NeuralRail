@echo off
echo ========================================
echo   NeuralRail Frontend Installation
echo ========================================
echo.
echo Installing frontend dependencies...
echo This may take a few minutes...
echo.

cd frontend
call npm install

echo.
echo ========================================
echo   Installation Complete!
echo ========================================
echo.
echo Next steps:
echo 1. Start backend: python backend/api/app.py
echo 2. Start frontend: npm run dev (in frontend folder)
echo    OR use START_FRONTEND.bat
echo.
echo Frontend will run on: http://localhost:3000
echo Backend API on: http://localhost:5000
echo.

pause
