# 🏗️ NeuralRail - System Architecture

**Complete technical architecture documentation**

---

## 🎯 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        USER                                 │
│                     (Web Browser)                           │
└────────────────────────┬────────────────────────────────────┘
                         │
                         │ HTTP
                         ↓
┌─────────────────────────────────────────────────────────────┐
│                   FRONTEND LAYER                            │
│                  (React + Vite)                             │
│                  Port: 3000                                 │
│                                                             │
│  ┌──────────────┬─────────────────────┬─────────────────┐  │
│  │  Left Panel  │   Middle Panel      │   Right Panel   │  │
│  │              │                     │                 │  │
│  │ - Scenarios  │ - Live Map          │ - Conflict      │  │
│  │ - Controls   │ - Graphs            │   Alert         │  │
│  │ - Train      │ - Elevation         │ - AI Solutions  │  │
│  │   Status     │   Profile           │ - Energy Meter  │  │
│  └──────────────┴─────────────────────┴─────────────────┘  │
│                                                             │
│  State Management: React Hooks (useState, useEffect)        │
│  API Client: Fetch API                                      │
│  Visualization: Recharts                                    │
└────────────────────────┬────────────────────────────────────┘
                         │
                         │ REST API (JSON)
                         │ Polling: 150ms
                         ↓
┌─────────────────────────────────────────────────────────────┐
│                    API LAYER                                │
│                  (Flask REST API)                           │
│                   Port: 5000                                │
│                                                             │
│  Endpoints:                                                 │
│  - GET  /api/scenarios                                      │
│  - POST /api/scenario/<id>/start                            │
│  - POST /api/simulation/step                                │
│  - POST /api/conflict/analyze                               │
│  - GET  /api/health                                         │
│                                                             │
│  CORS: Enabled                                              │
│  Format: JSON                                               │
└────────────────────────┬────────────────────────────────────┘
                         │
                         │ Function Calls
                         ↓
┌─────────────────────────────────────────────────────────────┐
│                   BACKEND LAYER                             │
│                    (Python)                                 │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │           Railway Simulator                          │  │
│  │  - Train movement                                    │  │
│  │  - Position tracking                                 │  │
│  │  - State management                                  │  │
│  └──────────────────────────────────────────────────────┘  │
│                         ↓                                   │
│  ┌──────────────────────────────────────────────────────┐  │
│  │         Conflict Detector                            │  │
│  │  - Collision prediction                              │  │
│  │  - 7-30 min lookahead                                │  │
│  │  - Severity assessment                               │  │
│  └──────────────────────────────────────────────────────┘  │
│                         ↓                                   │
│  ┌──────────────────────────────────────────────────────┐  │
│  │         Conflict Resolver (AI)                       │  │
│  │  - Solution generation                               │  │
│  │  - Priority evaluation                               │  │
│  │  - Energy optimization                               │  │
│  │  - Track constraint validation                       │  │
│  └──────────────────────────────────────────────────────┘  │
│                         ↓                                   │
│  ┌──────────────────────────────────────────────────────┐  │
│  │         Physics Engine                               │  │
│  │  - Energy calculations                               │  │
│  │  - Gradient penalties                                │  │
│  │  - Regenerative braking                              │  │
│  │  - Mass-based physics                                │  │
│  └──────────────────────────────────────────────────────┘  │
│                         ↓                                   │
│  ┌──────────────────────────────────────────────────────┐  │
│  │         AI Explainer                                 │  │
│  │  - Decision explanations                             │  │
│  │  - Alternative analysis                              │  │
│  │  - Similar case retrieval                            │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────────┐
│                    DATA LAYER                               │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │         Railway Network Data                         │  │
│  │  - Stations (CSMT, Thane, Kalyan, etc.)             │  │
│  │  - Track segments                                    │  │
│  │  - Gradients & elevations                            │  │
│  │  - Speed limits                                      │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │         Train Type Data                              │  │
│  │  - Rajdhani, Freight, Vande Bharat, etc.            │  │
│  │  - Mass, speed, acceleration                         │  │
│  │  - Priority levels                                   │  │
│  │  - Energy characteristics                            │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │         Scenario Definitions                         │  │
│  │  - Scenario 1: Head-On Collision                    │  │
│  │  - Scenario 2: Multi-Train Coordination             │  │
│  │  - Scenario 3: Bhor Ghat Challenge                  │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔄 Data Flow

### 1. Scenario Start Flow
```
User clicks Scenario
       ↓
Frontend: POST /api/scenario/1/start
       ↓
Backend: Initialize simulator
       ↓
Backend: Add trains to simulation
       ↓
Backend: Return initial state
       ↓
Frontend: Display trains on map
       ↓
Frontend: Start polling loop
```

### 2. Real-Time Update Flow
```
Every 150ms:
       ↓
Frontend: POST /api/simulation/step
       ↓
Backend: Move all trains (10 seconds)
       ↓
Backend: Check for conflicts
       ↓
Backend: Update energy calculations
       ↓
Backend: Return current state
       ↓
Frontend: Update UI
  - Train positions
  - Graph data
  - Energy meters
  - Conflict alerts
```

### 3. Conflict Resolution Flow
```
Conflict detected
       ↓
Frontend: POST /api/conflict/analyze
       ↓
Backend: Get train data
       ↓
Backend: Generate solutions
  - Stop train A
  - Stop train B
  - Slow both
  - Switch tracks
       ↓
Backend: Calculate energy for each
       ↓
Backend: Apply priority rules
       ↓
Backend: Score solutions
       ↓
Backend: Generate explanation
       ↓
Backend: Return sorted solutions
       ↓
Frontend: Display recommendations
       ↓
User: Click "APPLY SOLUTION"
       ↓
Backend: Execute solution
```

---

## 🧩 Component Architecture

### Frontend Components

```
App.jsx (Root)
├── Navbar.jsx
│   ├── Logo
│   ├── Live Indicator
│   ├── Clock
│   └── Sound Toggle
│
├── LeftPanel/
│   ├── ScenarioSelector.jsx
│   │   └── Scenario Cards (3)
│   ├── PlaybackControls.jsx
│   │   ├── Play/Pause Button
│   │   ├── Reset Button
│   │   └── Speed Buttons (1x-10x)
│   └── TrainStatusCard.jsx (per train)
│       ├── Speed Bar
│       ├── Position Progress
│       ├── ETA Display
│       └── Metrics (energy, mass, priority)
│
├── MiddlePanel/
│   ├── LiveMapView.jsx
│   │   ├── Station Markers
│   │   ├── Track Lines
│   │   ├── Train Markers
│   │   └── Conflict Zone
│   ├── ElevationProfile.jsx
│   │   ├── Gradient Visualization
│   │   ├── Train Markers
│   │   └── Stats Display
│   └── DistanceTimeGraph.jsx
│       ├── Recharts LineChart
│       ├── Train Lines
│       └── Conflict Marker
│
└── RightPanel/
    ├── ConflictAlert.jsx
    │   ├── Warning Icon
    │   ├── Train Badges
    │   ├── Countdown Timer
    │   └── Severity Badge
    ├── SolutionCard.jsx (per solution)
    │   ├── Action Description
    │   ├── Energy/Delay Metrics
    │   ├── Priority Status
    │   └── Apply Button
    └── EnergyMeter.jsx
        ├── System Energy Gauge
        ├── Savings Display
        ├── CO₂ Calculation
        └── Homes Powered
```

### Backend Modules

```
backend/
├── api/
│   └── app.py
│       ├── Flask app initialization
│       ├── CORS configuration
│       ├── Route handlers
│       └── Helper functions
│
├── simulation/
│   ├── railway_simulator.py
│   │   ├── RailwaySimulator class
│   │   ├── add_train()
│   │   ├── step()
│   │   ├── detect_conflicts()
│   │   └── get_system_status()
│   └── train.py
│       ├── Train class
│       ├── move()
│       ├── accelerate()
│       ├── brake()
│       └── get_status()
│
├── optimizer/
│   └── conflict_resolver.py
│       ├── ConflictResolver class
│       ├── analyze_conflict()
│       ├── generate_solutions()
│       ├── calculate_energy()
│       └── score_solution()
│
├── physics/
│   └── energy_calculator.py
│       ├── calculate_kinetic_energy()
│       ├── calculate_braking_energy()
│       ├── calculate_acceleration_energy()
│       ├── apply_gradient_penalty()
│       └── apply_regenerative_braking()
│
├── ai_agent/
│   └── llm_explainer.py
│       ├── LLMExplainer class
│       ├── explain_decision()
│       ├── compare_alternatives()
│       └── find_similar_cases()
│
└── data/
    └── railway_network.py
        ├── STATIONS dict
        ├── TRACK_SEGMENTS list
        ├── TRAIN_TYPES dict
        └── Helper functions
```

---

## 🔐 Security Architecture

### Frontend Security
- **Input Validation:** All user inputs validated
- **XSS Protection:** React auto-escapes content
- **HTTPS Ready:** Can be deployed with SSL
- **No Sensitive Data:** All data is simulation

### Backend Security
- **CORS:** Configured for localhost (dev)
- **Input Validation:** All API inputs validated
- **Error Handling:** Graceful error responses
- **Rate Limiting:** Can be added for production

### API Security
- **Authentication:** Not required (demo)
- **Authorization:** Not required (demo)
- **HTTPS:** Recommended for production
- **API Keys:** Can be added for production

---

## 📊 State Management

### Frontend State (React Hooks)
```javascript
// Main App State
const [scenarios, setScenarios] = useState([]);
const [currentScenario, setCurrentScenario] = useState(null);
const [trains, setTrains] = useState([]);
const [conflict, setConflict] = useState(null);
const [solutions, setSolutions] = useState([]);
const [history, setHistory] = useState([]);
const [systemEnergy, setSystemEnergy] = useState(0);
const [energySaved, setEnergySaved] = useState(0);
const [isRunning, setIsRunning] = useState(false);
const [currentTime, setCurrentTime] = useState(0);
const [playbackSpeed, setPlaybackSpeed] = useState(1);
const [soundEnabled, setSoundEnabled] = useState(true);
```

### Backend State (Python Objects)
```python
# Simulator State
self.trains = {}  # Dict of train_id -> Train object
self.current_time = 0  # Simulation time in seconds
self.conflicts_detected = []  # List of conflicts
self.total_system_energy_joules = 0  # Total energy
self.simulation_history = []  # History for replay
```

---

## 🔄 Communication Protocol

### Request Format
```json
{
  "method": "POST",
  "url": "/api/simulation/step",
  "headers": {
    "Content-Type": "application/json"
  },
  "body": {}
}
```

### Response Format
```json
{
  "time_minutes": 0.2,
  "trains": [
    {
      "id": "RAJ",
      "position": 56.28,
      "speed": 100.0,
      "state": "moving",
      "energy_kwh": 12.5,
      ...
    }
  ],
  "conflicts": [
    {
      "train_a": "RAJ",
      "train_b": "FRT",
      "position_km": 68.9,
      "time_minutes": 7.0,
      "severity": "critical"
    }
  ],
  "system_energy_kwh": 20.7,
  "history": [...]
}
```

---

## ⚡ Performance Optimization

### Frontend Optimizations
1. **React.memo:** Prevent unnecessary re-renders
2. **useCallback:** Memoize callback functions
3. **useMemo:** Memoize expensive calculations
4. **Lazy Loading:** Load components on demand
5. **Code Splitting:** Split bundle by route

### Backend Optimizations
1. **Efficient Algorithms:** O(n²) for conflict detection
2. **Caching:** Cache scenario data
3. **Batch Processing:** Process multiple trains together
4. **Memory Management:** Limit history to 1000 points
5. **Fast JSON:** Use optimized JSON serialization

### Network Optimizations
1. **Polling Interval:** 150ms (configurable)
2. **Data Compression:** Gzip enabled
3. **Minimal Payloads:** Only send necessary data
4. **Connection Reuse:** Keep-alive enabled

---

## 🧪 Testing Architecture

### Frontend Testing
- **Unit Tests:** Component testing (Jest)
- **Integration Tests:** API integration
- **E2E Tests:** Full user flows (Cypress)
- **Visual Tests:** Screenshot comparison

### Backend Testing
- **Unit Tests:** Function testing (pytest)
- **Integration Tests:** API endpoint testing
- **Scenario Tests:** All 3 scenarios validated
- **Performance Tests:** Load testing

---

## 📈 Scalability Architecture

### Horizontal Scaling
```
Load Balancer
     ↓
┌────────┬────────┬────────┐
│ API 1  │ API 2  │ API 3  │
└────────┴────────┴────────┘
     ↓
┌────────────────────────────┐
│   Shared State (Redis)     │
└────────────────────────────┘
```

### Vertical Scaling
- Increase server resources
- Optimize algorithms
- Add caching layers
- Use faster hardware

### Database Integration (Future)
```
API Layer
     ↓
┌────────────────────────────┐
│   PostgreSQL Database      │
│   - Train positions        │
│   - Conflict history       │
│   - Energy metrics         │
│   - User sessions          │
└────────────────────────────┘
```

---

## 🔧 Deployment Architecture

### Development
```
Localhost:3000 (Frontend)
     ↓
Localhost:5000 (Backend)
```

### Production
```
CDN (Static Assets)
     ↓
HTTPS Load Balancer
     ↓
┌────────────────────────────┐
│   Frontend (Nginx)         │
│   Port: 443                │
└────────────────────────────┘
     ↓
┌────────────────────────────┐
│   Backend (Gunicorn)       │
│   Port: 8000               │
└────────────────────────────┘
     ↓
┌────────────────────────────┐
│   Database (PostgreSQL)    │
└────────────────────────────┘
```

---

## 🎯 Architecture Decisions

### Why React?
- Component-based architecture
- Large ecosystem
- Fast development
- Easy state management

### Why Flask?
- Lightweight and fast
- Easy to learn
- RESTful API support
- Python ecosystem

### Why Vite?
- Fast development server
- Hot module replacement
- Optimized builds
- Modern tooling

### Why Recharts?
- React-friendly
- Responsive charts
- Easy customization
- Good documentation

### Why Polling (not WebSockets)?
- Simpler implementation
- Easier debugging
- Sufficient for demo
- Can upgrade later

---

## 📊 System Metrics

### Performance Targets
- **API Response:** < 100ms
- **Frontend Update:** 150ms
- **Page Load:** < 2s
- **Memory Usage:** < 200 MB
- **CPU Usage:** < 50%

### Reliability Targets
- **Uptime:** 99.9%
- **Error Rate:** < 0.1%
- **Data Accuracy:** 100%
- **Conflict Detection:** 100%

---

**This architecture supports a scalable, maintainable, and performant system!** 🏗️

