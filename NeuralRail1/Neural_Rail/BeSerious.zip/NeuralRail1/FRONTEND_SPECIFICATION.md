# 🎯 NeuralRail Frontend - Final Specification

## ✅ **Confirmed Requirements**

### **1. Layout**
- **3-Panel Design:** Left (30%) | Middle (50%) | Right (20%)
- **Dark Theme:** Railway control room aesthetic
- **Live Feed:** No playback controls on main view

### **2. Map (MVP - Most Important)**
- **Full Route:** CSMT (0km) to PUNE (192km) - always rendered
- **Auto-Zoom:** Automatically zooms to scenario section on load
- **Manual Zoom:** Slider + buttons (100%-300%)
- **Pan:** Drag to pan across full route
- **Track Display:** Single line per track
- **Variable Tracks:** 
  - CSMT-THANE: 4 tracks
  - THANE-KYN: 2 tracks
  - KYN-KARJAT: 2 tracks
  - KARJAT-LNL: 3 tracks (Bhor Ghat)
  - LNL-PUNE: 2 tracks

### **3. Map Elements**
- ✅ **Stations:** Name only (CSMT, THANE, KYN, KARJAT, LNL, PUNE)
- ✅ **Distance Markers:** Every 10-20 km
- ✅ **Track Labels:** "Track 1", "Track 2", etc.
- ✅ **Gradient Visual:** Slope indicator for Bhor Ghat (80-106 km)
- ✅ **Train Dots:** Small colored dots ON track lines
- ✅ **Train IDs:** Label above each dot
- ✅ **Track Status:** Indicators for blocked/occupied tracks

### **4. Train Representation**
- **Small dots** (colored by train type)
- **Train ID** label above dot
- **Hover:** Shows full details (speed, position, etc.)

### **5. Left Panel**
- Scenario selector (3 buttons to load scenarios)
- Train list (compact view)
- Section status

### **6. Right Panel**
- Conflict alert (when detected)
- AI recommendations (cards with details)
- Energy savings display
- **Playback controls** (only for AI simulation)

### **7. Middle Panel**
- **Top:** Live map with zoom controls
- **Bottom:** Distance-time graph

### **8. Priority Order**
1. Clear train positions on map
2. Real-time updates
3. Conflict detection alerts
4. AI recommendations
5. Graphs and charts
6. Train details
7. Energy savings display

---

## 🗺️ **Map Technical Specification**

### **Full Route Data:**
```javascript
const ROUTE = {
  totalDistance: 192, // km
  stations: [
    { code: 'CSMT', name: 'CSMT', km: 0 },
    { code: 'THANE', name: 'Thane', km: 34 },
    { code: 'KYN', name: 'Kalyan', km: 54 },
    { code: 'KARJAT', name: 'Karjat', km: 80 },
    { code: 'LNL', name: 'Lonavala', km: 106 },
    { code: 'PUNE', name: 'Pune', km: 192 }
  ],
  segments: [
    { from: 0, to: 34, tracks: 4, gradient: 'flat' },      // CSMT-THANE
    { from: 34, to: 54, tracks: 2, gradient: 'flat' },     // THANE-KYN
    { from: 54, to: 80, tracks: 2, gradient: 'gentle' },   // KYN-KARJAT
    { from: 80, to: 106, tracks: 3, gradient: 'steep' },   // KARJAT-LNL (Bhor Ghat)
    { from: 106, to: 192, tracks: 2, gradient: 'down' }    // LNL-PUNE
  ]
};
```

### **Zoom Behavior:**
```javascript
// On scenario load:
Scenario 1: Auto-zoom to 54-80 km (KYN-KARJAT)
Scenario 2: Auto-zoom to 0-34 km (CSMT-THANE)
Scenario 3: Auto-zoom to 80-106 km (KARJAT-LNL)

// User can:
- Zoom out to see full 0-192 km
- Zoom in to 300% for detail
- Pan left/right to see other sections
```

### **Track Rendering:**
```javascript
// Render tracks based on segment
for each segment:
  if (segment.from <= viewStart && segment.to >= viewEnd):
    render segment.tracks number of tracks
    
// Example at km 50 (in THANE-KYN segment):
  Track 1: ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Track 2: ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  (only 2 tracks shown)

// Example at km 10 (in CSMT-THANE segment):
  Track 1: ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Track 2: ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Track 3: ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Track 4: ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  (4 tracks shown)
```

### **Gradient Visual:**
```javascript
// For Bhor Ghat section (80-106 km):
Show elevation profile:
  150m ╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱ 625m
      80km                      106km
      
Label: "1.83% Gradient ⛰️"
```

---

## 🎨 **Visual Design**

### **Color Scheme:**
```css
/* Background */
--bg-dark: #0a0e1a;
--bg-panel: #111827;
--bg-card: #1f2937;

/* Tracks */
--track-line: #4b5563;
--track-blocked: #ef4444;
--track-available: #10b981;

/* Trains */
--train-rajdhani: #FF4444;
--train-freight: #8B4513;
--train-vb: #FFD700;
--train-local: #4169E1;
--train-express: #32CD32;

/* Status */
--conflict: #ef4444;
--warning: #f59e0b;
--success: #10b981;
```

### **Typography:**
```css
/* Control Room Font */
font-family: 'Roboto Mono', monospace; /* For numbers */
font-family: 'Inter', sans-serif;      /* For text */
```

---

## 🔧 **Component Structure**

```
App.jsx
├── Navbar.jsx (Logo, Clock, Status)
├── MainLayout.jsx
│   ├── LeftPanel.jsx
│   │   ├── ScenarioLoader.jsx (3 buttons)
│   │   └── TrainList.jsx (compact)
│   │
│   ├── MiddlePanel.jsx
│   │   ├── MapView.jsx (MAIN - with zoom/pan)
│   │   │   ├── StationMarkers.jsx
│   │   │   ├── DistanceMarkers.jsx
│   │   │   ├── TrackLines.jsx (variable count)
│   │   │   ├── TrackLabels.jsx
│   │   │   ├── GradientIndicator.jsx
│   │   │   ├── TrainMarkers.jsx (dots)
│   │   │   ├── ConflictZone.jsx
│   │   │   └── ZoomControls.jsx
│   │   │
│   │   └── DistanceTimeGraph.jsx
│   │
│   └── RightPanel.jsx
│       ├── ConflictAlert.jsx
│       ├── AIRecommendations.jsx
│       ├── SimulationControls.jsx (playback)
│       └── EnergySavings.jsx
```

---

## 📊 **Data Flow**

```javascript
1. User clicks "Load Scenario 1"
   ↓
2. API: POST /api/scenario/1/start
   ↓
3. Receives:
   - trains: [{id, position, speed, track, color}]
   - track_info: {tracks, section_start_km, section_end_km}
   - stations: [...]
   ↓
4. Map auto-zooms to section (54-80 km)
   ↓
5. Renders:
   - 2 tracks (KYN-KARJAT segment)
   - 2 train dots on Track 1
   - Track 2 shows "BLOCKED" indicator
   ↓
6. Real-time updates (150ms):
   - POST /api/simulation/step
   - Update train positions
   - Check for conflicts
   ↓
7. Conflict detected:
   - Show alert in right panel
   - POST /api/conflict/analyze
   - Show AI recommendations
```

---

## ✅ **Ready to Build!**

**All specifications confirmed:**
- ✅ Full route map (0-192 km)
- ✅ Auto-zoom to scenario section
- ✅ Variable tracks per segment (2-4)
- ✅ Distance markers every 10-20 km
- ✅ Gradient visual for Bhor Ghat
- ✅ Track labels
- ✅ Zoom slider + buttons
- ✅ Small dots for trains
- ✅ Train ID labels
- ✅ Dark control room theme

**Building now...** 🚀
