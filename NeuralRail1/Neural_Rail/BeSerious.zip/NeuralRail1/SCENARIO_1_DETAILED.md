# NeuralRail - Scenario 1: Head-On Collision - Priority Conflict

## Overview
**Scenario Name:** Head-On Collision - Priority Conflict  
**Conflict Section:** Thane-Kalyan (34 km to 54 km)  
**Conflict Type:** Head-on collision - both trains on Track 1  
**Key Challenge:** Track 2 is OCCUPIED by MEMO (Local EMU), so no track switching possible

---

## The Story

**Rajdhani Express (RAJ)** has left CSMT and is now at **15 km**, traveling at **100 km/h** towards Pune on **Track 1**.

**Heavy Freight (FRT)** has left Kalyan and is now at **55 km** (just past Kalyan), traveling at **50 km/h** towards CSMT on **Track 1**.

Both trains will enter the **Thane-Kalyan section (34-54 km)** which has only **2 tracks**. 

**Problem:** Track 2 is already **OCCUPIED by MEMO** (a Local EMU train at 45 km going to Kalyan).

**Result:** Both RAJ and FRT must use Track 1 → **HEAD-ON COLLISION!**

---

## Track Layout

```
CSMT (0 km)              THANE (34 km)                    KALYAN (54 km)
    |                        |                                |
    |    4 TRACKS            |         2 TRACKS               |
    |                        |                                |
====╬════════════════════════╬════════════════════════════════╬====  TRACK 1
    |      [RAJ →]           |                                | [← FRT]
    |       15 km            |                                |  55 km
    |                        |                                |
====╬════════════════════════╬════════════════════════════════╬====  TRACK 2
    |                        |        [MEMO →]                |
    |                        |         45 km                  |
    |                        |      (OCCUPIED!)               |
    |                        |                                |
====╬════════════════════════╬                                     TRACK 3 (CSMT-Thane only)
    |     [LOC1 →]           |                                
    |      15 km             |                                
    |                        |                                
====╬════════════════════════╬                                     TRACK 4 (CSMT-Thane only)
    |        [← LOC2]        |                                
    |         25 km          |                                
```

**Beyond Kalyan (showing full network activity):**
```
KALYAN (54 km)           KARJAT (80 km)          LONAVALA (106 km)         PUNE (192 km)
    |                        |                        |                        |
====╬════════════════════════╬════════════════════════╬════════════════════════╬====
    |      [LOC3 →]          |     [EXP1 →]           |      [FRT2 →]          |
    |       70 km            |      90 km             |       150 km           |
```

---

## Conflict Calculation

### Formula
```
Time to Collision = Distance Between Trains / Closing Speed
```

### Calculation
```
RAJ Position:     15 km
FRT Position:     55 km
Distance Between: 55 - 15 = 40 km

RAJ Speed:        100 km/h (forward →)
FRT Speed:        50 km/h (backward ←)
Closing Speed:    100 + 50 = 150 km/h (head-on collision)

Time to Collision = 40 km / 150 km/h
                  = 0.267 hours
                  = 0.267 × 60 minutes
                  = 16 minutes
```

### Collision Point Calculation
```
In 16 minutes (0.267 hours):
- RAJ travels: 100 km/h × 0.267 h = 26.7 km
- RAJ new position: 15 + 26.7 = 41.7 km

Collision Point: 41.7 km (in Thane-Kalyan section, between 34-54 km) ✓
```

---

## Conflict Detection Timing

**We want more demo time**, so conflict is detected when trains are closer:

```
Detection Point:
- RAJ at ~32 km (approaching Thane)
- FRT at ~45 km (in Thane-Kalyan section)
- Distance between: 45 - 32 = 13 km

Time for RAJ to reach 32 km from start:
= (32 - 15) / 100 × 60 = 10.2 minutes of demo time!

Time to collision AFTER detection:
= 13 km / 150 km/h × 60 = 5.2 minutes

This creates URGENCY - only ~5 minutes to act!
```

---

## Main Conflict Trains

### Train 1: RAJ (Rajdhani Express)
| Property | Value |
|----------|-------|
| Train ID | RAJ |
| Type | Rajdhani (Premium Passenger) |
| Priority | 1 (Highest) |
| Mass | 850 tons |
| Position | 15 km (CSMT-Thane section) |
| Speed | 100 km/h |
| Direction | Forward (→) |
| Destination | Pune (192 km) |
| Track | 1 |
| Color | #FF4444 (Red) |

### Train 2: FRT (Heavy Freight)
| Property | Value |
|----------|-------|
| Train ID | FRT |
| Type | Freight Heavy (Coal/Container) |
| Priority | 5 (Lowest) |
| Mass | 4200 tons |
| Position | 55 km (just past Kalyan) |
| Speed | 50 km/h |
| Direction | Backward (←) |
| Destination | CSMT (0 km) |
| Track | 1 |
| Color | #8B4513 (Brown) |

---

## All Trains in Scenario

### CSMT-Kalyan Section (Conflict Zone)
| Train | Type | Position | Speed | Direction | Track | Purpose |
|-------|------|----------|-------|-----------|-------|---------|
| RAJ | Rajdhani | 15 km | 100 km/h | Forward | 1 | **CONFLICT** |
| FRT | Freight | 55 km | 50 km/h | Backward | 1 | **CONFLICT** |
| MEMO | Local EMU | 45 km | 60 km/h | Forward | 2 | **Blocks Track 2** |
| LOC1 | Local EMU | 15 km | 80 km/h | Forward | 3 | Normal operation |
| LOC2 | Local EMU | 25 km | 75 km/h | Backward | 4 | Normal operation |

### Beyond Kalyan (Network Activity)
| Train | Type | Position | Speed | Direction | Track | Section |
|-------|------|----------|-------|-----------|-------|---------|
| LOC3 | Local EMU | 70 km | 65 km/h | Forward | 2 | Kalyan-Karjat |
| EXP1 | Express | 90 km | 60 km/h | Forward | 1 | Bhor Ghat |
| FRT2 | Freight | 150 km | 70 km/h | Forward | 2 | Lonavala-Pune |

---

## Why Track Switching is NOT Possible

**Track 2 is OCCUPIED by MEMO:**
- MEMO is a Local EMU at 45 km
- Moving towards Kalyan at 60 km/h
- Cannot switch RAJ or FRT to Track 2

**Tracks 3 & 4 don't exist in Thane-Kalyan section:**
- Only available in CSMT-Thane section (4 tracks)
- Thane-Kalyan has only 2 tracks

---

## AI Recommendations

### Option 1: Stop FRT at Thane Junction (RECOMMENDED) ✓
```
Action:     Stop FRT at Thane Junction (34 km)
Why:        Thane has 10 platforms - can hold freight train
Energy:     ~200 kWh (stopping 4200 ton freight at 50 km/h)
Delay:      FRT waits ~10 minutes for RAJ to pass
Priority:   Respected (RAJ Priority 1 > FRT Priority 5)
Result:     RAJ passes safely, FRT resumes after
```

### Option 2: Stop RAJ before Thane (NOT RECOMMENDED) ✗
```
Action:     Stop RAJ before entering Thane-Kalyan section
Why NOT:    Priority violation! RAJ is Priority 1
Energy:     ~400 kWh (stopping 850 ton train at 100 km/h)
Delay:      RAJ waits 15+ minutes
Impact:     1000+ passengers delayed, schedule disruption
```

### Option 3: Slow Both Trains
```
Action:     Reduce speed of both trains
Energy:     ~100 kWh
Delay:      Both delayed 5-8 minutes
Problem:    Temporary fix - doesn't resolve conflict permanently
```

---

## Why Stop FRT (Decision Logic)

1. **Priority:** RAJ has Priority 1 (highest), FRT has Priority 5 (lowest)
2. **Passengers:** RAJ carries 1000+ passengers with strict schedule
3. **Ease of Stopping:** FRT already slow (50 km/h), easier to stop
4. **Holding Point:** Thane Junction has 10 platforms - perfect for holding freight
5. **Energy:** Stopping slow freight uses less energy than stopping fast passenger train

---

## Timeline of Events

```
T+0s:      Scenario starts
           - RAJ at 5 km, moving forward at 100 km/h
           - FRT at 52 km, moving backward at 50 km/h
           - MEMO at 45 km on Track 2 (blocking)
           - LOC1, LOC2 on Tracks 3, 4 (normal operation)
           - EXP1, FRT2, LOC3 beyond Kalyan (network activity)

T+45s:     Conflict Detection Alert (after ~45 seconds demo time)
           - RAJ now at ~32 km (approaching Thane)
           - FRT now at ~40 km (in Thane-Kalyan section)
           - Distance between: ~8 km
           - Time to collision: ~3.2 minutes - URGENT!
           - AI generates solution options

T+~18.8min: Predicted collision if NO action taken
           - Collision at 36.3 km (Thane-Kalyan section)
           - Both trains on Track 1
```

---

## Thane Junction - The Solution Point

**Why Thane Junction is ideal for stopping FRT:**

| Feature | Value |
|---------|-------|
| Location | 34 km |
| Platforms | 10 |
| Can hold freight | Yes |
| Track capacity | Multiple holding lines |

---

## Judge Talking Points

1. **Long Demo Time:** "Watch the trains move for ~45 seconds before conflict is detected"

2. **Full Network View:** "See trains operating across the entire Mumbai-Pune corridor"

3. **Urgent Detection:** "When detected, only 3.2 minutes to collision - creates urgency!"

4. **Precise Calculation:** "Time = Distance / Closing Speed = 47km / 150km/h = 18.8 min"

5. **Track Constraint:** "Track 2 is occupied by MEMO, so track switching is not possible"

6. **Priority Respect:** "AI recommends stopping FRT (Priority 5) to let RAJ (Priority 1) pass"

7. **Infrastructure Awareness:** "Thane Junction has 10 platforms - perfect holding point"

---

## Summary

| Metric | Value |
|--------|-------|
| Conflict Type | Head-on collision |
| Conflict Section | Thane-Kalyan (34-54 km) |
| Initial Distance | 40 km |
| Closing Speed | 150 km/h |
| Total Time to Collision | 16 minutes |
| Collision Point | 41.7 km |
| Demo Time Before Detection | ~45 seconds |
| Time After Detection | ~5.2 minutes (URGENT!) |
| Why No Track Switch | Track 2 occupied by MEMO |
| AI Recommendation | Stop FRT at Thane Junction |
| Total Trains | 8 (showing full network) |
