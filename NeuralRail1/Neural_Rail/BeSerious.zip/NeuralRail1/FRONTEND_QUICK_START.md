# 🚀 Frontend Quick Start Guide

**5-Minute Setup | 5-Hour Build | Ready for Demo**

---

## ⚡ INSTANT SETUP

```bash
# 1. Navigate to frontend
cd frontend

# 2. Initialize React + Vite
npm create vite@latest . -- --template react

# 3. Install dependencies
npm install
npm install recharts

# 4. Start development server
npm run dev
```

**Frontend runs on:** `http://localhost:3000`  
**Backend API on:** `http://localhost:5000`

---

## 🎯 WHAT TO BUILD

### **3-Panel Layout:**
```
┌─────────────────────────────────────────────┐
│ LEFT (30%)  │ MIDDLE (50%)  │ RIGHT (20%)  │
│ Scenarios   │ Live Map      │ AI Assistant │
│ Train Cards │ Graph         │ Solutions    │
└─────────────────────────────────────────────┘
```

### **Core Components:**
1. **Navbar** - Logo, live indicator, clock
2. **ScenarioSelector** - Dropdown to select scenario
3. **TrainStatusCard** - Live train data (speed, position, ETA)
4. **LiveMapView** - Train positions on track
5. **DistanceTimeGraph** - Recharts line graph
6. **ConflictAlert** - Warning with countdown
7. **SolutionCard** - AI recommendations

---

## 📡 API CALLS

```javascript
// Get scenarios
fetch('/api/scenarios')

// Start scenario
fetch('/api/scenario/1/start', { method: 'POST' })

// Simulation step (call every 150ms)
fetch('/api/simulation/step', { method: 'POST' })

// Analyze conflict
fetch('/api/conflict/analyze', { method: 'POST' })
```

---

## 🎨 STYLING

**Colors:**
- Background: `#1a1a2e`
- Panel: `#16213e`
- Card: `#0f3460`
- Text: `#eaeaea`
- Live: `#ff0000` (pulsing)

**Fonts:**
- Numbers: `'Roboto Mono', monospace`
- Text: `'Inter', sans-serif`

---

## 🔄 REAL-TIME UPDATES

```javascript
useEffect(() => {
  if (!isRunning) return;
  
  const interval = setInterval(async () => {
    const res = await fetch('/api/simulation/step', { method: 'POST' });
    const data = await res.json();
    setTrains(data.trains);
    setConflict(data.conflicts[0]);
  }, 150);
  
  return () => clearInterval(interval);
}, [isRunning]);
```

---

## ✅ TESTING

**Scenario 1:** Stop FRT (363 kWh)  
**Scenario 2:** Multi-step switch (51 kWh)  
**Scenario 3:** Stop EXP (53 kWh, saves 1418 kWh!) 🔥

---

## 📚 FULL CONTEXT

See `FRONTEND_SESSION_CONTEXT.md` for:
- Complete API reference
- All component details
- Styling guide
- Helper functions
- Testing checklist
- Demo flow

---

**Time Estimate:** 5-6 hours  
**Status:** Backend ready, API functional  
**Next:** Build components following context doc

🎨 **START BUILDING!**
