/**
 * NeuralRail - Section Controller Display
 * Main Application Logic
 */

// ============================================
// CONFIGURATION
// ============================================
const CONFIG = {
  API_BASE: 'http://localhost:5000/api',
  UPDATE_INTERVAL: 800, // ms - slower updates for realistic movement (use speed controls to go faster)
  ANIMATION_DURATION: 800, // ms - match update interval for smooth transitions
};

// Route Data - REAL MUMBAI-PUNE CORRIDOR (from backend/data/railway_network.py)
const ROUTE = {
  totalKm: 192,
  stations: [
    { code: 'CSMT', name: 'Mumbai CSMT', km: 0, elevation: 10 },
    { code: 'THANE', name: 'Thane', km: 34, elevation: 25 },
    { code: 'KYN', name: 'Kalyan Jn', km: 54, elevation: 42 },
    { code: 'KARJAT', name: 'Karjat', km: 80, elevation: 150 },
    { code: 'LNL', name: 'Lonavala', km: 106, elevation: 625 },
    { code: 'PUNE', name: 'Pune Jn', km: 192, elevation: 560 }
  ],
  sections: [
    { from: 0, to: 34, tracks: 4, name: 'CSMT-THANE', type: 'suburban', maxSpeed: 100 },
    { from: 34, to: 54, tracks: 2, name: 'THANE-KALYAN', type: 'mainline', maxSpeed: 100 },
    { from: 54, to: 80, tracks: 2, name: 'KALYAN-KARJAT', type: 'mainline', maxSpeed: 100 },
    { from: 80, to: 106, tracks: 3, name: 'BHOR GHAT', type: 'ghat', maxSpeed: 60, gradient: 1.83 },
    { from: 106, to: 192, tracks: 2, name: 'LNL-PUNE', type: 'mainline', maxSpeed: 110 }
  ]
};

// Train Colors
const TRAIN_COLORS = {
  rajdhani: '#ff4444',
  freight_heavy: '#cd853f',
  vande_bharat: '#ffd700',
  local_emu: '#4a90d9',
  express_passenger: '#32cd32'
};

// ============================================
// STATE
// ============================================
let state = {
  connected: false,
  scenarios: [],
  currentScenario: null,
  trackInfo: null,  // Track info from scenario (blocked tracks, etc.)
  trains: [],
  conflict: null,
  solutions: [],
  isRunning: false,
  zoom: 100,
  energyConsumed: 0,
  energySaved: 0,
  graphData: [],
  // AI Performance metrics
  aiPerformance: {
    conflictsDetected: 0,
    conflictsResolved: 0,
    totalResponseTime: 0,
    responseCount: 0,
    correctDecisions: 0,
    totalDecisions: 0
  },
  // Simulation timing
  simulationStartTime: null,
  conflictDetectionDelay: 45000,  // Wait 45 seconds before showing conflict (more demo time for trains to get closer)
  // Playback controls
  playbackSpeed: 1  // 1 = normal, 2 = 2x, 0.5 = half speed
};

let updateInterval = null;


// ============================================
// INITIALIZATION
// ============================================
document.addEventListener('DOMContentLoaded', () => {
  initClock();
  initZoomControls();
  initEventListeners();
  renderTrackSVG();
  updateScrollMode();  // Set initial scroll mode
  initGraph();
  checkBackendConnection();
});

function initClock() {
  updateClock();
  setInterval(updateClock, 1000);
}

function updateClock() {
  const now = new Date();
  const timeStr = now.toLocaleTimeString('en-IN', { hour12: false });
  const dateStr = now.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  
  document.querySelector('.clock-time').textContent = timeStr;
  document.querySelector('.clock-date').textContent = dateStr;
}

// Zoom and Pan state
let zoomState = {
  scale: 1,
  panX: 0,
  panY: 0,
  isDragging: false,
  lastX: 0,
  lastY: 0
};

// Current focused section
let currentFocusSection = 'all';

function initZoomControls() {
  // Section selector - re-renders the map for focused section
  const sectionSelect = document.getElementById('sectionSelect');
  if (sectionSelect) {
    sectionSelect.addEventListener('change', (e) => {
      currentFocusSection = e.target.value;
      console.log('Section changed to:', currentFocusSection);
      renderTrackSVG();
      renderTrains();
      updateScrollMode();
    });
  } else {
    console.error('Section select element not found!');
  }
  
  // Initialize drag-to-scroll for track container
  initTrackScroll();
}

// Initialize horizontal drag-to-scroll for track container
function initTrackScroll() {
  const container = document.getElementById('trackContainer');
  if (!container) return;
  
  let isScrolling = false;
  let startX = 0;
  let scrollLeft = 0;
  
  container.addEventListener('mousedown', (e) => {
    if (!container.classList.contains('pannable')) return;
    
    isScrolling = true;
    startX = e.pageX - container.offsetLeft;
    scrollLeft = container.scrollLeft;
  });
  
  container.addEventListener('mouseleave', () => {
    isScrolling = false;
  });
  
  container.addEventListener('mouseup', () => {
    isScrolling = false;
  });
  
  container.addEventListener('mousemove', (e) => {
    if (!isScrolling) return;
    e.preventDefault();
    const x = e.pageX - container.offsetLeft;
    const walk = (x - startX) * 2;
    container.scrollLeft = scrollLeft - walk;
  });
  
  // Touch support
  container.addEventListener('touchstart', (e) => {
    if (!container.classList.contains('pannable')) return;
    startX = e.touches[0].pageX - container.offsetLeft;
    scrollLeft = container.scrollLeft;
  });
  
  container.addEventListener('touchmove', (e) => {
    if (!container.classList.contains('pannable')) return;
    const x = e.touches[0].pageX - container.offsetLeft;
    const walk = (x - startX) * 2;
    container.scrollLeft = scrollLeft - walk;
  });
}

// Update scroll/pan mode based on current focus
function updateScrollMode() {
  const container = document.getElementById('trackContainer');
  const svg = document.getElementById('trackSvg');
  
  if (!container || !svg) return;
  
  if (currentFocusSection === 'all') {
    // Full view - show entire route, no panning needed
    container.classList.remove('pannable');
    svg.classList.remove('zoomed');
    svg.style.width = '100%';
    container.scrollLeft = 0;
  } else {
    // Focused view - render full route zoomed, allow panning
    container.classList.add('pannable');
    svg.classList.add('zoomed');
    
    // Scroll to center on the focused section
    setTimeout(() => {
      scrollToFocusedSection();
    }, 50);
  }
}

// Scroll the track container to center on the focused section
function scrollToFocusedSection() {
  const container = document.getElementById('trackContainer');
  if (!container || currentFocusSection === 'all') return;
  
  const sectionIdx = parseInt(currentFocusSection);
  const section = ROUTE.sections[sectionIdx];
  if (!section) return;
  
  // Calculate the center km of the focused section
  const centerKm = (section.from + section.to) / 2;
  
  // Calculate scroll position (SVG is 2400px wide for 192km)
  const svgWidth = 2400;
  const padding = 80; // Left padding in SVG
  const trackWidth = svgWidth - padding - 60; // Minus right padding
  
  const scrollRatio = centerKm / ROUTE.totalKm;
  const targetScrollX = padding + (scrollRatio * trackWidth) - (container.clientWidth / 2);
  
  container.scrollLeft = Math.max(0, targetScrollX);
}

function initEventListeners() {
  document.getElementById('clearLog').addEventListener('click', clearLog);
  document.getElementById('rejectAll').addEventListener('click', closeConflictModal);
  document.getElementById('cancelSimulation').addEventListener('click', closeSimulationModal);
  document.getElementById('approveSimulation').addEventListener('click', approveSolution);
  
  // Playback controls (in navbar)
  document.getElementById('pauseBtn').addEventListener('click', togglePause);
  document.querySelectorAll('.speed-btn-nav').forEach(btn => {
    btn.addEventListener('click', () => setPlaybackSpeed(parseFloat(btn.dataset.speed)));
  });
}

// ============================================
// PLAYBACK CONTROLS
// ============================================
function togglePause() {
  state.isRunning = !state.isRunning;
  const pauseBtn = document.getElementById('pauseBtn');
  const pauseIcon = document.getElementById('pauseIcon');
  
  if (state.isRunning) {
    pauseIcon.textContent = '⏸️';
    pauseBtn.classList.remove('paused');
    startSimulation();
    addLog('info', '▶️ Simulation resumed');
  } else {
    pauseIcon.textContent = '▶️';
    pauseBtn.classList.add('paused');
    addLog('info', '⏸️ Simulation paused');
  }
}

function setPlaybackSpeed(speed) {
  state.playbackSpeed = speed;
  
  // Update UI (navbar buttons)
  document.querySelectorAll('.speed-btn-nav').forEach(btn => {
    btn.classList.toggle('active', parseFloat(btn.dataset.speed) === speed);
  });
  
  // Restart simulation with new speed
  if (state.isRunning) {
    startSimulation();
  }
  
  addLog('info', `⏩ Playback speed: ${speed}x`);
}

// ============================================
// API FUNCTIONS
// ============================================
async function checkBackendConnection() {
  try {
    const res = await fetch(`${CONFIG.API_BASE}/health`);
    if (res.ok) {
      setConnectionStatus(true);
      loadScenarios();
    } else {
      setConnectionStatus(false);
    }
  } catch (error) {
    setConnectionStatus(false);
    addLog('error', 'Backend connection failed. Start: python backend/api/app.py');
  }
}

function setConnectionStatus(connected) {
  state.connected = connected;
  const indicator = document.getElementById('connectionStatus');
  
  if (connected) {
    indicator.className = 'status-indicator live';
    indicator.querySelector('.status-text').textContent = 'LIVE';
    addLog('success', 'Connected to NeuralRail backend');
  } else {
    indicator.className = 'status-indicator error';
    indicator.querySelector('.status-text').textContent = 'OFFLINE';
  }
}

async function loadScenarios() {
  try {
    const res = await fetch(`${CONFIG.API_BASE}/scenarios`);
    const data = await res.json();
    state.scenarios = data.scenarios || [];
    renderScenarioButtons();
  } catch (error) {
    addLog('error', 'Failed to load scenarios');
  }
}

async function loadScenario(id) {
  try {
    addLog('info', `Loading Scenario ${id}...`);
    
    const res = await fetch(`${CONFIG.API_BASE}/scenario/${id}/start`, { method: 'POST' });
    const data = await res.json();
    
    state.currentScenario = data.scenario;
    state.trackInfo = data.track_info || {};
    state.trains = data.trains || [];
    state.conflict = null;
    state.solutions = [];
    state.energyConsumed = 0;
    state.energySaved = 0;
    state.graphData = [];
    state.isRunning = true;
    state.simulationStartTime = null;  // Reset so conflict detection delay starts fresh
    
    // Reset AI performance for new scenario
    state.aiPerformance = {
      conflictsDetected: 0,
      conflictsResolved: 0,
      totalResponseTime: 0,
      responseCount: 0,
      correctDecisions: 0,
      totalDecisions: 0
    };
    
    // Reset AI panel
    resetAIPanel();
    
    // Auto-focus track schematic on scenario's section
    autoFocusSection(data.scenario, data.track_info);
    
    updateScenarioButtons();
    renderTrains();
    updateTrainList();
    updateMetrics();
    clearGraph();
    
    addLog('success', `Scenario ${id} loaded: ${data.scenario.name}`);
    
    startSimulation();
  } catch (error) {
    addLog('error', 'Failed to load scenario');
  }
}

// Auto-focus track schematic based on scenario section
function autoFocusSection(scenario, trackInfo) {
  const sectionSelect = document.getElementById('sectionSelect');
  
  // Direct mapping: Scenario ID to Section Index
  // Scenario 1: Kalyan-Karjat (54-80 km) → section index "2"
  // Scenario 2: CSMT-Thane (0-34 km) → section index "0"  
  // Scenario 3: Bhor Ghat (80-106 km) → section index "3"
  
  let sectionIndex = 'all';
  
  // Method 1: Use track_info km range (most reliable)
  if (trackInfo && trackInfo.section_start_km !== undefined && trackInfo.section_end_km !== undefined) {
    const startKm = trackInfo.section_start_km;
    const endKm = trackInfo.section_end_km;
    
    // Find matching ROUTE section
    for (let i = 0; i < ROUTE.sections.length; i++) {
      const section = ROUTE.sections[i];
      if (section.from === startKm && section.to === endKm) {
        sectionIndex = i.toString();
        break;
      }
    }
  }
  
  // Method 2: Fallback - match by scenario section name
  if (sectionIndex === 'all' && scenario && scenario.section) {
    const name = scenario.section.toLowerCase();
    
    if (name.includes('kalyan') && name.includes('karjat')) {
      sectionIndex = '2';
    } else if (name.includes('csmt') || (name.includes('thane') && !name.includes('kalyan'))) {
      sectionIndex = '0';
    } else if (name.includes('thane') && name.includes('kalyan')) {
      sectionIndex = '1';
    } else if (name.includes('ghat') || name.includes('bhor')) {
      sectionIndex = '3';
    } else if (name.includes('pune') && name.includes('lonavala')) {
      sectionIndex = '4';
    }
  }
  
  // Apply the focus
  currentFocusSection = sectionIndex;
  sectionSelect.value = sectionIndex;
  
  // Re-render track with new focus
  renderTrackSVG();
  
  // Update scroll mode (enable/disable horizontal scroll)
  updateScrollMode();
  
  // Log which section we focused on
  if (sectionIndex !== 'all') {
    const focusedSection = ROUTE.sections[parseInt(sectionIndex)];
    addLog('info', `Map focused on: ${focusedSection.name} (${focusedSection.from}-${focusedSection.to} km)`);
  }
}


function startSimulation() {
  if (updateInterval) clearInterval(updateInterval);
  
  // Track when simulation started (for conflict detection delay)
  if (!state.simulationStartTime) {
    state.simulationStartTime = Date.now();
  }
  
  // Calculate update interval based on playback speed
  // Faster speed = shorter interval = more frequent updates
  const adjustedInterval = Math.max(100, CONFIG.UPDATE_INTERVAL / state.playbackSpeed);
  
  updateInterval = setInterval(async () => {
    if (!state.isRunning) return;
    
    try {
      const res = await fetch(`${CONFIG.API_BASE}/simulation/step`, { method: 'POST' });
      const data = await res.json();
      
      // Update trains with smooth transition
      updateTrainPositions(data.trains || []);
      
      // Update energy
      state.energyConsumed = data.system_energy_kwh || 0;
      updateMetrics();
      
      // Update graph
      addGraphPoint(data.trains);
      
      // Check for conflicts (only after delay - let trains move first for better visual)
      const timeSinceStart = Date.now() - state.simulationStartTime;
      if (data.conflicts && data.conflicts.length > 0 && timeSinceStart > state.conflictDetectionDelay) {
        handleConflict(data.conflicts[0]);
      }
    } catch (error) {
      console.error('Simulation step failed:', error);
    }
  }, adjustedInterval);
}

function stopSimulation() {
  state.isRunning = false;
  if (updateInterval) {
    clearInterval(updateInterval);
    updateInterval = null;
  }
}

async function handleConflict(conflict) {
  const startTime = Date.now();
  
  state.conflict = conflict;
  state.isRunning = false; // Pause for decision
  
  // Track conflict detected
  state.aiPerformance.conflictsDetected++;
  
  addLog('danger', `⚠️ CONFLICT DETECTED at ${conflict.position_km?.toFixed(1)} km!`);
  
  // Conflict zone rendering disabled - will be enabled when needed
  // renderConflictZone(conflict);
  
  // Get AI recommendations
  try {
    const res = await fetch(`${CONFIG.API_BASE}/conflict/analyze`, { method: 'POST' });
    const data = await res.json();
    
    state.solutions = data.solutions || [];
    state.energySaved = data.energy_saved_kwh || 0;
    
    // Track response time
    const responseTime = (Date.now() - startTime) / 1000;
    state.aiPerformance.totalResponseTime += responseTime;
    state.aiPerformance.responseCount++;
    
    updateMetrics();
    showConflictModal(conflict, state.solutions);
    
    addLog('info', `AI generated ${state.solutions.length} solutions in ${responseTime.toFixed(2)}s`);
  } catch (error) {
    addLog('error', 'Failed to analyze conflict');
  }
}

// ============================================
// TRACK RENDERING (SVG) - FULL ROUTE WITH SCROLL TO FOCUS
// ============================================
function renderTrackSVG() {
  const svg = document.getElementById('trackSvg');
  const container = document.getElementById('trackContainer');
  
  // Always render FULL route - scrolling handles focus
  const viewStartKm = 0;
  const viewEndKm = ROUTE.totalKm;
  
  // SVG dimensions - wider when in focused mode for panning
  const isFocused = currentFocusSection !== 'all';
  const width = isFocused ? 2400 : 1800;  // Wider when focused to allow panning
  const height = 350;
  const padding = { left: 80, right: 60, top: 55, bottom: 70 };
  const baseTrackSpacing = 30;
  const mergeZoneWidth = 60;
  
  // Update SVG viewBox and size
  svg.setAttribute('viewBox', `0 0 ${width} ${height}`);
  if (isFocused) {
    svg.style.width = `${width}px`;
    svg.style.minWidth = `${width}px`;
  } else {
    svg.style.width = '100%';
    svg.style.minWidth = '100%';
  }
  
  const viewRangeKm = viewEndKm - viewStartKm;
  const trackAreaWidth = width - padding.left - padding.right;
  const trackAreaHeight = height - padding.top - padding.bottom;
  
  // Clear existing
  svg.innerHTML = '';
  
  // Helper: km to x position (full route scale)
  const kmToX = (km) => padding.left + ((km - viewStartKm) / viewRangeKm) * trackAreaWidth;
  
  // Center Y for the track area
  const centerY = padding.top + trackAreaHeight / 2;
  
  // Helper: get Y positions for tracks in a section (centered)
  const getTrackYPositions = (numTracks) => {
    const positions = [];
    const totalHeight = (numTracks - 1) * baseTrackSpacing;
    const startY = centerY - totalHeight / 2;
    for (let i = 0; i < numTracks; i++) {
      positions.push(startY + i * baseTrackSpacing);
    }
    return positions;
  };
  
  // Background
  svg.innerHTML += `<rect x="0" y="0" width="${width}" height="${height}" fill="#050a12"/>`;
  
  // Draw distance markers (interval based on view range)
  const markerInterval = viewRangeKm > 100 ? 20 : viewRangeKm > 50 ? 10 : 5;
  const startMarker = Math.ceil(viewStartKm / markerInterval) * markerInterval;
  for (let km = startMarker; km <= viewEndKm; km += markerInterval) {
    const x = kmToX(km);
    if (x < padding.left || x > width - padding.right) continue;
    const isMajor = km % (markerInterval * 2) === 0;
    svg.innerHTML += `
      <line x1="${x}" y1="${padding.top - 5}" x2="${x}" y2="${height - padding.bottom + 5}" 
            stroke="${isMajor ? 'rgba(255,255,255,0.12)' : 'rgba(255,255,255,0.05)'}" stroke-width="1"/>
      <text x="${x}" y="${height - padding.bottom + 20}" text-anchor="middle" class="distance-label">${km}</text>
    `;
  }
  
  // Filter sections that are visible in current view
  const visibleSections = ROUTE.sections.filter(s => s.to > viewStartKm && s.from < viewEndKm);
  
  // Draw each visible section
  visibleSections.forEach((section) => {
    const sIdx = ROUTE.sections.indexOf(section);
    const x1 = Math.max(padding.left, kmToX(section.from));
    const x2 = Math.min(width - padding.right, kmToX(section.to));
    const midX = (x1 + x2) / 2;
    const nextSection = ROUTE.sections[sIdx + 1];
    const prevSection = ROUTE.sections[sIdx - 1];
    
    // Check if this section is the focused one
    const isFocusedSection = currentFocusSection !== 'all' && parseInt(currentFocusSection) === sIdx;
    
    // Track color based on section type
    const trackColor = section.tracks === 4 ? '#00ff88' : section.tracks === 3 ? '#ff6b35' : '#00d4ff';
    const trackYs = getTrackYPositions(section.tracks);
    
    // Highlight focused section with cyan dashed border
    if (isFocusedSection) {
      svg.innerHTML += `
        <rect x="${x1 - 5}" y="${padding.top - 10}" width="${x2 - x1 + 10}" height="${trackAreaHeight + 20}" 
              fill="rgba(0,212,255,0.08)" stroke="rgba(0,212,255,0.3)" stroke-width="2" stroke-dasharray="5,3" rx="8"/>
      `;
    }
    
    // Section background (subtle) for ghat
    if (section.type === 'ghat') {
      svg.innerHTML += `
        <rect x="${x1}" y="${padding.top}" width="${x2 - x1}" height="${trackAreaHeight}" 
              fill="rgba(255,107,53,0.08)" stroke="none"/>
      `;
    }
    
    // Section label at top
    svg.innerHTML += `
      <text x="${midX}" y="${padding.top - 20}" text-anchor="middle" class="section-label">${section.name}</text>
      <text x="${midX}" y="${padding.top - 5}" text-anchor="middle" class="section-tracks-label">${section.tracks} track${section.tracks > 1 ? 's' : ''}</text>
    `;
    
    // Gradient indicator for Bhor Ghat
    if (section.type === 'ghat' && section.gradient) {
      svg.innerHTML += `
        <text x="${midX}" y="${height - padding.bottom + 40}" text-anchor="middle" class="gradient-label">⛰️ ${section.gradient}%</text>
      `;
    }
    
    // Junction position is exactly at x2 (end of section = station)
    const junctionX = x2;
    const halfMergeZone = mergeZoneWidth / 2;
    
    // Tracks run from section start to just before junction, then from just after junction
    let mainStartX = x1;
    let mainEndX = x2;
    
    // If there's a transition at the START (coming from previous section)
    if (prevSection && prevSection.tracks !== section.tracks) {
      mainStartX = x1 + halfMergeZone;
    }
    // If there's a transition at the END (going to next section)
    if (nextSection && nextSection.tracks !== section.tracks) {
      mainEndX = x2 - halfMergeZone;
    }
    
    // Draw main horizontal tracks
    trackYs.forEach((y, tIdx) => {
      svg.innerHTML += `
        <line x1="${mainStartX}" y1="${y}" x2="${mainEndX}" y2="${y}" 
              stroke="${trackColor}" stroke-width="3" stroke-linecap="round"
              class="track-line tracks-${section.tracks}" data-section="${sIdx}" data-track="${tIdx + 1}"/>
      `;
      
      // Track number label (first section only)
      if (sIdx === 0) {
        svg.innerHTML += `
          <text x="${x1 - 8}" y="${y + 4}" text-anchor="end" class="track-num-label">T${tIdx + 1}</text>
        `;
      }
    });
    
    // Draw transitions AT THE JUNCTION using STRAIGHT DIAGONAL LINES
    if (nextSection && nextSection.tracks !== section.tracks) {
      const nextTrackYs = getTrackYPositions(nextSection.tracks);
      const nextStartX = x2 + halfMergeZone; // Next section starts after junction
      
      if (section.tracks > nextSection.tracks) {
        // MERGING at junction: 4→2 or 3→2 (straight diagonal lines)
        // Special handling for 3→2: middle track splits to both outputs
        if (section.tracks === 3 && nextSection.tracks === 2) {
          // Track 0 (top) → Track 0 (top)
          svg.innerHTML += `
            <line x1="${mainEndX}" y1="${trackYs[0]}" x2="${nextStartX}" y2="${nextTrackYs[0]}" 
                  stroke="${trackColor}" stroke-width="3" stroke-linecap="round" class="track-merge"/>
          `;
          // Track 1 (middle) → Track 0 (top) - fork
          svg.innerHTML += `
            <line x1="${mainEndX}" y1="${trackYs[1]}" x2="${nextStartX}" y2="${nextTrackYs[0]}" 
                  stroke="${trackColor}" stroke-width="3" stroke-linecap="round" class="track-merge"/>
          `;
          // Track 1 (middle) → Track 1 (bottom) - fork
          svg.innerHTML += `
            <line x1="${mainEndX}" y1="${trackYs[1]}" x2="${nextStartX}" y2="${nextTrackYs[1]}" 
                  stroke="${trackColor}" stroke-width="3" stroke-linecap="round" class="track-merge"/>
          `;
          // Track 2 (bottom) → Track 1 (bottom)
          svg.innerHTML += `
            <line x1="${mainEndX}" y1="${trackYs[2]}" x2="${nextStartX}" y2="${nextTrackYs[1]}" 
                  stroke="${trackColor}" stroke-width="3" stroke-linecap="round" class="track-merge"/>
          `;
        } else if (section.tracks === 4 && nextSection.tracks === 2) {
          // 4→2: Top 2 tracks merge to top, bottom 2 merge to bottom
          svg.innerHTML += `
            <line x1="${mainEndX}" y1="${trackYs[0]}" x2="${nextStartX}" y2="${nextTrackYs[0]}" 
                  stroke="${trackColor}" stroke-width="3" stroke-linecap="round" class="track-merge"/>
          `;
          svg.innerHTML += `
            <line x1="${mainEndX}" y1="${trackYs[1]}" x2="${nextStartX}" y2="${nextTrackYs[0]}" 
                  stroke="${trackColor}" stroke-width="3" stroke-linecap="round" class="track-merge"/>
          `;
          svg.innerHTML += `
            <line x1="${mainEndX}" y1="${trackYs[2]}" x2="${nextStartX}" y2="${nextTrackYs[1]}" 
                  stroke="${trackColor}" stroke-width="3" stroke-linecap="round" class="track-merge"/>
          `;
          svg.innerHTML += `
            <line x1="${mainEndX}" y1="${trackYs[3]}" x2="${nextStartX}" y2="${nextTrackYs[1]}" 
                  stroke="${trackColor}" stroke-width="3" stroke-linecap="round" class="track-merge"/>
          `;
        } else {
          // Generic merge
          trackYs.forEach((y, tIdx) => {
            const targetIdx = Math.floor(tIdx * nextSection.tracks / section.tracks);
            const nextY = nextTrackYs[targetIdx];
            svg.innerHTML += `
              <line x1="${mainEndX}" y1="${y}" x2="${nextStartX}" y2="${nextY}" 
                    stroke="${trackColor}" stroke-width="3" stroke-linecap="round" class="track-merge"/>
            `;
          });
        }
      } else {
        // DIVERGING at junction: 2→3 (straight diagonal lines)
        // Special handling for 2→3: each track splits appropriately
        if (section.tracks === 2 && nextSection.tracks === 3) {
          // Track 0 (top) → Track 0 (top)
          svg.innerHTML += `
            <line x1="${mainEndX}" y1="${trackYs[0]}" x2="${nextStartX}" y2="${nextTrackYs[0]}" 
                  stroke="${trackColor}" stroke-width="3" stroke-linecap="round" class="track-merge"/>
          `;
          // Track 0 (top) → Track 1 (middle) - fork
          svg.innerHTML += `
            <line x1="${mainEndX}" y1="${trackYs[0]}" x2="${nextStartX}" y2="${nextTrackYs[1]}" 
                  stroke="${trackColor}" stroke-width="3" stroke-linecap="round" class="track-merge"/>
          `;
          // Track 1 (bottom) → Track 1 (middle) - fork
          svg.innerHTML += `
            <line x1="${mainEndX}" y1="${trackYs[1]}" x2="${nextStartX}" y2="${nextTrackYs[1]}" 
                  stroke="${trackColor}" stroke-width="3" stroke-linecap="round" class="track-merge"/>
          `;
          // Track 1 (bottom) → Track 2 (bottom)
          svg.innerHTML += `
            <line x1="${mainEndX}" y1="${trackYs[1]}" x2="${nextStartX}" y2="${nextTrackYs[2]}" 
                  stroke="${trackColor}" stroke-width="3" stroke-linecap="round" class="track-merge"/>
          `;
        } else {
          // Generic diverge
          trackYs.forEach((y, tIdx) => {
            const ratio = nextSection.tracks / section.tracks;
            const startNextIdx = Math.floor(tIdx * ratio);
            const endNextIdx = Math.ceil((tIdx + 1) * ratio) - 1;
            
            for (let nIdx = startNextIdx; nIdx <= endNextIdx; nIdx++) {
              const nextY = nextTrackYs[nIdx];
              svg.innerHTML += `
                <line x1="${mainEndX}" y1="${y}" x2="${nextStartX}" y2="${nextY}" 
                      stroke="${trackColor}" stroke-width="3" stroke-linecap="round" class="track-merge"/>
              `;
            }
          });
        }
      }
    }
  });
  
  // Filter and draw visible stations
  const visibleStations = ROUTE.stations.filter(st => st.km >= viewStartKm - 2 && st.km <= viewEndKm + 2);
  visibleStations.forEach((station) => {
    const x = kmToX(station.km);
    if (x < padding.left - 10 || x > width - padding.right + 10) return;
    
    // Station line (vertical, subtle)
    svg.innerHTML += `
      <line x1="${x}" y1="${padding.top}" x2="${x}" y2="${height - padding.bottom}" 
            stroke="rgba(255,255,255,0.15)" stroke-width="1" stroke-dasharray="3,3"/>
    `;
    
    // Station marker and label
    svg.innerHTML += `
      <circle cx="${x}" cy="${height - padding.bottom + 8}" r="6" class="station-marker"/>
      <text x="${x}" y="${height - padding.bottom + 26}" text-anchor="middle" class="station-label">${station.code}</text>
      <text x="${x}" y="${height - padding.bottom + 40}" text-anchor="middle" class="station-km">${station.km} km</text>
    `;
  });
  
  // Render blocked tracks / incidents from scenario track_info
  renderBlockedTracks(svg, kmToX, getTrackYPositions, viewStartKm, viewEndKm, padding);
  
  // Container for conflict zone and trains
  svg.innerHTML += '<g id="conflictGroup"></g>';
  svg.innerHTML += '<g id="trainsGroup"></g>';
}

// Render blocked tracks and incidents based on scenario track_info
function renderBlockedTracks(svg, kmToX, getTrackYPositions, viewStartKm, viewEndKm, padding) {
  if (!state.trackInfo) return;
  
  const trackInfo = state.trackInfo;
  const sectionStartKm = trackInfo.section_start_km;
  const sectionEndKm = trackInfo.section_end_km;
  const numTracks = trackInfo.tracks || 2;
  
  // Check if this section is in view
  if (sectionEndKm < viewStartKm || sectionStartKm > viewEndKm) return;
  
  const trackYs = getTrackYPositions(numTracks);
  
  // Check each track status
  for (let t = 1; t <= numTracks; t++) {
    const statusKey = `track_${t}_status`;
    const detailsKey = `track_${t}_details`;
    const incidentKey = `track_${t}_incident`;
    
    const status = trackInfo[statusKey];
    const details = trackInfo[detailsKey];
    const incident = trackInfo[incidentKey];
    
    if (status === 'BLOCKED') {
      // Calculate center of the section width
      const sectionCenterKm = (sectionStartKm + sectionEndKm) / 2;
      const x = kmToX(sectionCenterKm);
      const y = trackYs[t - 1];
      
      // Draw blocked indicator - UNDER the track, centered horizontally
      svg.innerHTML += `
        <!-- Blocked Track Label - under track, centered -->
        <text x="${x}" y="${y + 18}" text-anchor="middle" fill="#ff3b3b" font-size="11" font-weight="700" 
              font-family="'JetBrains Mono', monospace">
          T${t} BLOCKED
        </text>
      `;
    }
  }
  
  // Render sidings if available
  if (trackInfo.sidings && trackInfo.sidings.length > 0) {
    trackInfo.sidings.forEach((siding, idx) => {
      const x = kmToX(siding.location_km);
      const trackY = trackYs[0]; // Connect to Track 1
      const sidingLength = 40; // Visual length of siding
      const sidingY = trackY - 25 - (idx * 20); // Above the track
      
      // Draw siding branch line (diagonal connection)
      svg.innerHTML += `
        <line x1="${x}" y1="${trackY}" x2="${x - 15}" y2="${sidingY}" 
              stroke="#ffb800" stroke-width="2" stroke-linecap="round"/>
      `;
      
      // Draw siding track (horizontal dead-end)
      svg.innerHTML += `
        <line x1="${x - 15}" y1="${sidingY}" x2="${x - 15 - sidingLength}" y2="${sidingY}" 
              stroke="#ffb800" stroke-width="3" stroke-linecap="round"/>
      `;
      
      // Draw dead-end marker (buffer stop)
      svg.innerHTML += `
        <rect x="${x - 15 - sidingLength - 4}" y="${sidingY - 5}" width="4" height="10" 
              fill="#ffb800" rx="1"/>
      `;
      
      // Siding label
      svg.innerHTML += `
        <text x="${x - 15 - sidingLength/2}" y="${sidingY - 8}" text-anchor="middle" 
              fill="#ffb800" font-size="9" font-weight="600" font-family="'JetBrains Mono', monospace">
          ${siding.name.split('(')[0].trim()}
        </text>
        <text x="${x - 15 - sidingLength/2}" y="${sidingY + 12}" text-anchor="middle" 
              fill="#8aa4c0" font-size="8" font-family="'JetBrains Mono', monospace">
          ${siding.location_km} km
        </text>
      `;
    });
  }
}

function renderTrains() {
  const group = document.getElementById('trainsGroup');
  if (!group) return;
  
  group.innerHTML = '';
  
  state.trains.forEach(train => {
    const pos = getTrainPosition(train);
    const color = train.color || TRAIN_COLORS[train.type] || '#00d4ff';
    const isForward = train.direction === 'forward';
    
    // Direction arrow points - larger for visibility
    const arrowSize = 8;
    const arrowX = isForward ? 18 : -18;
    const arrowPoints = isForward 
      ? `${arrowX - arrowSize},-${arrowSize/2} ${arrowX},0 ${arrowX - arrowSize},${arrowSize/2}`
      : `${arrowX + arrowSize},-${arrowSize/2} ${arrowX},0 ${arrowX + arrowSize},${arrowSize/2}`;
    
    group.innerHTML += `
      <g class="train-marker" id="train-${train.id}" transform="translate(${pos.x}, ${pos.y})">
        <!-- Glow effect -->
        <circle r="22" fill="${color}" opacity="0.25" class="train-glow"/>
        
        <!-- Main dot -->
        <circle r="12" class="train-dot" fill="${color}"/>
        
        <!-- Direction arrow -->
        <polygon points="${arrowPoints}" class="train-direction" fill="${color}"/>
        
        <!-- Train ID -->
        <text y="-22" text-anchor="middle" class="train-label">${train.id}</text>
      </g>
    `;
  });
}

function updateTrainPositions(newTrains) {
  newTrains.forEach(train => {
    const marker = document.getElementById(`train-${train.id}`);
    if (marker) {
      const pos = getTrainPosition(train);
      marker.setAttribute('transform', `translate(${pos.x}, ${pos.y})`);
    }
    
    // Update state
    const idx = state.trains.findIndex(t => t.id === train.id);
    if (idx >= 0) {
      state.trains[idx] = train;
    }
  });
  
  updateTrainList();
}

function getTrainPosition(train) {
  // SVG dimensions - must match renderTrackSVG
  const isFocused = currentFocusSection !== 'all';
  const width = isFocused ? 2400 : 1800;
  const height = 350;
  const padding = { left: 80, right: 60, top: 55, bottom: 70 };
  const baseTrackSpacing = 30;
  const mergeZoneWidth = 60; // pixels - must match renderTrackSVG
  
  // ALWAYS use full route range (0 to 192 km) - no focus-based clipping
  const viewStartKm = 0;
  const viewEndKm = ROUTE.totalKm;
  
  const viewRangeKm = viewEndKm - viewStartKm;
  const trackAreaWidth = width - padding.left - padding.right;
  const trackAreaHeight = height - padding.top - padding.bottom;
  const centerY = padding.top + trackAreaHeight / 2;
  
  // Convert merge zone from pixels to km (must match SVG rendering)
  const halfMergeZoneKm = (mergeZoneWidth / 2) / trackAreaWidth * viewRangeKm;
  
  // Helper: get Y positions for tracks in a section (centered)
  const getTrackYPositions = (numTracks) => {
    const positions = [];
    const totalHeight = (numTracks - 1) * baseTrackSpacing;
    const startY = centerY - totalHeight / 2;
    for (let i = 0; i < numTracks; i++) {
      positions.push(startY + i * baseTrackSpacing);
    }
    return positions;
  };
  
  // X position based on km (scaled to view range)
  const x = padding.left + ((train.position - viewStartKm) / viewRangeKm) * trackAreaWidth;
  
  // Find current section
  const sectionIdx = ROUTE.sections.findIndex(s => train.position >= s.from && train.position <= s.to);
  const section = ROUTE.sections[sectionIdx] || ROUTE.sections[0];
  const trackIdx = Math.min((train.track_number || 1) - 1, section.tracks - 1);
  
  // Get Y positions for current section
  const trackYs = getTrackYPositions(section.tracks);
  let y = trackYs[trackIdx];
  
  // Check if train is in a merge zone (transitioning between sections)
  const prevSection = ROUTE.sections[sectionIdx - 1];
  const nextSection = ROUTE.sections[sectionIdx + 1];
  
  // Entering this section from previous (tracks changing)
  if (prevSection && prevSection.tracks !== section.tracks) {
    const distFromStart = train.position - section.from;
    if (distFromStart < halfMergeZoneKm) {
      const progress = distFromStart / halfMergeZoneKm;
      const prevTrackYs = getTrackYPositions(prevSection.tracks);
      const prevTrackIdx = Math.min((train.track_number || 1) - 1, prevSection.tracks - 1);
      const prevY = prevTrackYs[prevTrackIdx];
      y = prevY + (y - prevY) * progress;
    }
  }
  
  // Exiting this section to next (tracks changing)
  if (nextSection && nextSection.tracks !== section.tracks) {
    const distToEnd = section.to - train.position;
    if (distToEnd < halfMergeZoneKm) {
      const progress = 1 - (distToEnd / halfMergeZoneKm);
      const nextTrackYs = getTrackYPositions(nextSection.tracks);
      const nextTrackIdx = Math.min((train.track_number || 1) - 1, nextSection.tracks - 1);
      const nextY = nextTrackYs[nextTrackIdx];
      y = y + (nextY - y) * progress;
    }
  }
  
  return { x, y };
}

function renderConflictZone(conflict) {
  const group = document.getElementById('conflictGroup');
  if (!group) return;
  
  const width = 1800;
  const height = 350;
  const padding = { left: 80, right: 60, top: 55, bottom: 70 };
  
  // Determine view range based on focused section
  let viewStartKm = 0;
  let viewEndKm = ROUTE.totalKm;
  
  if (currentFocusSection !== 'all') {
    const idx = parseInt(currentFocusSection);
    const section = ROUTE.sections[idx];
    if (section) {
      viewStartKm = Math.max(0, section.from - 3);
      viewEndKm = Math.min(ROUTE.totalKm, section.to + 3);
    }
  }
  
  const viewRangeKm = viewEndKm - viewStartKm;
  const trackAreaWidth = width - padding.left - padding.right;
  
  const km = conflict.position_km || 0;
  const x = padding.left + ((km - viewStartKm) / viewRangeKm) * trackAreaWidth;
  const zoneWidth = 50;
  
  group.innerHTML = `
    <!-- Glow effect -->
    <rect x="${x - zoneWidth/2 - 8}" y="${padding.top - 10}" width="${zoneWidth + 16}" height="${height - padding.top - padding.bottom + 20}" 
          class="conflict-zone-glow" rx="6"/>
    
    <!-- Main zone -->
    <rect x="${x - zoneWidth/2}" y="${padding.top}" width="${zoneWidth}" height="${height - padding.top - padding.bottom}" 
          class="conflict-zone" rx="4"/>
    
    <!-- Warning icon -->
    <text x="${x}" y="${padding.top - 15}" text-anchor="middle" font-size="18">⚠️</text>
    
    <!-- Conflict label -->
    <text x="${x}" y="${height - padding.bottom + 20}" text-anchor="middle" fill="#ff3b3b" font-size="10" font-weight="600">CONFLICT</text>
  `;
}

function clearConflictZone() {
  const group = document.getElementById('conflictGroup');
  if (group) group.innerHTML = '';
}

// ============================================
// TRAIN LIST
// ============================================
function updateTrainList() {
  const container = document.getElementById('trainList');
  const countEl = document.getElementById('trainCount');
  
  countEl.textContent = `${state.trains.length} trains`;
  
  if (state.trains.length === 0) {
    container.innerHTML = '<div class="empty-state">Select a scenario to begin</div>';
    return;
  }
  
  container.innerHTML = state.trains.map(train => {
    const color = train.color || TRAIN_COLORS[train.type] || '#00d4ff';
    const dirArrow = train.direction === 'forward' ? '→' : '←';
    const nextStation = train.next_station || '--';
    const distToStation = train.distance_to_station?.toFixed(0) || '--';
    
    return `
      <div class="train-card" style="--train-color: ${color}">
        <div class="train-header">
          <span class="train-id">${train.id}</span>
          <span class="train-speed">${train.speed?.toFixed(0) || 0}</span>
        </div>
        <div class="train-position">
          <span class="position-km">${train.position?.toFixed(1) || 0} km</span>
          <span class="position-track">T${train.track_number || 1}</span>
        </div>
        <div class="train-destination">
          <span class="dest-arrow">${dirArrow}</span>
          <span class="dest-station">${nextStation}</span>
          <span class="dest-distance">${distToStation}</span>
        </div>
      </div>
    `;
  }).join('');
}

// ============================================
// SCENARIO DROPDOWN (in Navbar)
// ============================================
let currentRunningScenarioId = null;  // Track which scenario is running

function renderScenarioButtons() {
  const select = document.getElementById('scenarioSelect');
  const runBtn = document.getElementById('runScenarioBtn');
  
  // Populate dropdown with scenario options
  select.innerHTML = '<option value="">Select Scenario</option>' +
    state.scenarios.map(scenario => 
      `<option value="${scenario.id}">${scenario.id}. ${scenario.name}${scenario.id === 3 ? ' 🔥' : ''}</option>`
    ).join('');
  
  // Handle selection change - just enable/disable run button
  select.addEventListener('change', () => {
    const selectedId = select.value;
    runBtn.disabled = !selectedId;
  });
  
  // Handle run button click
  runBtn.addEventListener('click', () => {
    const selectedId = select.value;
    if (selectedId) {
      currentRunningScenarioId = selectedId;  // Remember which scenario we're running
      loadScenario(parseInt(selectedId));
    }
  });
}

function updateScenarioButtons() {
  const select = document.getElementById('scenarioSelect');
  
  if (state.currentScenario && currentRunningScenarioId) {
    // Keep the dropdown showing the running scenario
    select.value = currentRunningScenarioId;
  }
}


// ============================================
// METRICS
// ============================================
function updateMetrics() {
  document.getElementById('energyConsumed').textContent = state.energyConsumed.toFixed(1);
  document.getElementById('energySaved').textContent = state.energySaved.toFixed(1);
  
  // CO2 calculation (0.82 kg per kWh for Indian grid)
  const co2 = state.energySaved * 0.82;
  document.getElementById('co2Reduced').textContent = co2.toFixed(1);
  
  // Killer feature highlight
  const killerEl = document.getElementById('killerFeature');
  if (state.energySaved > 1000) {
    killerEl.style.display = 'flex';
    const homes = Math.floor(state.energySaved / 5);
    document.getElementById('killerDesc').textContent = `Equivalent to powering ${homes} homes for 1 hour`;
  } else {
    killerEl.style.display = 'none';
  }
  
  // Update AI Performance metrics
  updateAIPerformance();
}

function updateAIPerformance() {
  const perf = state.aiPerformance;
  
  // Accuracy: correct decisions / total decisions (show as %)
  const accuracy = perf.totalDecisions > 0 
    ? ((perf.correctDecisions / perf.totalDecisions) * 100).toFixed(1) + '%'
    : '--';
  document.getElementById('aiAccuracy').textContent = accuracy;
  
  // Conflicts resolved
  document.getElementById('conflictsResolved').textContent = perf.conflictsResolved;
  
  // Average response time
  const avgResponse = perf.responseCount > 0
    ? (perf.totalResponseTime / perf.responseCount).toFixed(2) + 's'
    : '--';
  document.getElementById('avgResponseTime').textContent = avgResponse;
  
  // Safety score: 100% - (unresolved conflicts / detected conflicts) * 100
  const safetyScore = perf.conflictsDetected > 0
    ? (100 - ((perf.conflictsDetected - perf.conflictsResolved) / perf.conflictsDetected) * 100).toFixed(0) + '%'
    : '100%';
  document.getElementById('safetyScore').textContent = safetyScore;
}

// ============================================
// TIME-SPACE GRAPH (Canvas)
// Distance (Y-axis) vs Time (X-axis)
// - Diagonal line = train moving
// - Horizontal line = train stopped (distance constant)
// - Steeper slope = faster train
// ============================================
let graphCtx = null;
let graphStartTime = null;
const GRAPH_PADDING = { left: 55, right: 20, top: 15, bottom: 35 };

function initGraph() {
  const canvas = document.getElementById('graphCanvas');
  if (!canvas) {
    console.error('Graph canvas not found!');
    return;
  }
  
  graphCtx = canvas.getContext('2d');
  graphStartTime = Date.now();
  
  // Set canvas size after a short delay to ensure container has dimensions
  setTimeout(() => {
    resizeGraph();
    console.log('Graph initialized:', canvas.width, 'x', canvas.height);
  }, 100);
  
  window.addEventListener('resize', resizeGraph);
}

function resizeGraph() {
  const canvas = document.getElementById('graphCanvas');
  const container = canvas.parentElement;
  
  // Ensure we have valid dimensions
  const width = container.clientWidth || 400;
  const height = container.clientHeight || 200;
  
  canvas.width = width;
  canvas.height = height;
  
  console.log('Graph resized:', width, 'x', height);
  drawGraph();
}

function drawGraphGrid() {
  if (!graphCtx) return;
  
  const canvas = graphCtx.canvas;
  const w = canvas.width;
  const h = canvas.height;
  const p = GRAPH_PADDING;
  const graphW = w - p.left - p.right;
  const graphH = h - p.top - p.bottom;
  
  // Clear with dark background
  graphCtx.fillStyle = '#0d1a2d';
  graphCtx.fillRect(0, 0, w, h);
  
  // Draw graph area background
  graphCtx.fillStyle = '#1a2d47';
  graphCtx.fillRect(p.left, p.top, graphW, graphH);
  
  // Grid lines
  graphCtx.strokeStyle = '#2a4060';
  graphCtx.lineWidth = 1;
  
  // Y-AXIS: Distance (0-192 km) - Station markers
  const stations = ROUTE.stations;
  stations.forEach(station => {
    const y = p.top + graphH - (station.km / ROUTE.totalKm) * graphH;
    
    // Station grid line (dashed)
    graphCtx.strokeStyle = '#3a5070';
    graphCtx.setLineDash([4, 4]);
    graphCtx.beginPath();
    graphCtx.moveTo(p.left, y);
    graphCtx.lineTo(w - p.right, y);
    graphCtx.stroke();
    graphCtx.setLineDash([]);
    
    // Station label
    graphCtx.fillStyle = '#8aa4c0';
    graphCtx.font = '10px JetBrains Mono';
    graphCtx.textAlign = 'right';
    graphCtx.fillText(station.code, p.left - 5, y + 3);
  });
  
  // Additional distance markers (every 40km)
  graphCtx.fillStyle = '#5a7a9a';
  graphCtx.font = '9px JetBrains Mono';
  for (let km = 0; km <= ROUTE.totalKm; km += 40) {
    const y = p.top + graphH - (km / ROUTE.totalKm) * graphH;
    
    // Minor grid line
    graphCtx.strokeStyle = '#2a4060';
    graphCtx.beginPath();
    graphCtx.moveTo(p.left, y);
    graphCtx.lineTo(w - p.right, y);
    graphCtx.stroke();
  }
  
  // X-AXIS: Time markers
  const timeWindow = 120; // 120 seconds visible window
  const timeInterval = 20; // Label every 20 seconds
  
  for (let t = 0; t <= timeWindow; t += timeInterval) {
    const x = p.left + (t / timeWindow) * graphW;
    
    // Vertical grid line
    graphCtx.strokeStyle = t % 60 === 0 ? '#3a5070' : '#2a4060';
    graphCtx.lineWidth = t % 60 === 0 ? 1.5 : 1;
    graphCtx.beginPath();
    graphCtx.moveTo(x, p.top);
    graphCtx.lineTo(x, h - p.bottom);
    graphCtx.stroke();
    
    // Time label
    graphCtx.fillStyle = '#8aa4c0';
    graphCtx.font = '10px JetBrains Mono';
    graphCtx.textAlign = 'center';
    const mins = Math.floor(t / 60);
    const secs = t % 60;
    graphCtx.fillText(`${mins}:${secs.toString().padStart(2, '0')}`, x, h - p.bottom + 15);
  }
  
  // Axis labels
  graphCtx.fillStyle = '#00d4ff';
  graphCtx.font = '11px Inter';
  
  // Y-axis label (Distance)
  graphCtx.save();
  graphCtx.translate(12, h / 2);
  graphCtx.rotate(-Math.PI / 2);
  graphCtx.textAlign = 'center';
  graphCtx.fillText('Distance (km)', 0, 0);
  graphCtx.restore();
  
  // X-axis label (Time)
  graphCtx.textAlign = 'center';
  graphCtx.fillText('Time (mm:ss)', w / 2, h - 3);
  
  // Draw axis lines
  graphCtx.strokeStyle = '#5a7a9a';
  graphCtx.lineWidth = 2;
  graphCtx.beginPath();
  graphCtx.moveTo(p.left, p.top);
  graphCtx.lineTo(p.left, h - p.bottom);
  graphCtx.lineTo(w - p.right, h - p.bottom);
  graphCtx.stroke();
}

function addGraphPoint(trains) {
  if (!trains || trains.length === 0) {
    console.log('addGraphPoint: No trains data');
    return;
  }
  
  // Calculate elapsed time in seconds
  const elapsedSec = (Date.now() - graphStartTime) / 1000;
  
  // Store data point with timestamp
  const point = {
    time: elapsedSec,
    trains: trains.map(t => ({
      id: t.id,
      position: t.position,
      speed: t.speed || 0,
      color: t.color || TRAIN_COLORS[t.type] || '#00d4ff'
    }))
  };
  state.graphData.push(point);
  
  // Log every 10 points for debugging
  if (state.graphData.length % 10 === 0) {
    console.log(`Graph data points: ${state.graphData.length}, trains:`, point.trains.map(t => `${t.id}@${t.position.toFixed(1)}km`));
  }
  
  // Keep data for last 120 seconds
  const timeWindow = 120;
  const cutoffTime = elapsedSec - timeWindow;
  state.graphData = state.graphData.filter(p => p.time >= cutoffTime);
  
  drawGraph();
}

function drawGraph() {
  if (!graphCtx) {
    console.log('drawGraph: No context');
    return;
  }
  
  drawGraphGrid();
  
  // Show message if no data, but still draw if we have at least 1 point
  if (state.graphData.length === 0) {
    const canvas = graphCtx.canvas;
    graphCtx.fillStyle = '#5a7a9a';
    graphCtx.font = '12px Inter';
    graphCtx.textAlign = 'center';
    graphCtx.fillText('Run a scenario to see train movements', canvas.width / 2, canvas.height / 2);
    return;
  }
  
  const canvas = graphCtx.canvas;
  const w = canvas.width;
  const h = canvas.height;
  const p = GRAPH_PADDING;
  const graphW = w - p.left - p.right;
  const graphH = h - p.top - p.bottom;
  
  // Time window (120 seconds)
  const timeWindow = 120;
  const latestTime = state.graphData[state.graphData.length - 1].time;
  const startTime = Math.max(0, latestTime - timeWindow);
  
  // Get unique train IDs
  const trainIds = [...new Set(state.graphData.flatMap(pt => pt.trains.map(t => t.id)))];
  
  // Draw path for each train
  trainIds.forEach(trainId => {
    const points = state.graphData
      .map(pt => {
        const train = pt.trains.find(t => t.id === trainId);
        if (!train) return null;
        
        // X: time position (scrolling window)
        const x = p.left + ((pt.time - startTime) / timeWindow) * graphW;
        
        // Y: distance position (0 at bottom, 192 at top)
        const y = p.top + graphH - (train.position / ROUTE.totalKm) * graphH;
        
        return { x, y, color: train.color, speed: train.speed };
      })
      .filter(pt => pt !== null && pt.x >= p.left);
    
    if (points.length === 0) return;
    
    // Draw train path line (if we have 2+ points)
    if (points.length >= 2) {
      graphCtx.strokeStyle = points[0].color;
      graphCtx.lineWidth = 2.5;
      graphCtx.lineCap = 'round';
      graphCtx.lineJoin = 'round';
      graphCtx.beginPath();
      graphCtx.moveTo(points[0].x, points[0].y);
      
      for (let i = 1; i < points.length; i++) {
        graphCtx.lineTo(points[i].x, points[i].y);
      }
      graphCtx.stroke();
    }
    
    // Draw current position marker (larger dot at end)
    const last = points[points.length - 1];
    
    // Glow effect
    graphCtx.fillStyle = last.color;
    graphCtx.globalAlpha = 0.3;
    graphCtx.beginPath();
    graphCtx.arc(last.x, last.y, 10, 0, Math.PI * 2);
    graphCtx.fill();
    graphCtx.globalAlpha = 1;
    
    // Main dot
    graphCtx.fillStyle = last.color;
    graphCtx.beginPath();
    graphCtx.arc(last.x, last.y, 5, 0, Math.PI * 2);
    graphCtx.fill();
    
    // Train ID label near the dot
    graphCtx.fillStyle = '#ffffff';
    graphCtx.font = 'bold 10px JetBrains Mono';
    graphCtx.textAlign = 'left';
    graphCtx.fillText(trainId, last.x + 8, last.y + 3);
  });
  
  // Draw legend showing line interpretation
  drawGraphLegend();
}

function drawGraphLegend() {
  const canvas = graphCtx.canvas;
  const w = canvas.width;
  const p = GRAPH_PADDING;
  
  // Legend box in top-right
  const legendX = w - p.right - 150;
  const legendY = p.top + 5;
  
  graphCtx.fillStyle = 'rgba(13, 26, 45, 0.9)';
  graphCtx.fillRect(legendX, legendY, 145, 45);
  graphCtx.strokeStyle = '#3a5070';
  graphCtx.lineWidth = 1;
  graphCtx.strokeRect(legendX, legendY, 145, 45);
  
  graphCtx.font = '9px Inter';
  graphCtx.fillStyle = '#8aa4c0';
  graphCtx.textAlign = 'left';
  
  // Diagonal line = moving
  graphCtx.strokeStyle = '#00d4ff';
  graphCtx.lineWidth = 2;
  graphCtx.beginPath();
  graphCtx.moveTo(legendX + 8, legendY + 18);
  graphCtx.lineTo(legendX + 28, legendY + 10);
  graphCtx.stroke();
  graphCtx.fillText('Diagonal = Moving', legendX + 35, legendY + 16);
  
  // Horizontal line = stopped
  graphCtx.beginPath();
  graphCtx.moveTo(legendX + 8, legendY + 35);
  graphCtx.lineTo(legendX + 28, legendY + 35);
  graphCtx.stroke();
  graphCtx.fillText('Horizontal = Stopped', legendX + 35, legendY + 38);
}

function clearGraph() {
  state.graphData = [];
  graphStartTime = Date.now();
  console.log('Graph cleared, start time reset');
  resizeGraph();  // Ensure canvas is properly sized
}


// ============================================
// AI RECOMMENDATIONS PANEL
// ============================================
function showConflictModal(conflict, solutions) {
  const aiContent = document.getElementById('aiContent');
  const aiStatusBadge = document.getElementById('aiStatusBadge');
  
  // Update status badge
  aiStatusBadge.textContent = '⚠️ CONFLICT';
  aiStatusBadge.className = 'info-badge highlight';
  aiStatusBadge.style.background = 'rgba(255, 59, 59, 0.2)';
  aiStatusBadge.style.color = '#ff3b3b';
  
  // Add alert animation
  aiContent.classList.add('ai-alert');
  
  // Render conflict info and solutions in the AI panel
  aiContent.innerHTML = `
    <div class="ai-conflict-header">
      <span class="alert-icon">⚠️</span>
      <div class="alert-text">
        <div class="alert-title">Conflict Detected</div>
        <div class="alert-location">${conflict.position_km?.toFixed(1)} km • ${conflict.train_a} vs ${conflict.train_b} • ${conflict.time_minutes?.toFixed(1)} min</div>
      </div>
    </div>
    <div class="ai-solutions">
      ${solutions.slice(0, 5).map((sol, idx) => `
        <div class="ai-solution-card ${idx === 0 ? 'recommended' : ''}" data-index="${idx}">
          <div class="solution-header">
            <span class="solution-rank">${idx + 1}</span>
            <span class="solution-action">${sol.action}</span>

          </div>
          <div class="solution-metrics">
            <div class="metric">
              <span class="metric-value">${sol.energy_kwh?.toFixed(0)}</span>
              <span class="metric-label">kWh</span>
            </div>
            <div class="metric">
              <span class="metric-value">${sol.delay_minutes?.toFixed(1)}</span>
              <span class="metric-label">min</span>
            </div>
            <div class="metric">
              <span class="metric-value">${sol.score?.toFixed(1)}</span>
              <span class="metric-label">score</span>
            </div>
          </div>
          <div class="solution-actions">
            <button class="btn btn-secondary btn-sm simulate-btn" data-index="${idx}">Simulate</button>
            <button class="btn btn-success btn-sm approve-btn" data-index="${idx}">✓ Approve</button>
          </div>
        </div>
      `).join('')}
      <button class="btn btn-secondary reject-all-btn" style="width: 100%; margin-top: 8px;">Reject All & Continue</button>
    </div>
  `;
  
  // Add event listeners
  aiContent.querySelectorAll('.simulate-btn').forEach(btn => {
    btn.addEventListener('click', () => simulateSolution(parseInt(btn.dataset.index)));
  });
  
  aiContent.querySelectorAll('.approve-btn').forEach(btn => {
    btn.addEventListener('click', () => approveSolutionDirect(parseInt(btn.dataset.index)));
  });
  
  aiContent.querySelector('.reject-all-btn')?.addEventListener('click', () => closeConflictModal());
}

function closeConflictModal() {
  resetAIPanel();
  clearConflictZone();
  state.conflict = null;
  state.isRunning = true;
  startSimulation();
  addLog('warning', 'All solutions rejected. Simulation resumed.');
}

function resetAIPanel() {
  const aiContent = document.getElementById('aiContent');
  const aiStatusBadge = document.getElementById('aiStatusBadge');
  
  // Reset status badge
  aiStatusBadge.textContent = 'Monitoring';
  aiStatusBadge.className = 'info-badge';
  aiStatusBadge.style.background = '';
  aiStatusBadge.style.color = '';
  
  // Remove alert animation
  aiContent.classList.remove('ai-alert');
  
  // Reset to idle state
  aiContent.innerHTML = `
    <div class="ai-idle-state">
      <div class="ai-icon">🧠</div>
      <div class="ai-message">AI is monitoring train movements</div>
      <div class="ai-submessage">Recommendations will appear when conflicts are detected</div>
    </div>
  `;
}

// ============================================
// SIMULATION MODAL
// ============================================
let currentSimulationIndex = null;

function simulateSolution(index) {
  currentSimulationIndex = index;
  const solution = state.solutions[index];
  
  // Close conflict modal
  document.getElementById('conflictModal').classList.remove('active');
  
  // Open simulation modal
  const modal = document.getElementById('simulationModal');
  document.getElementById('simAction').textContent = solution.action;
  document.getElementById('simEnergy').textContent = `${solution.energy_kwh?.toFixed(0)} kWh`;
  document.getElementById('simDelay').textContent = `${solution.delay_minutes?.toFixed(1)} min`;
  
  modal.classList.add('active');
  
  // Run simulation animation
  runSimulationAnimation(solution);
}

function runSimulationAnimation(solution) {
  const progressBar = document.getElementById('simProgress');
  const svg = document.getElementById('simulationSvg');
  
  // Draw simple track in simulation view
  svg.innerHTML = `
    <line x1="50" y1="75" x2="550" y2="75" stroke="#4a6a8a" stroke-width="4"/>
    <circle cx="100" cy="75" r="8" fill="${state.trains[0]?.color || '#ff4444'}" id="simTrain1"/>
    <circle cx="500" cy="75" r="8" fill="${state.trains[1]?.color || '#cd853f'}" id="simTrain2"/>
    <text x="100" y="55" text-anchor="middle" fill="#e8f0f8" font-size="12">${state.trains[0]?.id || 'T1'}</text>
    <text x="500" y="55" text-anchor="middle" fill="#e8f0f8" font-size="12">${state.trains[1]?.id || 'T2'}</text>
  `;
  
  // Animate
  let progress = 0;
  const duration = 3000; // 3 seconds
  const startTime = Date.now();
  
  function animate() {
    const elapsed = Date.now() - startTime;
    progress = Math.min(elapsed / duration, 1);
    
    progressBar.style.width = `${progress * 100}%`;
    
    // Move trains based on solution
    const train1 = document.getElementById('simTrain1');
    const train2 = document.getElementById('simTrain2');
    
    if (solution.action.includes('Stop') && solution.action.includes(state.trains[1]?.id)) {
      // Train 2 stops, train 1 continues
      train1.setAttribute('cx', 100 + progress * 200);
    } else if (solution.action.includes('Stop') && solution.action.includes(state.trains[0]?.id)) {
      // Train 1 stops, train 2 continues
      train2.setAttribute('cx', 500 - progress * 200);
    } else {
      // Both slow down
      train1.setAttribute('cx', 100 + progress * 100);
      train2.setAttribute('cx', 500 - progress * 100);
    }
    
    if (progress < 1) {
      requestAnimationFrame(animate);
    } else {
      addLog('info', 'Simulation complete. Review and approve if satisfied.');
    }
  }
  
  animate();
}

function closeSimulationModal() {
  document.getElementById('simulationModal').classList.remove('active');
  // Reopen conflict modal
  if (state.conflict && state.solutions.length > 0) {
    showConflictModal(state.conflict, state.solutions);
  }
}

function approveSolution() {
  if (currentSimulationIndex !== null) {
    approveSolutionDirect(currentSimulationIndex);
  }
  document.getElementById('simulationModal').classList.remove('active');
}

function approveSolutionDirect(index) {
  const solution = state.solutions[index];
  
  // Close modals
  document.getElementById('conflictModal').classList.remove('active');
  document.getElementById('simulationModal').classList.remove('active');
  
  // Reset AI panel
  resetAIPanel();
  
  // Track AI performance - conflict resolved
  state.aiPerformance.conflictsResolved++;
  state.aiPerformance.totalDecisions++;
  // If user approved recommended solution (index 0), count as correct
  if (index === 0) {
    state.aiPerformance.correctDecisions++;
  }
  updateAIPerformance();
  
  clearConflictZone();
  state.conflict = null;
  
  addLog('success', `✅ Solution approved: ${solution.action}`);
  addLog('info', `Energy: ${solution.energy_kwh?.toFixed(0)} kWh | Delay: ${solution.delay_minutes?.toFixed(1)} min`);
  
  // Resume simulation
  state.isRunning = true;
  startSimulation();
}


// ============================================
// DECISION LOG
// ============================================
function addLog(type, message) {
  const container = document.getElementById('logContent');
  const now = new Date();
  const timeStr = now.toLocaleTimeString('en-IN', { hour12: false });
  
  const entry = document.createElement('div');
  entry.className = `log-entry ${type}`;
  entry.innerHTML = `
    <span class="log-time">${timeStr}</span>
    <span class="log-msg">${message}</span>
  `;
  
  container.appendChild(entry);
  container.scrollTop = container.scrollHeight;
  
  // Keep only last 50 entries
  while (container.children.length > 50) {
    container.removeChild(container.firstChild);
  }
}

function clearLog() {
  const container = document.getElementById('logContent');
  container.innerHTML = `
    <div class="log-entry info">
      <span class="log-time">${new Date().toLocaleTimeString('en-IN', { hour12: false })}</span>
      <span class="log-msg">Log cleared. System ready.</span>
    </div>
  `;
}

// ============================================
// UTILITY FUNCTIONS
// ============================================
function formatTime(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

// ============================================
// KEYBOARD SHORTCUTS
// ============================================
document.addEventListener('keydown', (e) => {
  // ESC to close modals
  if (e.key === 'Escape') {
    document.getElementById('conflictModal').classList.remove('active');
    document.getElementById('simulationModal').classList.remove('active');
  }
  
  // 1, 2, 3 to load scenarios
  if (e.key >= '1' && e.key <= '3' && !e.ctrlKey && !e.altKey) {
    const id = parseInt(e.key);
    if (state.scenarios.find(s => s.id === id)) {
      loadScenario(id);
    }
  }
  
  // + / - for zoom
  if (e.key === '+' || e.key === '=') {
    setZoom(state.zoom + 25);
  }
  if (e.key === '-') {
    setZoom(state.zoom - 25);
  }
});

// ============================================
// ERROR HANDLING
// ============================================
window.addEventListener('error', (e) => {
  console.error('Application error:', e.error);
  addLog('error', 'An error occurred. Check console for details.');
});

// Retry connection periodically if disconnected
setInterval(() => {
  if (!state.connected) {
    checkBackendConnection();
  }
}, 5000);
