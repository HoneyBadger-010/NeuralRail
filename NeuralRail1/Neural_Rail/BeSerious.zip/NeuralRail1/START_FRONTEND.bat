@echo off
echo ========================================
echo   NeuralRail Frontend Startup
echo ========================================
echo.
echo Starting React development server...
echo Frontend will run on: http://localhost:3000
echo.
echo Make sure backend is running on port 5000!
echo.

cd frontend
npm run dev

pause
